# Performance & Resource Model

How the app sizes itself and how to tune it. Applies to **1.2.0**.

## CPU budget

At startup the app computes an *effective* CPU budget as:

```
budget = min(host_cores, cgroup_quota_cores, affinity_cores)
```

- `host_cores` — `os.cpu_count()`
- `cgroup_quota_cores` — cgroup v2 `/sys/fs/cgroup/cpu.max` or cgroup v1
  `cpu.cfs_quota_us / cpu.cfs_period_us` (Docker `--cpus`, Compose `cpus:`,
  Kubernetes limits). `null`/`max` means unlimited.
- `affinity_cores` — `len(os.sched_getaffinity(0))` (Linux).

Sizing from the host instead of the budget is what causes **CFS throttling**:
too many runnable threads for the quota → the kernel stalls the whole cgroup
each period → CPU% looks low while wall-clock slows down.

## Workers and threads

```
workers = min(budget / threads_target, RAM / OCR_RAM_PER_WORKER_GB, budget)
threads_per_worker = budget / workers      # when "auto"
```

- `threads_target` for auto worker sizing is **4**. Each worker then uses
  `budget / workers` threads, so `workers × threads ≈ budget`.
- Threads are applied to `OMP_NUM_THREADS`, `MKL_NUM_THREADS`,
  `OPENBLAS_NUM_THREADS`, `NUMEXPR_NUM_THREADS`, `OMP_THREAD_LIMIT`,
  `torch.set_num_threads()` and `cv2.setNumThreads()`.
- Operator-set env vars always win (`setdefault`).

### Knobs

| Variable | Default | Meaning |
| --- | --- | --- |
| `OCR_WORKER_CONCURRENCY` | `auto` | Celery worker processes |
| `OCR_THREADS_PER_WORKER` | `auto` | Threads per worker |
| `OCR_RAM_PER_WORKER_GB` | `2.5` | RAM assumed per worker for auto sizing |

Pin integers to override the automatic values.

## Inspecting the live values

```
GET /api/v1/stats/system
```

returns `cpu_cores` (effective), `cpu_host_cores`, `cpu_budget_cores`,
`cpu_cgroup_quota_cores`, `worker_count`, `recommended_workers`,
`threads_per_worker`. The System Health page shows the budget next to the core
count, and the worker logs the resolved values on startup.

## Container limits

If you cap the container, keep the budget honest by setting `cpus:` (the app
reads the resulting cgroup quota automatically):

```yaml
services:
  worker:
    cpus: "4"
```

Example: 16 host cores, container `cpus: 4`, auto → `workers=1`,
`threads=4` (4 requests for RAM permitting), rather than 4 workers × 4 threads.

## Verifying no throttling

```bash
docker exec ocr-worker cat /sys/fs/cgroup/cpu.max        # v2
docker exec ocr-worker cat /sys/fs/cgroup/cpu/cpu.cfs_quota_us  # v1
docker stats ocr-worker        # CPU% should approach (not exceed) budget
```

Under load, `workers × threads_per_worker` should be ≤ budget and container CPU%
should track the quota closely instead of hovering near zero.

## Per-job monitoring

`resource_monitor.py` samples peak RSS and average CPU per job; those feed the
benchmark results (`time`, `ram`, `cpu`) and the Analytics/Lab pages. A CPU
value above 100% simply means multiple cores were used and is expected.
