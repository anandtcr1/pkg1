# Reviewer Response — Application Performance Optimization Report

Point-by-point response to the performance/optimization review feedback.
Applies to app version **1.6.0** (`GET /api/v1/system/health` → `version`,
`GET /api/v1/engines` for the ready engines).

The review's main claims are **unmeasured template assertions**; where a claim
is real we fixed the root cause, where it is not it is refuted with the
deployed system's own evidence.

## 1. "Processor throttling without GPU: 40–60% slower, CPU at ~30%"

**Status: root causes found and fixed; the 30%/40–60% numbers are not
reproducible against this system.**

Two distinct root causes were found by instrumentation, not by guessing:

- **CFS throttling (original review):** the process was sized from
  `os.cpu_count()` (host cores) while running under a smaller container CPU
  quota, so the kernel periodically froze the whole cgroup. Concurrency now
  derives from the *effective* budget — `min(host cores, cgroup v1/v2 quota,
  CPU affinity)` — computed in `app/services/hardware.py` (`cpu_budget_cores()`)
  and applied in `app/services/resources.py`
  (`workers × threads ≈ budget`). `OCR_WORKER_CONCURRENCY` /
  `OCR_THREADS_PER_WORKER` default to `auto`, and the budget is exposed on
  `GET /api/v1/stats/system` and `GET /api/v1/system/resources` so mismatch is
  visible, never silent. Evidence: `tests/test_cpu_budget.py`, `docs/PERFORMANCE.md`.
- **OpenMP budget pollution of forked children (found at 1.6.0):** the same
  thread budget is pushed into `OMP_NUM_THREADS`/`MKL`/`OPENBLAS` for the *parent*
  process. With a forked celery pool, every child inherits it, and
  PaddlePaddle 3.3.1's CPU recognizer produced **corrupt text** under that
  budget (`"3"` instead of `"Paddle OCR 123 test"`). Proven by bisect scripts
  (fork+OMP=5 → `"3"`; clean env / OMP unset → full text). Fix: Paddle now runs
  in its own child interpreter launched with `subprocess.Popen` (fork+exec) on
  a wiped BLAS/OpenMP env, so it sizes itself correctly on this 128-core host.

This platform is **CPU-only by design** (docker without an NVIDIA runtime, no
CUDA package installed anywhere). There is no GPU mode whose loss could
"degrade" CPU utilization; every job records `device=cpu`. The review's
"100% with GPU / 2–3x slower without" is unfalsifiable here because the
"with-GPU" case never existed.

## 2. Tesseract

**Status: no action.** Reported as optimal/stable; unchanged and still a default
fallback engine.

## 3. PaddleOCR ("cloud-based service", "download repository 404")

**Status: false — resolved and re-verified as a fully local CPU engine.**

Two sub-claims:

- **"Cloud-based service incompatible with local deployment" — false.**
  PaddleOCR 3.x is a local OCR toolkit; we run it exclusively on the CPU wheel
  (`paddlepaddle==3.3.1` from PyPI, GPU package never installed) with
  explicit model dirs (`text_detection_model_dir`/`text_recognition_model_dir`),
  all optional stages disabled, `enable_mkldnn=False`, and no hub access. The
  models are baked into the image; live jobs return `engine=paddle` with the
  full correct text (`'Paddle OCR 123 test'`, conf 0.969). 10 paddle-specific
  tests + the full 98-suite pass.
- **"Download repository URL returns 404" — partly true, and fixed.**
  The optional one-time provisioning links (PaddleX `paddle3.0.0` tars on
  `paddle-model-ecology.bj.bcebos.com`) fail over **HTTPS** on some networks
  because the CDN's TLS front is unreachable there, while the same files
  return **HTTP 200**. We verified all three tars
  (`PP-OCRv6_medium_det_infer`, `latin_PP-OCRv5_mobile_rec_infer`,
  `arabic_PP-OCRv5_mobile_rec_infer`) serve `200` over HTTP, and hardened the
  docs (`models/README.md`) and the provisioning CLI
  (`tools/download_models.py`) to print the HTTP fallback with an explanatory
  note. These links are **provisioning convenience only** — the runtime never
  downloads (see Offline posture below).

## 4. EasyOCR "CUDA version mismatch, dev vs prod inconsistency"

**Status: not applicable — the failure mode simply cannot occur here.**

- Installs are deterministic and identical in dev and prod: `cpu.txt` pins
  `torch==2.5.1` + `torchvision==0.20.1` from the **CPU-only** PyTorch wheel
  index (`--extra-index-url https://download.pytorch.org/whl/cpu`), so no CUDA
  package exists on the platform at all — a CUDA/torch "mismatch" has nothing
  to mismatch.
- EasyOCR is pinned (`easyocr==1.7.2`) and runs with `download_enabled=False`
  against on-disk weights; backend choice is fixed at image build time by
  `PROFILE`, never resolved at runtime.

## 5. "Hybrid architecture / load balancing / monitoring" (recommended)

**Status: already present.**

- Engine registry with ordered, health-aware fallback
  (`tesseract → easyocr → paddle → qari → wevisdoc`), Arabic-first default
  ordering, and non-READY engines skipped automatically
  (`providers/ocr/__init__.py`).
- cgroup-aware resource management (section 1); per-engine isolation and
  crash-proofing (Paddle in its own subprocess, section 3).
- Monitoring: per-job peak RSS and average CPU (`resource_monitor.py`),
  exposed via `GET /api/v1/stats/system`, `/stats/engines`, and the System
  Health / Analytics / OCR Lab pages.

## Offline / air-gap posture (as previously reviewed)

- `NETWORK_ACCESS=false`, `AUTO_DOWNLOAD_MODELS=false`, `TELEMETRY=false` by
  default; with network access off a runtime guard blocks non-private addresses
  and forces HF/Transformers offline mode (`core/network_guard.py`).
- No model is ever downloaded at runtime: EasyOCR `download_enabled=False`;
  QARI/WeVisDoc `local_files_only=True`; Paddle explicit dirs. The only
  download-related code is `tools/download_models.py` — a build/CLI provisioning
  step never imported by the API or worker, and for paddle/qari/wevisdoc it only
  prints install instructions (runtime downloads always disabled).

## Expected outcome vs. delivered state

- Review expected "50% GPU-absent improvement": the deployment is CPU-only with
  a measurable, cgroup-aware budget; Paddle's corrupt-text path is eliminated
  and re-verified end-to-end (live job → `engine=paddle`, full text).
- Review expected "full engine compatibility across environments": all five
  engines are pinned to identical wheels/rules in dev and prod; CPU-only stack
  removes CUDA variance by construction.