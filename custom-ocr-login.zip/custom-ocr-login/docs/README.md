# Docs

- [Offline / air-gapped deployment](OFFLINE.md) — the offline contract, network guard,
  model provisioning, and verification steps.
- OCR Lab benchmark workflow — see the in-app OCR Lab page and `POST /api/v1/benchmark`.