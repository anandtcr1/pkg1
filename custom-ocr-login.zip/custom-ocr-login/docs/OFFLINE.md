# Offline / Air-gapped Deployment (IOCR)

IOCR is designed to run with **zero runtime network access**. Every model is local,
nothing is downloaded at request time, and any accidental outbound attempt fails fast
with an explicit error instead of hanging on a timeout.

## The offline contract

| Setting            | Value used in air-gapped mode | Effect |
|--------------------|-------------------------------|--------|
| `OFFLINE_MODE`     | `true`                        | Reported in System Health; implies deployment posture |
| `NETWORK_ACCESS`   | `false`                       | Enables the in-process socket guard (see below) |
| `MODEL_SOURCE`     | `local`                       | Engines only look in `MODELS_DIR` |
| `AUTO_DOWNLOAD_MODELS` | `false`                   | Nothing is ever fetched at runtime |
| `TELEMETRY`        | `false`                       | No external telemetry/crash reporters |
| `MODELS_DIR`       | `/models` (Docker)            | Must be provisioned before first run |

If a model is missing, the affected engine reports `MODEL_NOT_INSTALLED` with the
exact expected path, and the OCR job fails with error code `MODEL_NOT_INSTALLED` —
never a silent download.

## Network guard

With `NETWORK_ACCESS=false` an in-process socket guard (installed by `app/core/network_guard.py`
in both the API and the worker) blocks every outbound `socket.connect`/`connect_ex` to
a public address and sets library offline switches (`HF_HUB_OFFLINE`, `TRANSFORMERS_OFFLINE`, …).
Private ranges (`127/8`, `10/8`, `172.16/12`,
`192.168/16`, `::1`, `fc00::/7`) stay allowed so the API can still reach PostgreSQL and
Redis inside the Docker network. A blocked attempt raises `NetworkAccessBlocked`.

## Provisioning models (one time, on a connected host)

```bash
python -m app.tools.download_models --target ./models \
    --engines tesseract,easyocr,qari
```

- Uses local copies where possible (Tesseract traineddata from the system package).
- EasyOCR weights come from GitHub; Tesseract traineddata is copied from the system package.
- `qari` is **print-only**: no download is performed. It creates `models/qari/`
  and prints the exact NAMAA-Space Qwen2-VL-2B files to copy (v0.2 adapter,
  v0.3 standalone, `base/` for the adapter) — see the full install steps in
  `models/README.md`.
- `wevisdoc` is also **print-only**: it creates `models/wevisdoc/` and prints the
  exact Tencent Qwen3-VL-2B/4B files to copy. Using its native
  `Qwen3VLForConditionalGeneration` loader means **no trust_remote_code**, so the
  air-gap contract is preserved automatically.
- `paddle` is **print-only** too: it creates `models/paddle/{det,rec_latin,rec_arabic}`
  and prints the official PaddleX `paddle3.0.0` tar URLs. Paddle is wired with an
  explicit local model dir on every call, so PaddleX never contacts its model hub.
- Copy the resulting `./models` directory onto the target machine as `MODELS_DIR`.
- In Docker the images **bake a seed** (`MODELS_SEED_DIR=/opt/models-seed`); the
  entrypoint copies it into the `models_data` volume on first start. The seed
  contains whatever the build could fetch — a build without network still produces
  a working image for Tesseract, just fewer engines.

## QARI-OCR in offline mode

QARI-OCR is a local Qwen2-VL-2B-Instruct fine-tune (Qwen2-VL OCR); it runs entirely
in-process on CPU (bf16) or CUDA (fp16), needs no API key, and never phones home.
If the model files are absent, `/api/v1/engines` reports `MODEL_NOT_INSTALLED`
with the exact expected directories and the health probe marks the engine SKIPPED —
auto OCR silently routes to a ready engine (Tesseract/EasyOCR) for non-Arabic
documents and picks QARI only for Arabic/mixed documents when QARI is actually READY.
The optional WeVisDoc engine (page→Markdown) follows the same contract: absent or
incompatible files → `MODEL_NOT_INSTALLED`/`UNAVAILABLE`, never a download.

## Verifying the offline posture

1. `GET /api/v1/system/health` → `offline` object: `offline_mode`, `network_access`,
   `network_guard_active`, `model_source`, `auto_download_models`, `telemetry`,
   `models_dir_exists`.
2. `POST /api/v1/system/health/check` → runs a real local probe per READY engine and
   stores `PASS`/`FAIL`/`SKIPPED` on `engines[*].last_check`.
3. Firewall-level proof: disconnect the host from the network and run an OCR job.
   It must still complete using local models.

## Error codes you will see in offline mode

- `MODEL_NOT_INSTALLED` — expected local path is reported in the job error.
- `NETWORK_BLOCKED` — guard refused an outbound attempt.
- `UNSUPPORTED_FILE` / `CORRUPTED_IMAGE` / `CORRUPTED_PDF` — document validation.
- `ENGINE_BUSY` — another heavy generative job (QARI/WeVisDoc) holds the exclusive
  CPU inference lock; the caller waited `HEAVY_INFERENCE_WAIT_S` seconds.

## Performance on CPU-only hosts

Generative decode (QARI/WeVisDoc) is memory-bandwidth-bound, so low CPU
utilization is physical, not a scheduling bug. The runtime keeps it sane:

- `OCR_THREADS_PER_WORKER=auto` derives the thread budget from the real host
  quota (cores ∩ cgroup ∩ affinity) and pins torch to it — no CFS oversubscription.
- `heavy_inference_guard()` (in `app/services/hardware.py`) serializes heavy
  generations across processes with an exclusive file lock, so two VLMs never
  thrash the same memory bus at once (`HEAVY_INFERENCE_WAIT_S` = wait timeout).
- **Adaptive engine selection**: `engine=auto` (the default) routes Arabic →
  QARI, ordinary documents → cheap Tesseract/PaddleOCR, and only routes to the
  expensive structured parser (WeVisDoc) when `prefer_quality=true` or
  `quality_mode=high`.
- **PaddleOCR on CPU**: MKLDNN stays off (`enable_mkldnn=False`) because
  PaddlePaddle 3.3.1's PIR/oneDNN path crashes on this CPU toolchain; Paddle runs
  on the plain CPU backend and is treated as a classic (non-heavy) engine, so it
  never contends for the heavy inference lock.
- **Throughput monitoring**: generative jobs record `tokens_processed`
  (output tokens, never a quality claim). `GET /api/v1/stats/engines` exposes
  honest `avg_seconds_per_page` and `avg_tokens_per_sec` per engine;
  `overview.total_tokens_processed` tracks the total.

## Keeping it that way

Never ship `.env` credentials (`.gitignore`d), keep `TELEMETRY=false`, and monitor via
`GET /api/v1/system/resources` + System Status in the dashboard.