# Authentication Changes — Active Directory, Windows SSO & New Login Screen

This document describes every change made to add **Active Directory (LDAP) authentication**, **Windows single sign-on (Kerberos)**, **AD user management** and the **redesigned login screen** to IOCR. Use it to port the same changes into the main project.

---

## Contents

1. [Summary](#1-summary)
2. [Authentication rules](#2-authentication-rules)
3. [How it works (flows)](#3-how-it-works-flows)
4. [Python packages and system libraries](#4-python-packages-and-system-libraries)
5. [Configuration (environment variables)](#5-configuration-environment-variables)
6. [Database changes](#6-database-changes)
7. [API changes](#7-api-changes)
8. [Backend files changed](#8-backend-files-changed)
9. [Frontend files changed](#9-frontend-files-changed)
10. [Login screen redesign](#10-login-screen-redesign)
11. [Deployment and infrastructure setup](#11-deployment-and-infrastructure-setup)
12. [Security notes](#12-security-notes)
13. [Porting checklist for the main project](#13-porting-checklist-for-the-main-project)
14. [Testing](#14-testing)
15. [Known limitations](#15-known-limitations)

---

## 1. Summary

| Area | Change |
|---|---|
| User management | Admins search Active Directory (`ldap://dev.team.ae`) and add users to the application database. New **Users** page. |
| Login | A user can sign in only if they exist in **both** the application database **and** Active Directory. The password is verified by AD. |
| Exception | The local account **`administrator` / `123456`** signs in with a local password and never goes to AD. |
| Windows SSO | Users who are not signed in are logged in automatically with their Windows account (Kerberos). If that fails they are redirected to the login page. |
| Auth required | `REQUIRE_AUTH` now defaults to `true`, so anonymous users are always redirected to the login page. |
| Downloads/previews | Direct URLs (exports, original file, page images, benchmark previews) now carry the session token so they still work when login is required. |
| Login UI | Full-screen animated backdrop ("data extracted from documents") with a sample Arabic UAE certificate; login card centered. English + Arabic. |

---

## 2. Authentication rules

> **Updated 2026-10-16:** `administrator` / `123456` is no longer created by default. While no users exist, the app shows a first-run **"Create administrator"** screen, and every local account signs in with its local password. Set `ADMIN_PASSWORD` to keep the seeded account. See the entry "First-run setup" in [CHANGELOG.md](CHANGELOG.md).

| Who | How they sign in | Requirements |
|---|---|---|
| `administrator` (configurable via `ADMIN_USERNAME`) | Username + local password (`ADMIN_PASSWORD`, default `123456`) | None — this is the break-glass account. Never checked against AD. Cannot sign in through Windows SSO. Cannot be removed or demoted. |
| Everyone else | Username + **AD password**, or **Windows SSO** | 1) Registered in the application DB by an admin, **and** 2) exists and is **enabled** in AD. |

Additional rules:

- Accepted username formats at login: `jdoe`, `DEV\jdoe`, `jdoe@dev.team.ae` (all normalised to the `sAMAccountName`, `jdoe`). Lookups are case-insensitive.
- **Disabled AD accounts** are excluded from search and cannot be added or sign in.
- **Empty passwords are always rejected** (AD treats an empty-password bind as a successful "unauthenticated bind").
- **Removing a user** from the application, or deleting/disabling them in AD, blocks their next login. Removing them from the application also invalidates their existing session tokens immediately (tokens are resolved against the `users` table on every request).
- User-management endpoints always require a signed-in **administrator**, even when `REQUIRE_AUTH=false`. API keys never qualify as admin.

---

## 3. How it works (flows)

### 3.1 Adding a user (admin)

```
Admin → Users page → search "jdoe"
  → GET /api/v1/users/directory?q=jdoe
      → service-account bind to AD → LDAP search (enabled users only) → results (+ "already added" flag)
Admin → "Add"
  → POST /api/v1/users {username, is_admin}
      → exact AD lookup by sAMAccountName (must exist & be enabled)
      → insert into users (auth_source="ldap", hashed_password="!ldap", display_name, email)
```

### 3.2 Username/password login

```
POST /api/v1/auth/login {username, password}
 ├─ username == ADMIN_USERNAME ? → bcrypt check against local hash → JWT
 └─ otherwise
     ├─ normalise username → must exist in users table          (else 401)
     ├─ service-account bind → find user DN in AD (enabled)      (else 401)
     ├─ bind as user DN with the supplied password               (else 401)
     ├─ AD unreachable / misconfigured                           → 503
     └─ refresh display_name from AD → JWT
```

### 3.3 Windows SSO (automatic login)

```
Browser opens any app page, not signed in
 → AuthGuard: GET /auth/me → not authenticated
 → GET /api/v1/auth/sso  (fetch with credentials: "include")
     1st response: 401 + WWW-Authenticate: Negotiate
     browser retries with Authorization: Negotiate <Kerberos ticket>
     server validates ticket (pyspnego: SSPI on Windows / GSSAPI+keytab on Linux)
       → principal jdoe@DEV.TEAM.AE or DEV\jdoe
       → realm/domain must be allowed (SSO_DOMAINS or derived from base DN)
       → user must be registered in DB and enabled in AD
       → 200 + JWT (+ mutual-auth token)
 → success: token stored, page renders
 → failure: redirect to /login (or continue anonymously if auth is not required)
```

- After an explicit **sign-out** (or a failed SSO attempt), auto-login is skipped for the rest of that browser session (`sessionStorage` flag `iocr.sso_skip`) so the user can sign in with another account, e.g. `administrator`. A successful login clears the flag.
- On failure the server returns **401 without** a `WWW-Authenticate` header on purpose, so the browser never shows a Windows credentials pop-up.
- The login page also has a manual **"Sign in with Windows account"** button.

---

## 4. Python packages and system libraries

### 4.1 Added to `backend/requirements/base.txt`

| Package | Version | Purpose | Notable dependencies pulled in |
|---|---|---|---|
| `ldap3` | `2.9.1` | Pure-Python LDAP client: AD search, service-account bind, user password verification (simple bind). | `pyasn1` |
| `pyspnego[kerberos]` | `0.11.2` | Server-side SPNEGO/Kerberos ticket validation for Windows SSO. | `cryptography`; **Windows:** `sspilib` (native SSPI); **Linux:** `gssapi`, `krb5` (the `[kerberos]` extra, only installed on non-Windows) |

Excerpt:

```text
# --- Security ---
python-jose[cryptography]==3.3.0
passlib[bcrypt]==1.7.4
# Active Directory login / user search (pure Python, no system libs)
ldap3==2.9.1
# Windows SSO (Kerberos/SPNEGO). Windows uses SSPI; Linux pulls gssapi + krb5
# (built against libkrb5-dev, see Dockerfile) and reads the keytab in KRB5_KTNAME.
pyspnego[kerberos]==0.11.2
```

Already present and reused: `python-jose` (JWT), `bcrypt`/`passlib` (local admin password).

### 4.2 System packages (Docker image)

`backend/Dockerfile` — added to the `apt-get install` list (needed to build/run `gssapi` and `krb5` on Linux):

```dockerfile
    gcc \
    libkrb5-dev \
```

### 4.3 Local installation note

On the development machine pip failed TLS verification (`CERTIFICATE_VERIFY_FAILED`, corporate proxy). Use the Windows certificate store instead of disabling verification:

```bash
backend/.venv/Scripts/python.exe -m pip install --use-feature=truststore ldap3==2.9.1 "pyspnego[kerberos]==0.11.2"
```

### 4.4 Downloading packages for offline installation

The Docker image (Linux, Python 3.11) and a Windows development venv (Python 3.12) need **different** wheel files.

> **Why not `pip download --platform …` for Linux?** pip evaluates the packages' platform markers against the machine it runs on, not the `--platform` target. Run on Windows, it fetches the Windows-only `sspilib` and **skips** `gssapi` and `krb5`. Those two also have **no prebuilt Linux wheels** (source only, compiled against Kerberos headers). Build the Linux wheels inside a Linux container instead.

#### 4.4.1 Linux wheels for the Docker image (Python 3.11)

On any machine with Docker and internet access (PowerShell):

```powershell
mkdir wheels-linux
docker run --rm -v "${PWD}\wheels-linux:/wheels" python:3.11-slim sh -c "apt-get update && apt-get install -y --no-install-recommends gcc libkrb5-dev && pip wheel --wheel-dir /wheels ldap3==2.9.1 pyspnego[kerberos]==0.11.2 gssapi==1.12.0 krb5==0.10.0"
```

This produces Linux wheels for the packages and all their dependencies: `ldap3`, `pyspnego`, `gssapi`, `krb5`, `pyasn1`, `cryptography`, `cffi`, `pycparser`, `decorator`. `gssapi 1.12.0` and `krb5 0.10.0` are the current releases. Pin them in `requirements/base.txt` as well, so the offline build always matches:

```text
gssapi==1.12.0 ; sys_platform != "win32"
krb5==0.10.0 ; sys_platform != "win32"
```

> This command was not run on the development machine (Docker is not installed there).

#### 4.4.2 Windows wheels for a local venv (Python 3.12)

Run on Windows with the same Python version as the venv:

```powershell
pip download -d wheels-win ldap3==2.9.1 "pyspnego[kerberos]==0.11.2"
```

Downloads 7 files (verified):

```text
cffi-2.1.1-cp312-cp312-win_amd64.whl
cryptography-50.0.2-cp311-abi3-win_amd64.whl
ldap3-2.9.1-py2.py3-none-any.whl
pyasn1-0.6.4-py3-none-any.whl
pycparser-3.11-py3-none-any.whl
pyspnego-0.11.2-py3-none-any.whl
sspilib-0.6.0-cp311-abi3-win_amd64.whl
```

Windows does not need `gssapi` / `krb5`; pyspnego uses the built-in Windows Kerberos support (SSPI via `sspilib`).

> Behind the TLS-intercepting proxy, add `--use-feature=truststore` to every `pip` command, or pip fails with `CERTIFICATE_VERIFY_FAILED`.

#### 4.4.3 Installing offline

Windows venv:

```powershell
pip install --no-index --find-links wheels-win ldap3==2.9.1 "pyspnego[kerberos]==0.11.2"
```

Dockerfile (copy `wheels-linux/` into the backend build context first):

```dockerfile
COPY wheels-linux/ /wheels/
RUN pip install --no-index --find-links /wheels ldap3==2.9.1 "pyspnego[kerberos]==0.11.2"
```

Notes:

- With prebuilt wheels, the image no longer needs `gcc` (it was only needed to compile). It still needs the Kerberos **runtime** library: `libgssapi-krb5-2` is enough instead of `libkrb5-dev`.
- **If `gssapi` / `krb5` cannot be built:** password login through Active Directory still works fully. Only Windows auto-login (SSO) on Linux stops working: `/auth/sso` logs `SSO - Kerberos acceptor unavailable` and users are sent to the login page.

---

## 5. Configuration (environment variables)

All settings live in `backend/app/core/config.py` and are documented in `.env.example`.

### 5.1 Changed defaults

| Variable | Old default | New default | Note |
|---|---|---|---|
| `REQUIRE_AUTH` | `false` | **`true`** | Anonymous users are redirected to the login page. |
| `ADMIN_USERNAME` | `admin` | **`administrator`** | The only local-password account. |
| `ADMIN_PASSWORD` | *(empty → random)* | **`123456`** | Re-synced into the DB on every start. **Change for production.** |
| `CORS_ORIGINS` | hard-coded in compose | `${CORS_ORIGINS:-http://localhost:3000}` | Now also the allow-list for the credentialed SSO call. |

### 5.2 New variables

| Variable | Default | Description |
|---|---|---|
| `LDAP_ENABLED` | `true` | Turn AD integration on/off. |
| `LDAP_SERVER` | `ldap://dev.team.ae` | `ldap://host[:389]` or `ldaps://host[:636]`. |
| `LDAP_USE_STARTTLS` | `false` | Upgrade `ldap://` to TLS (required if the DC enforces LDAP signing). |
| `LDAP_BASE_DN` | *(empty)* | Empty = read `defaultNamingContext` from the DC (e.g. `DC=dev,DC=team,DC=ae`). |
| `LDAP_BIND_USER` | *(empty)* | **Required.** Read-only service account: `svc_ocr@dev.team.ae`, `DEV\svc_ocr` or a full DN. |
| `LDAP_BIND_PASSWORD` | *(empty)* | **Required.** Service-account password. |
| `LDAP_TIMEOUT_S` | `10` | Connect/receive timeout (seconds). |
| `SSO_ENABLED` | `true` | Enable Windows SSO endpoint. |
| `SSO_DOMAINS` | *(empty)* | Accepted Kerberos realms / NetBIOS domains, comma-separated. Empty = derived from base DN (`DEV.TEAM.AE`, `DEV`). |
| `KRB5_KTNAME` | `/etc/krb5/http.keytab` (compose) | Path to the keytab for `HTTP/<api-host>` (Linux only). |

### 5.3 docker-compose.yml

- `backend` service: added `LDAP_*`, `SSO_ENABLED`, `SSO_DOMAINS`, `KRB5_KTNAME`, `CORS_ORIGINS` (env-driven); changed `REQUIRE_AUTH`, `ADMIN_USERNAME`, `ADMIN_PASSWORD` defaults; added a commented keytab volume:
  ```yaml
      # Windows SSO keytab (see .env.example):
      # - ./secrets/krb5:/etc/krb5:ro
  ```
- `worker` service: only the `REQUIRE_AUTH` / `ADMIN_*` defaults changed (the worker never authenticates users, so no LDAP variables).

---

## 6. Database changes

Table **`users`** — two new nullable columns (model: `backend/app/models/models.py`):

| Column | Type | Meaning |
|---|---|---|
| `auth_source` | `VARCHAR(16)` | `"local"` (break-glass admin) or `"ldap"` (AD user). |
| `display_name` | `VARCHAR(255)` | AD `displayName`, refreshed on each login. |

**Migration:** none needed if the main project uses the existing `ensure_schema()` (it adds missing columns on startup). Otherwise run:

```sql
ALTER TABLE users ADD COLUMN auth_source VARCHAR(16);
ALTER TABLE users ADD COLUMN display_name VARCHAR(255);
```

Data conventions:

- AD users are stored with `hashed_password = "!ldap"`. This can never match a bcrypt check, so AD users can never sign in locally.
- `ensure_admin()` creates or repairs the `administrator` row on every start (`auth_source="local"`, `is_admin=true`, password hash re-synced from `ADMIN_PASSWORD`).
- A pre-existing `admin` row from earlier versions is left in place but can no longer sign in unless an `admin` account also exists in AD.

---

## 7. API changes

All under `/api/v1`.

### 7.1 Auth

| Method & path | Change | Notes |
|---|---|---|
| `POST /auth/login` | **Modified** | Local check for `administrator`; AD check for everyone else. Returns `503` when AD is unreachable. Response now includes `display_name`. |
| `GET /auth/sso` | **New** | Windows SSO (Kerberos/SPNEGO). See flow 3.3. |
| `GET /auth/me` | Unchanged | Used by the frontend guard. |

Login / SSO success response:

```json
{
  "access_token": "<jwt>",
  "token_type": "bearer",
  "expires_in": 43200,
  "username": "jdoe",
  "display_name": "John Doe",
  "is_admin": false,
  "auth_required": true
}
```

`/auth/sso` responses:

| Situation | Status | `WWW-Authenticate` |
|---|---|---|
| No `Authorization: Negotiate` header | 401 | `Negotiate` (challenge) |
| Valid ticket, registered + enabled user | 200 | `Negotiate <mutual-auth token>` (if any) |
| Bad ticket / NTLM instead of Kerberos / foreign realm / not registered / disabled in AD / AD down / `administrator` | 401 | *none* (prevents browser pop-up) |

### 7.2 Users (new router, admin only)

| Method & path | Body / query | Response | Errors |
|---|---|---|---|
| `GET /users` | — | `UserOut[]` | 401, 403 |
| `GET /users/directory?q=<2-64 chars>&limit=<1-100>` | — | `DirectoryUserOut[]` | 401, 403, 503 (AD) |
| `POST /users` | `{"username": "jdoe", "is_admin": false}` | `UserOut` (201) | 400 (administrator), 404 (not in AD / disabled), 409 (already added), 503 |
| `PATCH /users/{id}` | `{"is_admin": true}` | `UserOut` | 400 (own account / administrator), 404 |
| `DELETE /users/{id}` | — | 204 | 400 (own account / administrator), 404 |

Schemas (`backend/app/schemas/schemas.py`):

```python
class UserOut(BaseModel):          # id, username, display_name, email, is_admin, auth_source, created_at
class DirectoryUserOut(BaseModel): # username, display_name, email, upn, department, title, registered
class UserCreate(BaseModel):       # username (1-128), is_admin=False
class UserUpdate(BaseModel):       # is_admin
```

### 7.3 Token in query string

Unchanged backend behaviour, now used by the frontend: any endpoint accepts the session JWT as `?api_key=<token>` (in addition to `Authorization: Bearer`). This is used for URLs the browser loads directly (downloads, `<img>`, PDF viewer).

---

## 8. Backend files changed

### 8.1 New files

| File | Purpose |
|---|---|
| `backend/app/services/ldap_service.py` | All AD logic: `normalize_username`, `search_users`, `find_user`, `authenticate`, `directory_domains`, `LdapError`, `LdapUser`. Filters enabled users with `(&(objectCategory=person)(objectClass=user)(!(userAccountControl:1.2.840.113556.1.4.803:=2)))`. Escapes user input with `escape_filter_chars`. Caches the base DN. Converts socket/LDAP errors to `LdapError` (→ HTTP 503). |
| `backend/app/api/v1/users.py` | Users router (list, AD search, add, change role, remove). All endpoints depend on `require_admin`. |
| `backend/app/core/sso_cors.py` | `SSOCorsMiddleware` — for `/api/v1/auth/sso` only, returns `Access-Control-Allow-Origin: <origin>` + `Allow-Credentials: true` **only** for origins in `CORS_ORIGINS`; strips CORS headers for any other origin. |

### 8.2 Modified files

| File | Changes |
|---|---|
| `backend/app/api/v1/auth.py` | Added `find_user` (case-insensitive), `is_local_admin`, rewritten `ensure_admin` (creates/repairs `administrator`, re-syncs password), rewritten `login` (local vs AD), new `_session` helper, new `GET /auth/sso` endpoint with `_split_principal` and `_sso_refused`. Imports `spnego`, `ldap_service`. |
| `backend/app/core/security.py` | New dependency `require_admin` (signed-in admin user required; API keys rejected). |
| `backend/app/core/config.py` | New `LDAP_*`, `SSO_*` settings; `sso_domain_list` property; new defaults for `REQUIRE_AUTH`, `ADMIN_USERNAME`, `ADMIN_PASSWORD`. |
| `backend/app/core/network_guard.py` | New `allow_host(host)` — the offline guard blocks public IPs; the AD server's resolved IPs are allow-listed right before each LDAP connection. |
| `backend/app/models/models.py` | `User.auth_source`, `User.display_name`. |
| `backend/app/schemas/schemas.py` | `UserOut`, `DirectoryUserOut`, `UserCreate`, `UserUpdate`. |
| `backend/app/main.py` | Registers `users.router`; adds `SSOCorsMiddleware` (added last = outermost); startup log lines for AD/SSO status (`service_account=MISSING` when not configured, keytab path). |
| `backend/requirements/base.txt` | `ldap3`, `pyspnego[kerberos]`. |
| `backend/Dockerfile` | `gcc`, `libkrb5-dev`. |
| `docker-compose.yml` | See §5.3. |
| `.env.example` | New "Active Directory" and "Windows single sign-on" sections; new defaults. |

---

## 9. Frontend files changed

### 9.1 New files

| File | Purpose |
|---|---|
| `frontend/app/(app)/users/page.tsx` | **Users** admin page: table of registered users (name, login, e-mail, source, role, created), promote/demote, remove; "Add user" dialog with AD search, "grant administrator" checkbox, "already added" badge. |
| `frontend/components/login-showcase.tsx` | `LoginBackdrop` (full-screen animated background) and `LoginMark` (animated logo). |
| `frontend/assets/uae-emblem.png` | Emblem used on the sample certificate (transparent PNG, 171×192). |

### 9.2 Modified files

| File | Changes |
|---|---|
| `frontend/lib/api.ts` | `windowsLogin()` (SSO call with `credentials: "include"`, 15 s timeout); `authUrl()` (appends `?api_key=<token>`); `isWindowsSsoSkipped()` / `skipWindowsSso()`; `AUTH_CHANGED_EVENT` dispatched by `setStoredToken` / `clearStoredToken`; `clearStoredToken` sets the SSO-skip flag; `listUsers`, `searchDirectory`, `addUser`, `setUserAdmin`, `removeUser`; `exportJobUrl`, `originalFileUrl`, `exportCorrectionsUrl`, `benchmarkFileUrl` now wrapped in `authUrl()`. |
| `frontend/lib/types.ts` | `AppUser`, `DirectoryUser`; `display_name` on `LoginResponse`. |
| `frontend/components/auth-guard.tsx` | Rewritten: `/auth/me` → if not signed in, try `windowsLogin()` (unless skipped) → on failure redirect to `/login` when auth is required. Shows "Signing in with your Windows account…" while trying. |
| `frontend/components/sidebar.tsx` | New nav item **Users** (Administration group); account row refreshes on `AUTH_CHANGED_EVENT`. |
| `frontend/components/document-viewer.tsx` | Page images loaded via `authUrl(page.image_url)`. |
| `frontend/app/login/page.tsx` | Complete redesign (see §10); "Sign in with Windows account" button; distinct "AD unavailable" error message; show/hide password. |
| `frontend/app/globals.css` | Login animation keyframes and classes (`login-scan`, `login-box`, `login-field`, `login-progress`, `login-stream`, `login-float`, `login-glow`, `login-scan-mini`) + `prefers-reduced-motion` rules. |
| `frontend/lib/i18n.tsx` | New English + Arabic keys: `nav.users`, `users.*`, `auth.unavailable`, `auth.windows*`, `auth.or`, `auth.welcome`, `auth.show_password`, `auth.hide_password`, `auth.footer`, `login.hero.*`, `login.demo.*`. |

No new npm packages were added (uses existing `lucide-react`, `tailwindcss-animate`, `next/image`).

---

## 10. Login screen redesign

**Theme:** "data extracted from documents", dark navy gradient with grid and soft glows.

Layout:

- **Full-screen animated backdrop** (`LoginBackdrop`, `aria-hidden`):
  - Brand (top-left), floating file-type badges (PDF, JPG, PNG, TIFF, DOCX).
  - **Sample Arabic certificate** (left): UAE flag-colour band, emblem, "الإمارات العربية المتحدة", "شهادة تسجيل", fields رقم المرجع / الاسم / الإمارة / تاريخ الإصدار, signature, "نموذج" stamp, diagonal **"نموذج · SAMPLE"** watermark. Marked `translate="no"` so browser auto-translate does not rewrite it.
  - A **scan beam** sweeps the certificate; each value gets a blue bounding box as the beam crosses it.
  - **Data particles** stream from the certificate, behind the login card, to an **"Extracted fields"** card (right) where each value appears with a confidence score, followed by a progress bar.
  - Headline "Turn documents into data" + feature pills (bottom-left; hidden on short screens).
- **Login card centered** on top: animated scan logo, "Welcome back", username/password with icons, show/hide password, Sign in, "Sign in with Windows account", "Secured with Active Directory · runs fully offline". Language and theme toggles top-right.

Animation details:

- One **7-second cycle**, pure CSS (no JS/libraries). All animations use `transform`/`opacity` (GPU-friendly, in sync).
- Each bounding box / extracted row has an inline `animation-delay` matching when the beam reaches that line.
- `prefers-reduced-motion`: no movement; shows the finished extraction.
- Responsive: the certificate and result card need ≥ 1280 px (`xl`) beside the centered card; on smaller screens only the backdrop and badges show.
- RTL (Arabic UI) supported via logical properties (`start`/`end`).

> **Emblem:** the certificate shows the official emblem supplied by the requester. Use of official UAE emblems is regulated — confirm your organisation is authorised to display it, especially if the login page is visible outside your own staff. To replace it, swap `frontend/assets/uae-emblem.png`.

---

## 11. Deployment and infrastructure setup

### 11.1 Active Directory (required)

1. Create a **read-only service account** (e.g. `svc_ocr`) — it only needs to read user objects.
2. Set `LDAP_BIND_USER` / `LDAP_BIND_PASSWORD`.
3. Prefer encrypted transport: `LDAP_SERVER=ldaps://dev.team.ae` **or** `LDAP_USE_STARTTLS=true`. Plain `ldap://` sends passwords in clear text, and DCs that enforce LDAP signing reject plain simple binds.
4. Check the startup log:
   ```
   SEC - Active Directory enabled=True server=ldap://dev.team.ae service_account=configured windows_sso=True keytab=/etc/krb5/http.keytab
   ```

### 11.2 Windows SSO (optional, for automatic login)

1. **Use a DNS name** for the API (browsers never send Kerberos tickets to `localhost` or an IP), e.g. `NEXT_PUBLIC_API_URL=http://ocr.dev.team.ae:8000`.
2. **Register the SPN and export a keytab** (on a domain controller):
   ```cmd
   setspn -S HTTP/ocr.dev.team.ae svc_ocr
   ktpass /princ HTTP/ocr.dev.team.ae@DEV.TEAM.AE /mapuser DEV\svc_ocr /pass * /crypto AES256-SHA1 /ptype KRB5_NT_PRINCIPAL /out http.keytab
   ```
3. Put `http.keytab` in `./secrets/krb5/` and uncomment the volume in `docker-compose.yml` (`KRB5_KTNAME=/etc/krb5/http.keytab`).
   *Windows host (no Docker):* no keytab — pyspnego uses SSPI; the SPN must belong to the account the API runs as.
4. **Trust the API host in browsers** (GPO): add it to the Internet Options **Local intranet** zone (Edge/Chrome), or `network.negotiate-auth.trusted-uris` (Firefox).
5. **Clock sync** with the DC (Kerberos allows ~5 minutes skew).
6. Set `CORS_ORIGINS` to the **exact** frontend origin(s), e.g. `http://ocr.dev.team.ae:3000`. Only these origins may call `/auth/sso`.

### 11.3 After upgrading

- Restart the backend so new defaults (`REQUIRE_AUTH=true`) apply.
- Sign in as `administrator` → **Users** → add AD users.

---

## 12. Security notes

- **Credentialed CORS is restricted** to `CORS_ORIGINS` on `/auth/sso`. Otherwise any website an employee visits could silently obtain a session token for them.
- **Realm check** on SSO: tickets from other realms / trusted domains are rejected even if the username matches.
- **No browser credential prompts**: failed SSO returns 401 without re-challenging.
- **Empty-password bind** is blocked (AD "unauthenticated bind").
- **LDAP injection**: all search input is escaped with `ldap3.utils.conv.escape_filter_chars`.
- **Least privilege**: the service account only needs read access.
- **`administrator` / `123456`** is weak by design (requested). Override `ADMIN_PASSWORD` in production; it is re-synced on every start.
- Tokens in query strings (`?api_key=`) can appear in server/proxy logs. This is existing backend behaviour, now used for downloads and previews.
- Every login decision is logged (`AUTH -`, `SSO -`, `USERS -` prefixes) for auditing.

---

## 13. Porting checklist for the main project

**Backend**

- [ ] Add `ldap3==2.9.1` and `pyspnego[kerberos]==0.11.2` (plus pinned `gssapi` / `krb5`) to requirements.
- [ ] Download wheels for offline installation (§4.4): Linux wheels built in Docker, Windows wheels with `pip download`; install with `--no-index --find-links`.
- [ ] Add `gcc` and `libkrb5-dev` to the Dockerfile `apt-get` list.
- [ ] Copy new files: `services/ldap_service.py`, `api/v1/users.py`, `core/sso_cors.py`.
- [ ] Apply modifications: `api/v1/auth.py`, `core/security.py` (`require_admin`), `core/config.py`, `core/network_guard.py` (`allow_host`), `models/models.py`, `schemas/schemas.py`, `main.py` (router + middleware).
- [ ] Add DB columns `users.auth_source`, `users.display_name` (automatic via `ensure_schema`, or SQL in §6).
- [ ] Update `.env` / `.env.example` / `docker-compose.yml` (§5).

**Frontend**

- [ ] Copy new files: `app/(app)/users/page.tsx`, `components/login-showcase.tsx`, `assets/uae-emblem.png`.
- [ ] Apply modifications: `lib/api.ts`, `lib/types.ts`, `lib/i18n.tsx`, `components/auth-guard.tsx`, `components/sidebar.tsx`, `components/document-viewer.tsx`, `app/login/page.tsx`, `app/globals.css`.
- [ ] Rebuild (`npm run build`) and redeploy the static export.

**Infrastructure**

- [ ] AD service account + `LDAP_BIND_*`.
- [ ] LDAPS or StartTLS.
- [ ] (SSO) SPN, keytab, DNS name, browser intranet-zone GPO, `CORS_ORIGINS`.

---

## 14. Testing

### 14.1 Automated checks performed

Run against a throwaway SQLite DB with ldap3's in-memory **MOCK_SYNC** AD server and FastAPI `TestClient` (the real `dev.team.ae` was not reachable from the development machine):

| Scenario | Expected | Result |
|---|---|---|
| `administrator` / `123456` | 200 | ✅ |
| `administrator` wrong password | 401 | ✅ |
| AD user not yet added | 401 | ✅ |
| AD search by name | results, `registered=false` | ✅ |
| Search returns disabled accounts | none | ✅ |
| Search without login | 401 | ✅ |
| Add user / add duplicate / add unknown / add disabled | 201 / 409 / 404 / 404 | ✅ |
| Login as added user (`jdoe`, `DEV\JDoe`) | 200 | ✅ |
| Wrong password / empty password | 401 / 401 | ✅ |
| User only in AD (not added) | 401 | ✅ |
| Non-admin calls `/users` | 403 | ✅ |
| Promote to admin | `is_admin=true` | ✅ |
| User deleted from AD then logs in | 401 | ✅ |
| Remove user → existing token | no longer authenticated | ✅ |
| Remove `administrator` | 400 | ✅ |
| SSO: no header | 401 + `Negotiate` challenge | ✅ |
| SSO: `jdoe@DEV.TEAM.AE` / `DEV\JDoe` | 200 | ✅ |
| SSO: foreign realm / AD-only / disabled / `administrator` / bad ticket / NTLM / bad base64 | 401, no challenge | ✅ |
| SSO CORS: trusted origin / foreign origin | origin echoed + credentials / no CORS headers | ✅ |
| `REQUIRE_AUTH` default: anonymous `/auth/me`, `/ocr` without token, with Bearer, with `?api_key=` | `auth_required=true`, 401, 200, 200 | ✅ |
| Frontend `tsc --noEmit` | no errors | ✅ |
| Login page screenshots (light, dark, 1280/1536/1920 px, reduced motion) | renders correctly | ✅ |

### 14.2 Manual tests to run in the target environment

1. Startup log shows `service_account=configured`.
2. Sign in as `administrator` → Users → search a real AD user → add.
3. Sign in as that user with their AD password.
4. Disable the user in AD → sign-in fails. Remove the user in the app → session ends.
5. (SSO) From a domain-joined PC with the host in the intranet zone, open the app → automatic login. Sign out → login page appears (no auto-login until the browser session ends).

---

## 15. Known limitations

- **NTLM** is not supported for SSO (only Kerberos). Browsers that fall back to NTLM go to the login page.
- SSO does not work via `localhost` or IP addresses (Kerberos requirement).
- Users added to the app are not automatically removed when deleted from AD; they simply can no longer sign in. Remove them from the Users page for a clean list.
- AD group-based roles are not implemented; the admin role is set per user in the app.
- The local `administrator` cannot use Windows SSO by design.
