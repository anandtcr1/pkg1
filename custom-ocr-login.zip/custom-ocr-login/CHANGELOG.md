# Change Log

Every change made to this project, recorded so it can be applied to the **office development environment**. Newest entries first.

**Baseline:** Active Directory login, Windows SSO, user management and the new login screen are fully documented in [AuthenticationChanges.md](AuthenticationChanges.md). Apply that first; the entries below come after it.

Each entry lists:

- **Why:** the reason for the change.
- **Files:** new (N), modified (M) and deleted (D) files.
- **Packages:** Python/npm packages added, removed or upgraded.
- **Config:** environment variables added or changed.
- **Database:** schema or data changes.
- **Apply in office:** the steps to bring the change across.
- **Verified:** how it was checked.

---

## 2026-10-17 — LoginUserManagementChanges.md: consolidated login & user-management guide

**Why:** To implement only the login and user-management changes in the offline development environment from one document showing the **final** state, instead of combining `AuthenticationChanges.md` with the later changelog entries.

**Files**

| | File | Change |
|---|---|---|
| N | `LoginUserManagementChanges.md` | Implementation guide: final rules, implementation order, packages and offline wheels, configuration, database (with SQL), API reference, file list, **complete source of every new file and of `auth.py`, `security.py`, `login/page.tsx`, `auth-guard.tsx`, `layout.tsx`**, exact code of every changed section (config, models, schemas, main, network guard, api.ts, types.ts, sidebar, document viewer, i18n EN+AR keys, CSS), deployment files, test user, verification checklist, troubleshooting. Code blocks were generated from the source files and checked to be identical. |
| M | `.env.example` | Stale comment `# AD. ADMIN_USERNAME above is the only exception (local password).` → `# AD. Local accounts (first-run administrator, ADMIN_PASSWORD seed) are the` / `# exception: they sign in with a local password.` |
| M | `backend/app/core/config.py` | Stale comment `# The local break-glass account (ADMIN_USERNAME) never goes to AD.` → `# Local accounts (first-run admin / ADMIN_PASSWORD seed) never go to AD.` |

**Packages:** none · **Config:** none (comments only) · **Database:** none

**Apply in office:** use `LoginUserManagementChanges.md` (it supersedes `AuthenticationChanges.md` where they differ). Copy `frontend/assets/uae-emblem.png` separately: it is a binary file and is not embedded in the document.

**Verified:** 43 code blocks, none empty; 83 English and 83 Arabic translation keys; all 11 "complete file" listings are identical to the files on disk; `config.py` compiles.

---

## 2026-10-17 — Users are disabled instead of deleted (with confirmation, re-enable)

**Why:** Deleting a user removed them permanently. Now the bin button on the Users page asks **"Do you want to disable the user?"** (Yes / No). **Yes** marks the user as disabled; nothing is deleted. An administrator can enable the user again at any time. Disabled users cannot sign in.

**Behaviour**

- **Disable:** bin button → modal "Disable user" / "Do you want to disable the user?" → **Yes** disables, **No** closes. The user stays in the list with a red **Disabled** badge and a dimmed row.
- **Enable:** disabled users show a green **Enable user** button (no confirmation).
- **Disabled users cannot sign in:**
  - Password login (local and AD) → `403 "This account is disabled. Contact the administrator."` (login page shows "Your account is disabled. Contact the administrator."). The message is only returned after the password was verified, so it reveals nothing to someone guessing passwords; a wrong password still returns the normal `401`.
  - Windows SSO → refused (falls back to the login page).
  - **Existing sessions stop working immediately** (tokens are checked against the users table on every request).
- Re-adding a disabled AD user from the search dialog returns `409 "User is already registered but disabled. Enable them instead."`
- **Rule change:** previously local accounts could not be changed at all on the Users page. Now the only protection is **your own account**: you cannot disable or change the role of yourself (`400 "You cannot change your own account."`; buttons are greyed out with a tooltip). This allows disabling local users such as `test1`, and the acting admin always stays an active admin, so nobody can lock everyone out.
- The hard-delete endpoint `DELETE /api/v1/users/{id}` was **removed** (returns `405`).

**Files**

| | File | Change |
|---|---|---|
| M | `backend/app/models/models.py` | New column `User.is_active = Column(Boolean, nullable=True, default=True)`; new property `User.enabled` (`is_active is not False`, so `NULL` = active) |
| M | `backend/app/core/security.py` | `_verify_credentials`: a token is only valid when the user exists **and** `user.enabled` |
| M | `backend/app/api/v1/auth.py` | New `backfill_user_flags(db)` (sets `is_active = TRUE` where `NULL`; called from `ensure_admin_once` on startup); new `_disabled()` (`403`); `login`: disabled check after successful local or AD password check; `/auth/sso`: refuses disabled users |
| M | `backend/app/api/v1/users.py` | `PATCH /users/{id}` now accepts `{"is_admin"?: bool, "is_active"?: bool}` (`422` if neither); refuses only the acting admin's own account; `DELETE /users/{id}` removed; add-user `409` message distinguishes disabled users; removed `is_local` / `Response` imports |
| M | `backend/app/schemas/schemas.py` | `UserOut.is_active: bool = True` (validator maps `NULL` → `True`); `UserUpdate` fields both optional: `is_admin: Optional[bool]`, `is_active: Optional[bool]` |
| M | `frontend/lib/api.ts` | Removed `removeUser()`; new `setUserActive(id, active)` (`PATCH {is_active}`) |
| M | `frontend/lib/types.ts` | `AppUser.is_active: boolean` |
| M | `frontend/app/(app)/users/page.tsx` | New **Status** column (Active / Disabled badge); disabled rows dimmed; bin button opens the confirmation modal (`Dialog`, Yes/No) instead of `window.confirm`; **Enable user** button (`UserCheck` icon) for disabled users; role and disable buttons disabled for the signed-in admin's own row (reads `/auth/me`); role button disabled for disabled users |
| M | `frontend/app/login/page.tsx` | Error message `auth.disabled` when the response mentions "disabled" |
| M | `frontend/lib/i18n.tsx` | Removed `users.remove`, `users.remove_confirm`, `users.removed`. Added (EN + AR): `users.active`, `users.disabled`, `users.disable`, `users.enable`, `users.disable_title` ("Disable user"), `users.disable_confirm` ("Do you want to disable the user?" / "هل تريد تعطيل المستخدم؟"), `users.disable_note`, `users.yes`, `users.no`, `users.disabled_ok`, `users.enabled_ok`, `users.self_note`, `auth.disabled` |

**Packages:** none · **Config:** none

**Database**

- New column `users.is_active BOOLEAN` (nullable). Added automatically on startup by `ensure_schema()`; existing rows are then set to `TRUE` by `backfill_user_flags()`. Manual SQL if needed:
  ```sql
  ALTER TABLE users ADD COLUMN is_active BOOLEAN;
  UPDATE users SET is_active = TRUE WHERE is_active IS NULL;
  ```
- **Test data (local dev database only, `backend/ocr.db`):** user **`test1`** / password **`123456`**: local account (`auth_source='local'`), standard user (`is_admin=false`), active, display name "Test User 1". Created with the app's own bcrypt hashing. **Status: created 2026-10-17 12:45.** Verified: login `test1` / `123456` → 200 (`is_admin=false`), session valid, wrong password → 401. Backups taken before changing the file: `backend/ocr.db.bak-20261017-122752`, `backend/ocr.db.bak-20261017-124559`.

  > **Note:** while *DB Browser for SQLite* (or any SQLite tool) has `ocr.db` open, the backend cannot start after this change (`database is locked` on `ALTER TABLE users ADD COLUMN is_active`). Close the database in the tool before starting the backend.

  For the office environment, create test users the same way (bcrypt hash), e.g. from `backend/`:
  ```bash
  python -c "from app.core.database import SessionLocal; from app.models import models; from app.core.security import hash_password; from app.models.models import User; db=SessionLocal(); db.add(User(username='test1', hashed_password=hash_password('123456'), is_admin=False, auth_source='local', display_name='Test User 1', is_active=True)); db.commit()"
  ```
  Run it after the backend has started once (so `is_active` exists). `test1` / `123456` is a weak test credential: do not create it in production.

**Apply in office**

1. Backend: apply the changes to `models.py`, `security.py`, `auth.py`, `users.py`, `schemas.py`; restart (the column is added and existing users are marked active automatically).
2. Frontend: apply the changes to `api.ts`, `types.ts`, `users/page.tsx`, `login/page.tsx`, `i18n.tsx`; rebuild (`npm run build`) and redeploy.
3. Anything that called `DELETE /api/v1/users/{id}` must use `PATCH /api/v1/users/{id}` with `{"is_active": false}` instead.
4. Optional: create test users as shown above (not in production).

**Verified** (FastAPI `TestClient`, fresh SQLite DB, mock AD):

| Scenario | Result |
|---|---|
| `test1` (local) and `jdoe` (AD) sign in while active | 200 / 200 |
| Disable `test1` | 200, `is_active=false` |
| `test1`'s existing session after disabling | no longer authenticated |
| `test1` login with correct / wrong password while disabled | 403 "This account is disabled…" / 401 |
| AD user `jdoe` login while disabled | 403 |
| Re-add disabled `jdoe` | 409 "…disabled. Enable them instead." |
| Users list keeps disabled users | `administrator` active, `jdoe` and `test1` disabled |
| Enable `test1`, then login | `is_active=true`, 200 |
| Admin disables own account / empty PATCH / `DELETE` | 400 / 422 / 405 |
| Promote local user `test1` | allowed |
| Frontend `tsc --noEmit` | passes |

The modal was not checked in a browser screenshot.

---

## 2026-10-17 — Fix: login page crash "Failed to execute 'insertBefore' on 'Node'"

**Why:** Clicking **Sign in** crashed the login page with:

```
Runtime NotFoundError: Failed to execute 'insertBefore' on 'Node': The node before
which the new node is to be inserted is not a child of this node.
app\login\page.tsx (151:23)
```

**Cause:** the browser's auto-translate (Chrome/Edge "Translate this page") replaces text nodes in the page with its own `<font>` elements. React still holds references to the original text nodes. When the button switches its icon (arrow → spinner), React inserts the new icon before a text node that is no longer in the page, and the render crashes. Browser extensions that rewrite page text can cause the same error.

**Fix**

1. Browser translation is disabled for the whole app. The app has its own English/Arabic switch, so translating it adds nothing and can break any page.
2. Button labels next to a switching icon are wrapped in their own `<span>`, so React inserts the icon next to a stable element even if something rewrites the text.

**Files**

| | File | Change |
|---|---|---|
| M | `frontend/app/layout.tsx` | `<html lang="en" suppressHydrationWarning>` → `<html lang="en" translate="no" className="notranslate" suppressHydrationWarning>`; `metadata.other = { google: "notranslate" }` (renders `<meta name="google" content="notranslate">`) |
| M | `frontend/app/login/page.tsx` | Sign-in button label: `{busy ? t("auth.submitting") : t("auth.submit")}` → `<span>{…}</span>` |
| M | `frontend/app/setup/page.tsx` | Create-administrator button label wrapped in `<span>` |
| M | `frontend/app/(app)/system-health/page.tsx` | Run-check button label wrapped in `<span>` |
| M | `frontend/app/(app)/lab/page.tsx` | Run-benchmark button label wrapped in `<span>` |

**Packages:** none · **Config:** none · **Database:** none

**Apply in office**

1. Make the edits above; rebuild (`npm run build`) and redeploy the frontend.
2. In the browser, reload the page. If Chrome/Edge still shows the page translated, choose **"Show original"** once in the translate bar.

**Verified:** `tsc --noEmit` passes; the served login page contains `<html lang="en" translate="no" class="notranslate">` and `<meta name="google" content="notranslate"/>`. The theme switch (adds the `dark` class) and the language switch (sets `lang` / `dir`) do not remove the no-translate markers. The crash itself was not reproduced here.

---

## 2026-10-16 — First-run setup: create the administrator when no users exist

**Why:** On a new installation with no users, nobody could sign in. Now, while the `users` table is empty, the web app shows a **"Create administrator"** screen with **User name**, **Password** and **Re-enter password**. After saving, the account is created and the user is signed in with it immediately.

**Behaviour changes** (supersede parts of `AuthenticationChanges.md` §2 and §5):

| Before | Now |
|---|---|
| `administrator` / `123456` created automatically on every start | **Not created by default.** Only created when `ADMIN_PASSWORD` is set (then re-synced on every start, as before). |
| Only the account named `ADMIN_USERNAME` used a local password | **Every local account** (`auth_source = "local"`, from the setup screen or the env seed) signs in with its local password. Everyone else still goes through Active Directory. |
| `ADMIN_PASSWORD` empty → random password printed in the log | Empty → no seed; the first-run screen is used instead. |

Rules for the setup screen:

- Available **only while no users exist**. Afterwards `POST /auth/setup` returns `409` and the page redirects to the login page.
- User name: 3-64 characters, letters, digits, `.`, `-`, `_`. Password: at least 6 characters. Both fields are checked in the browser and on the server.
- The created account is a **local administrator** (`auth_source="local"`, `is_admin=true`). It cannot be removed or demoted from the Users page, cannot sign in through Windows SSO, and cannot be unlocked with an AD password (`DEV\name` is refused).
- A server-side lock prevents two simultaneous first-run requests from both creating an administrator.
- Existing installations are unaffected: if any user already exists (for example the earlier `administrator`), the setup screen never appears and that account keeps working.

> **Security:** until the first administrator is created, anyone who can reach the web app can complete the setup. Create the administrator right after deployment, or set `ADMIN_PASSWORD` so an administrator exists from the first start.

**Files**

| | File | Change |
|---|---|---|
| M | `backend/app/api/v1/auth.py` | New `GET /auth/setup` (`{"setup_required": bool}`) and `POST /auth/setup` (`{"username", "password"}` → `201 {"username", "is_admin": true}`; `422` invalid input; `409` already done). New helpers `is_local(user)` and `setup_required(db)`; `SetupRequest` model; `USERNAME_RE`, `MIN_PASSWORD_LENGTH = 6`, `_setup_lock`. `ensure_admin` only seeds when `ADMIN_PASSWORD` is set (no random password any more; logs `ADMIN - no users yet …` when the DB is empty). `login`: any local account uses its local password; a local account reached through an AD-style name is refused. `/auth/sso`: refuses local accounts via `is_local(user)`. `/auth/me`: new field `setup_required`. Removed `is_local_admin` and the `secrets` import. |
| M | `backend/app/api/v1/users.py` | Imports `is_local` instead of `is_local_admin`. Add-user no longer has a special "administrator" check (duplicates still return `409`). Change role / remove refuse **any** local account (`is_local(user)`). |
| M | `backend/app/core/config.py` | `ADMIN_PASSWORD` default `"123456"` → `""`; comment updated. |
| M | `backend/app/main.py` | Startup log `admin_user=…` → `admin_seed=<name>` or `admin_seed=off (first-run setup)`. |
| M | `docker-compose.yml` | `ADMIN_PASSWORD: ${ADMIN_PASSWORD:-123456}` → `${ADMIN_PASSWORD:-}` (backend and worker). |
| M | `.env.example` | `ADMIN_PASSWORD=123456` → `ADMIN_PASSWORD=` with new explanation. |
| N | `frontend/app/setup/page.tsx` | First-run screen (same backdrop and centered card as login): User name, Password, Re-enter password, show/hide password, validation messages, "Create administrator". On success creates the account, signs in with it and opens the dashboard. Redirects to `/login` if setup is already done. |
| M | `frontend/components/auth-guard.tsx` | If `/auth/me` returns `setup_required` → redirect to `/setup` (before Windows SSO). |
| M | `frontend/app/login/page.tsx` | If `setup_required` → redirect to `/setup`. |
| M | `frontend/lib/api.ts` | `getSetupStatus()`, `createFirstAdmin(username, password)`. |
| M | `frontend/lib/types.ts` | `AuthMe.setup_required?: boolean`. |
| M | `frontend/lib/i18n.tsx` | New `setup.*` keys in English and Arabic: `title`, `subtitle`, `username` ("User name"), `password`, `confirm` ("Re-enter password"), `submit`, `submitting`, `mismatch`, `too_short`, `invalid_username`, `success`, `failed`, `note`. |
| M | `AuthenticationChanges.md` | Note in §2 pointing to this entry. |

**Packages:** none · **Database:** none (uses the existing `auth_source` column)

**Config**

| Variable | Old default | New default |
|---|---|---|
| `ADMIN_PASSWORD` | `123456` | *(empty)* → no seeded admin; first-run screen |

To keep the old behaviour (`administrator` / `123456` always present), set `ADMIN_PASSWORD=123456`.

**Apply in office**

1. Backend: apply the changes to `auth.py`, `users.py`, `config.py`, `main.py`.
2. Frontend: add `app/setup/page.tsx`; apply the changes to `auth-guard.tsx`, `login/page.tsx`, `api.ts`, `types.ts`, `i18n.tsx`; rebuild (`npm run build`) and redeploy.
3. Decide on `ADMIN_PASSWORD` in the office `.env` / compose: empty to use the setup screen, or a value to seed `ADMIN_USERNAME`.
4. Restart the backend. The startup log shows `admin_seed=…`; with an empty database it also shows `ADMIN - no users yet: open the web app to create the first administrator`.
5. Open the app: with no users you are sent to `/setup`. Create the administrator; you are signed in automatically.

**Verified** (FastAPI `TestClient`, fresh SQLite database):

| Scenario | Result |
|---|---|
| Empty DB: `/auth/me` and `/auth/setup` | `setup_required: true` |
| `administrator` / `123456` without `ADMIN_PASSWORD` | 401 (not seeded) |
| Invalid user name / password shorter than 6 | 422 / 422 |
| Create `itadmin` | 201 |
| Create again | 409; `setup_required: false` afterwards |
| Login `ITADMIN` (case-insensitive) / wrong password / `DEV\itadmin` | 200 admin / 401 / 401 |
| Users list | `itadmin`, `local`, admin |
| Delete own account | 400 |
| `ADMIN_PASSWORD=123456` set: `administrator` / `123456` | 200 (seed still works) |
| Frontend `tsc --noEmit` | passes |

The setup page was **not** checked in a browser screenshot: the dev servers here point at a backend that already has users, so `/setup` redirects to the login page.

---

## 2026-10-16 — Users dialog: search placeholder changed to "Name"

**Why:** The placeholder in the "Add user from Active Directory" search box showed sample values ("e.g. jdoe or John"). Replaced with a plain label.

**Files**

| | File | Change |
|---|---|---|
| M | `frontend/lib/i18n.tsx` | `users.dialog.placeholder`: English `"e.g. jdoe or John"` → `"Name"`; Arabic `"مثال: jdoe أو John"` → `"الاسم"` |

**Packages:** none · **Config:** none · **Database:** none

**Apply in office**

1. Make the same two edits in `frontend/lib/i18n.tsx` (search for `users.dialog.placeholder`).
2. Rebuild and redeploy the frontend (`npm run build`).

**Verified:** `tsc --noEmit` passes.

---

## 2026-10-16 — AuthenticationChanges.md: offline package download section

**Why:** The office environment installs Python packages offline.

**Files**

| | File | Change |
|---|---|---|
| M | `AuthenticationChanges.md` | New §4.4 "Downloading packages for offline installation" (Linux wheels built in Docker, Windows wheels via `pip download`, offline install commands); porting checklist (§13) updated |

**Packages:** none (documentation only) · **Config:** none · **Database:** none

**Apply in office:** use the updated `AuthenticationChanges.md`.

---

<!--
Template for new entries (copy above the newest entry):

## YYYY-MM-DD — Short title

**Why:**

**Files**

| | File | Change |
|---|---|---|
| N/M/D | `path` | what changed |

**Packages:** · **Config:** · **Database:**

**Apply in office**

1.

**Verified:**

---
-->
