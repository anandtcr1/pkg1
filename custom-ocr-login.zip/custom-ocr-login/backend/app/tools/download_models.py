"""Provision the LOCAL model repository.

Run this on a machine WITH Internet access, then copy the resulting directory
to MODELS_DIR on the air-gapped host. The running application never downloads.

    python -m app.tools.download_models --target ./models --engines tesseract,easyocr
    python -m app.tools.download_models --target ./models --engines tesseract --tesseract-source system

Also used at Docker build time to bake a seed copy into the image (best-effort).
"""

import argparse
import glob
import os
import shutil
import sys
import tempfile
import urllib.request
from pathlib import Path

from app.services.languages import all_languages, easyocr_langs

TESSDATA_REPOS = {
    "fast": "https://github.com/tesseract-ocr/tessdata_fast/raw/main/",
    "best": "https://github.com/tesseract-ocr/tessdata_best/raw/main/",
}


def _expand_codes(codes: list[str] | None) -> set[str] | None:
    """Expand pseudo-codes so a slim transfer still carries what they need."""
    if not codes:
        return None
    out = set(codes)
    if "auto" in out:
        out.add("en")
    if "mixed" in out:
        out.update(("ar", "en"))
    return out


def tessdata_files(codes: list[str] | None = None) -> tuple[str, ...]:
    """Every traineddata file the requested languages need (default: all) + osd."""
    selected = _expand_codes(codes)
    names = {"osd.traineddata"}
    for lang in all_languages():
        if selected is not None and lang.code not in selected:
            continue
        for code in lang.tesseract.split("+"):
            if code:
                names.add(f"{code}.traineddata")
    return tuple(sorted(names))


TESSDATA_FILES = tessdata_files()


def log(msg: str) -> None:
    print(f"[models] {msg}", flush=True)


# ---------------------------------------------------------------- tesseract


def provision_tesseract(target: Path, source: str, sets: list[str], codes: list[str] | None = None) -> None:
    root = target / "tesseract"
    root.mkdir(parents=True, exist_ok=True)
    wanted = tessdata_files(codes)
    if source == "system":
        candidates = glob.glob("/usr/share/tesseract-ocr/*/tessdata") + glob.glob("/usr/share/tessdata")
        if not candidates:
            raise FileNotFoundError("system tessdata directory not found")
        src = Path(candidates[0])
        for name in wanted:
            if (src / name).exists():
                shutil.copy2(src / name, root / name)
                log(f"tesseract: copied {name} from {src}")
        return
    for tess_set in sets:
        dest = root / tess_set
        dest.mkdir(parents=True, exist_ok=True)
        for name in wanted:
            url = TESSDATA_REPOS[tess_set] + name
            log(f"tesseract[{tess_set}]: downloading {name}")
            urllib.request.urlretrieve(url, dest / name)


# ---------------------------------------------------------------- easyocr


def provision_easyocr(target: Path, codes: list[str] | None = None) -> None:
    import easyocr

    selected = _expand_codes(codes)
    dest = target / "easyocr" / "models"
    dest.mkdir(parents=True, exist_ok=True)
    groups: list[tuple[str, ...]] = []
    for lang in all_languages():
        if selected is not None and lang.code not in selected:
            continue
        if lang.easyocr and lang.easyocr not in groups:
            groups.append(lang.easyocr)
    for langs in groups:
        log(f"easyocr: fetching weights for {list(langs)}")
        easyocr.Reader(
            list(langs),
            gpu=False,
            download_enabled=True,
            model_storage_directory=str(dest),
            user_network_directory=str(dest),
            verbose=False,
        )
    for f in sorted(dest.glob("*.pth")):
        log(f"easyocr: {f.name}")


# ---------------------------------------------------------------- qari

# QARI-OCR (Qwen2-VL-2B-Instruct Arabic fine-tunes) is installable ONLY from the
# official NAMAA-Space Hugging Face releases below; we never fetch it here. This
# provisioning step creates the expected directories and prints the exact files
# an operator must copy onto the air-gapped host under `models/qari/`.
QARI_SOURCES = {
    "v0.2": "https://huggingface.co/NAMAA-Space/Qari-OCR-0.2.2.1-VL-2B-Instruct",
    "v0.3": "https://huggingface.co/NAMAA-Space/Qari-OCR-v0.3-VL-2B-Instruct",
    "base": "https://huggingface.co/Qwen/Qwen2-VL-2B-Instruct",
}


def provision_qari(target: Path) -> None:
    root = target / "qari"
    (root / "v0.2").mkdir(parents=True, exist_ok=True)
    (root / "v0.3").mkdir(parents=True, exist_ok=True)
    (root / "base").mkdir(parents=True, exist_ok=True)
    log("QARI: no download performed (runtime downloads are always disabled).")
    log("Install offline — copy these files onto the target under MODELS_DIR/qari/")
    log("  v0.2/ (LoRA adapter) from " + QARI_SOURCES["v0.2"])
    log("     adapter_config.json, adapter_model.safetensors (~127 MB), tokenizer.* files")
    log("  base/ (required by v0.2) from " + QARI_SOURCES["base"])
    log("     config.json, model.safetensors (shards), tokenizer.* files, preprocessor_config.json")
    log("  v0.3/ (standalone) from " + QARI_SOURCES["v0.3"])
    log("     config.json, model.safetensors (~4.4 GB), tokenizer.* files, preprocessor_config.json")


# ---------------------------------------------------------------- wevisdoc

# WeVisDoc (Tencent Qwen3-VL-2B/4B page→Markdown parser) is installable ONLY from
# the official Tencent Hugging Face releases below; we never fetch it here, same as
# QARI. This creates the expected directory and prints the exact files an operator
# must copy onto the air-gapped host under `models/wevisdoc/`.
WEVISDOC_SOURCES = {
    "2B": "https://huggingface.co/tencent/WeVisDoc-2B",
    "4B": "https://huggingface.co/tencent/WeVisDoc-4B",
}


def provision_wevisdoc(target: Path, variant: str = "2B") -> None:
    root = target / "wevisdoc"
    root.mkdir(parents=True, exist_ok=True)
    chosen = WEVISDOC_SOURCES.get(variant, WEVISDOC_SOURCES["2B"])
    log("WeVisDoc: no download performed (runtime downloads are always disabled).")
    log("Install offline — copy ONE checkpoint onto the target under MODELS_DIR/wevisdoc/")
    log(f"  from {chosen}")
    log("     config.json (model_type must be 'qwen3_vl'), model*.safetensors (full weights),")
    log("     tokenizer_config.json, tokenizer.json, processor_config.json, ...")
    log("  A LoRA/PEFT adapter alone is NOT accepted (the engine needs full weights).")


# ---------------------------------------------------------------- paddle

# PaddleOCR 3.x inference models (official PaddleX "paddle3.0.0" tar packages).
# We never download at runtime; this prints the exact packages + layout an
# operator downloads once on a connected host and copies onto the air-gapped
# host under MODELS_DIR/paddle/.
# Official PaddleX "paddle3.0.0" inference tar packages. The CDN answers 200
# over plain HTTP, but some networks block its HTTPS/TLS front (HTTPS
# hangs/errors while the same file is fine over HTTP), so we always print the
# HTTP-equivalent URL as fallback.
PADDLE_HUB = "https://paddle-model-ecology.bj.bcebos.com/paddlex/official_inference_model/paddle3.0.0"
PADDLE_HUB_HTTP = "http://paddle-model-ecology.bj.bcebos.com/paddlex/official_inference_model/paddle3.0.0"
PADDLE_MODELS = {
    "det": ("PP-OCRv6_medium_det", "<models>/paddle/det"),
    "rec_latin": ("latin_PP-OCRv5_mobile_rec", "<models>/paddle/rec_latin"),
    "rec_arabic": ("arabic_PP-OCRv5_mobile_rec", "<models>/paddle/rec_arabic"),
}


def provision_paddle(target: Path) -> None:
    root = target / "paddle"
    for sub in ("det", "rec_latin", "rec_arabic"):
        (root / sub).mkdir(parents=True, exist_ok=True)
    log("PaddleOCR: no download performed (runtime downloads are always disabled).")
    log("Install offline — on a connected host download each package once, extract it,")
    log("and copy its files (inference.pdiparams + inference.json/yml + config.json) to:")
    for sub, (name, where) in PADDLE_MODELS.items():
        url = f"{PADDLE_HUB}/{name}_infer.tar"
        url_http = f"{PADDLE_HUB_HTTP}/{name}_infer.tar"
        log(f"  {name}")
        log(f"    {url}")
        log(f"    (HTTP fallback if TLS is blocked: {url_http})")
        log(f"    -> copy extracted files to {where.replace('<models>', str(root.parent))}")
    log("  rec_arabic is optional but recommended for Arabic/Farsi/Urdu docs.")


# ---------------------------------------------------------------- main


def main() -> int:
    parser = argparse.ArgumentParser(description="Provision the local OCR model repository.")
    parser.add_argument("--target", default="./models")
    parser.add_argument("--engines", default="tesseract,easyocr")
    parser.add_argument("--tesseract-source", choices=["github", "system"], default="github")
    parser.add_argument("--tesseract-sets", default="fast,best")
    parser.add_argument("--langs", default="",
        help="comma-separated canonical language codes to provision (default: every registry language). Applies to tesseract and easyocr; 'auto'/'mixed' pull in their required languages.",
    )
    parser.add_argument(
        "--wevisdoc-variant",
        choices=["2B", "4B"],
        default="2B",
        help="which WeVisDoc checkpoint to print install instructions for (never downloads)",
    )
    args = parser.parse_args()

    target = Path(args.target).resolve()
    target.mkdir(parents=True, exist_ok=True)
    engines = [e.strip() for e in args.engines.split(",") if e.strip()]
    langs = [c.strip() for c in args.langs.split(",") if c.strip()] or None
    failures: list[str] = []

    for engine in engines:
        try:
            if engine == "tesseract":
                provision_tesseract(target, args.tesseract_source, [s.strip() for s in args.tesseract_sets.split(",")], langs)
            elif engine == "easyocr":
                provision_easyocr(target, langs)
            elif engine == "qari":
                provision_qari(target)
            elif engine == "wevisdoc":
                provision_wevisdoc(target, args.wevisdoc_variant)
            elif engine == "paddle":
                provision_paddle(target)
            else:
                log(f"unknown engine '{engine}', skipping")
        except Exception as exc:  # noqa: BLE001 — continue with the next engine
            failures.append(f"{engine}: {type(exc).__name__}: {str(exc)[:160]}")
            log(f"{engine}: FAILED — {failures[-1]}")

    for reserved in ("qari", "qwen", "wevisdoc", "paddle"):
        (target / reserved).mkdir(exist_ok=True)

    log(f"done → {target}")
    for path in sorted(target.rglob("*")):
        if path.is_file():
            log(f"  {path.relative_to(target)}  ({path.stat().st_size // 1024} KB)")
    if failures:
        log("some engines failed: " + "; ".join(failures))
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
