"""Container entrypoint: seed local models from the image (offline copy), then exec the command.

Usage: python -m app.entrypoint <command...>
"""

import os
import sys

from app.core.config import settings
from app.services.model_repository import seed_from

SEED_ROOT = os.environ.get("MODELS_SEED_DIR", "/opt/models-seed")


def main(argv: list[str]) -> None:
    os.makedirs(settings.models_path, exist_ok=True)
    for action in seed_from(SEED_ROOT):
        print(f"[entrypoint] {action}", flush=True)
    if not argv:
        print("[entrypoint] no command given", file=sys.stderr)
        sys.exit(2)
    os.execvp(argv[0], argv)


if __name__ == "__main__":
    main(sys.argv[1:])
