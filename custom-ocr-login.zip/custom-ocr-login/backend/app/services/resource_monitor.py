"""Per-job resource sampling (peak RSS, average CPU) with a lightweight thread."""

import threading
import time

import psutil


class ResourceSampler:
    def __init__(self, interval: float = 0.5) -> None:
        self.interval = interval
        self.peak_rss_mb = 0.0
        self.cpu_samples: list[float] = []
        self.duration = 0.0
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._proc = psutil.Process()
        self._started = 0.0

    def _sample(self) -> None:
        try:
            rss = self._proc.memory_info().rss / (1024 * 1024)
            self.peak_rss_mb = max(self.peak_rss_mb, rss)
            self.cpu_samples.append(self._proc.cpu_percent(interval=None))
        except psutil.Error:
            pass

    def _run(self) -> None:
        while not self._stop.wait(self.interval):
            self._sample()

    def __enter__(self) -> "ResourceSampler":
        self._started = time.perf_counter()
        self._proc.cpu_percent(interval=None)  # prime
        self._sample()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        return self

    def __exit__(self, *exc) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=2)
        self._sample()
        self.duration = round(time.perf_counter() - self._started, 3)

    @property
    def avg_cpu_percent(self) -> float:
        valid = [c for c in self.cpu_samples if c is not None]
        return round(sum(valid) / len(valid), 1) if valid else 0.0
