"""Active Directory lookups and password verification (ldap3, pure Python).

Flow used everywhere:
  1. bind with the read-only service account (LDAP_BIND_USER / LDAP_BIND_PASSWORD)
  2. search the directory (user picker, or resolve a login name to its DN)
  3. for logins, re-bind as the user's DN with the supplied password — AD decides.

Disabled AD accounts are filtered out of every search, so they can neither be
added nor sign in.
"""

import logging
from dataclasses import dataclass
from typing import Optional
from urllib.parse import urlparse

from ldap3 import DSA, SIMPLE, SUBTREE, Connection, Server
from ldap3.core.exceptions import LDAPException
from ldap3.utils.conv import escape_filter_chars

from app.core import network_guard
from app.core.config import settings

logger = logging.getLogger("ocr.ldap")

# Enabled AD user accounts only (bit 2 of userAccountControl = ACCOUNTDISABLE).
_USER_FILTER = "(&(objectCategory=person)(objectClass=user)(!(userAccountControl:1.2.840.113556.1.4.803:=2)))"
_ATTRIBUTES = ["sAMAccountName", "userPrincipalName", "displayName", "mail", "department", "title"]

_base_dn_cache: Optional[str] = None


class LdapError(Exception):
    """Directory unreachable or misconfigured (not a wrong password)."""


@dataclass
class LdapUser:
    username: str  # sAMAccountName — the login name stored in our DB
    dn: str
    display_name: Optional[str] = None
    email: Optional[str] = None
    upn: Optional[str] = None
    department: Optional[str] = None
    title: Optional[str] = None


def normalize_username(raw: str) -> str:
    """Accept 'jdoe', 'DEV\\jdoe' or 'jdoe@dev.team.ae' and return 'jdoe'."""
    name = (raw or "").strip()
    if "\\" in name:
        name = name.split("\\", 1)[1]
    if "@" in name:
        name = name.split("@", 1)[0]
    return name.strip()


def _server() -> Server:
    host = urlparse(settings.LDAP_SERVER).hostname or settings.LDAP_SERVER
    # The offline guard blocks public IPs; the DC is an explicitly trusted host.
    network_guard.allow_host(host)
    return Server(settings.LDAP_SERVER, get_info=DSA, connect_timeout=settings.LDAP_TIMEOUT_S)


def _bind(server: Server, user: str, password: str) -> Optional[Connection]:
    """Return a bound connection, None on bad credentials, LdapError when unreachable."""
    conn = Connection(
        server,
        user=user,
        password=password,
        authentication=SIMPLE,
        receive_timeout=settings.LDAP_TIMEOUT_S,
        raise_exceptions=False,
    )
    try:
        conn.open()
        if settings.LDAP_USE_STARTTLS:
            conn.start_tls()
        if conn.bind():
            return conn
    except (LDAPException, OSError) as exc:
        conn.unbind()
        raise LdapError(f"Active Directory is unreachable ({settings.LDAP_SERVER}): {exc}") from exc
    conn.unbind()
    return None


def _service_connection() -> Connection:
    if not settings.LDAP_ENABLED:
        raise LdapError("Active Directory integration is disabled (LDAP_ENABLED=false).")
    if not settings.LDAP_BIND_USER or not settings.LDAP_BIND_PASSWORD:
        raise LdapError("LDAP_BIND_USER / LDAP_BIND_PASSWORD are not configured.")
    conn = _bind(_server(), settings.LDAP_BIND_USER, settings.LDAP_BIND_PASSWORD)
    if conn is None:
        raise LdapError("The LDAP service account was rejected by Active Directory.")
    return conn


def _base_dn(conn: Connection) -> str:
    global _base_dn_cache
    if settings.LDAP_BASE_DN:
        return settings.LDAP_BASE_DN
    if _base_dn_cache is None:
        info = conn.server.info
        values = info.other.get("defaultNamingContext") if info is not None else None
        if not values:
            raise LdapError("Could not read defaultNamingContext from AD; set LDAP_BASE_DN.")
        _base_dn_cache = values[0]
    return _base_dn_cache


def directory_domains() -> set[str]:
    """Kerberos realm + NetBIOS name implied by the base DN (DC=dev,DC=team,DC=ae -> DEV.TEAM.AE, DEV)."""
    base = settings.LDAP_BASE_DN or _base_dn_cache
    if not base:
        conn = _service_connection()
        try:
            base = _base_dn(conn)
        finally:
            conn.unbind()
    labels = [part.split("=", 1)[1] for part in base.split(",") if part.strip().upper().startswith("DC=")]
    if not labels:
        return set()
    return {".".join(labels).upper(), labels[0].upper()}


def _first(attrs: dict, name: str) -> Optional[str]:
    value = attrs.get(name)
    if isinstance(value, list):
        value = value[0] if value else None
    return str(value) if value else None


def _search(conn: Connection, condition: str, limit: int) -> list[LdapUser]:
    try:
        ok = conn.search(
            _base_dn(conn),
            f"(&{_USER_FILTER}{condition})",
            search_scope=SUBTREE,
            attributes=_ATTRIBUTES,
            size_limit=limit,
        )
    except (LDAPException, OSError) as exc:
        raise LdapError(f"Active Directory search failed: {exc}") from exc
    # sizeLimitExceeded still returns the first `limit` entries — that's fine.
    if not ok and conn.result.get("result") not in (0, 4):
        raise LdapError(f"Active Directory search failed: {conn.result.get('description')}")
    users = []
    for entry in conn.response or []:
        if entry.get("type") != "searchResEntry":
            continue  # skip referrals
        attrs = entry["attributes"]
        username = _first(attrs, "sAMAccountName")
        if not username:
            continue
        users.append(
            LdapUser(
                username=username,
                dn=entry["dn"],
                display_name=_first(attrs, "displayName"),
                email=_first(attrs, "mail"),
                upn=_first(attrs, "userPrincipalName"),
                department=_first(attrs, "department"),
                title=_first(attrs, "title"),
            )
        )
    return users


def search_users(query: str, limit: int = 25) -> list[LdapUser]:
    """Directory picker: match login name, display name, e-mail or first/last name."""
    q = escape_filter_chars(query.strip())
    if not q:
        return []
    condition = (
        f"(|(sAMAccountName=*{q}*)(displayName=*{q}*)(mail=*{q}*)"
        f"(userPrincipalName={q}*)(givenName={q}*)(sn={q}*))"
    )
    conn = _service_connection()
    try:
        return _search(conn, condition, limit)
    finally:
        conn.unbind()


def find_user(username: str) -> Optional[LdapUser]:
    """Exact lookup by login name (sAMAccountName). None = not in AD or disabled."""
    name = escape_filter_chars(normalize_username(username))
    if not name:
        return None
    conn = _service_connection()
    try:
        found = _search(conn, f"(sAMAccountName={name})", 2)
    finally:
        conn.unbind()
    return found[0] if len(found) == 1 else None


def authenticate(username: str, password: str) -> Optional[LdapUser]:
    """Verify the password against AD. None = unknown/disabled user or wrong password."""
    # An empty password would be an "unauthenticated bind" that AD reports as
    # successful — never let it through.
    if not password:
        return None
    user = find_user(username)
    if user is None:
        return None
    conn = _bind(_server(), user.dn, password)
    if conn is None:
        return None
    conn.unbind()
    return user
