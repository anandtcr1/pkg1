"""Centralized LOCAL model repository.

Layout (MODELS_DIR, default ./models — /models in Docker):

  tesseract/            ara.traineddata eng.traineddata osd.traineddata   (flat = default set)
  tesseract/fast/       optional tessdata_fast set  (Speed Mode)
  tesseract/best/       optional tessdata_best set  (Accuracy Mode)
  easyocr/models/       craft_mlt_25k.pth + recognition weights (english_g2.pth, arabic.pth ...)
  qari/                 QARI-OCR (Qwen2-VL-2B fine-tunes, official NAMAA-Space releases)
    v0.2/               LoRA adapter (adapter_config.json + adapter_model.safetensors + tokenizer files)
    v0.3/               standalone checkpoint (config.json + model.safetensors + tokenizer files)
    base/               local Qwen2-VL-2B base required by the v0.2 adapter (config.json + weights <-> QARI_BASE_MODEL_DIR)
  wevisdoc/             Tencent WeVisDoc (Qwen3-VL-2B/4B page→Markdown parser), one checkpoint here:
                        config.json + model*.safetensors + tokenizer files (<-> WEVISDOC_MODEL_DIR)
  paddle/               PaddleOCR 3.x inference models (paddle3.0.0 format), local-only:
    det/                detection engine (inference.pdiparams + inference.json)
    rec_latin/          Latin recognizer (latin_PP-OCRv5_mobile_rec)
    rec_arabic/         Arabic recognizer (arabic_PP-OCRv5_mobile_rec)
  qwen/                 reserved

Nothing in this module ever downloads. Missing models are reported with the
exact path where they are expected.
"""

import os
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from app.core.config import settings

TESSERACT_REQUIRED = ("ara.traineddata", "eng.traineddata")
TESSERACT_OPTIONAL = ("osd.traineddata",)
EASYOCR_DETECTOR = "craft_mlt_25k.pth"


def models_root() -> Path:
    return Path(settings.models_path)


def engine_dir(engine: str) -> Path:
    mapping = {
        "tesseract": "tesseract",
        "easyocr": os.path.join("easyocr", "models"),
        "qari": "qari",
        "wevisdoc": "wevisdoc",
        "paddle": "paddle",
        "qwen": "qwen",
    }
    return models_root() / mapping.get(engine, engine)


# ---------------------------------------------------------------- Tesseract


def _has_tessdata(directory: Path) -> bool:
    return all((directory / f).exists() for f in TESSERACT_REQUIRED)


def tessdata_dir(mode: Optional[str] = None) -> Path:
    """Pick tessdata for Speed/Accuracy mode.

    speed    → fast/  → (flat root) → best/
    accuracy → best/  → (flat root) → fast/
    """
    root = engine_dir("tesseract")
    wanted = (mode or settings.TESSERACT_MODE or "speed").strip().lower()
    accuracy = wanted in ("accuracy", "best", "high")
    order = [root / "best", root, root / "fast"] if accuracy else [root / "fast", root, root / "best"]
    for candidate in order:
        if _has_tessdata(candidate):
            return candidate
    return root


def tesseract_config(mode: Optional[str] = None) -> str:
    return f'--tessdata-dir "{tessdata_dir(mode)}"'


@dataclass
class RepoCheck:
    ok: bool
    path: str
    reason: Optional[str] = None


def check_tesseract(mode: Optional[str] = None) -> RepoCheck:
    directory = tessdata_dir(mode)
    missing = [f for f in TESSERACT_REQUIRED if not (directory / f).exists()]
    if missing:
        return RepoCheck(False, str(directory), f"Missing traineddata: {', '.join(missing)}")
    return RepoCheck(True, str(directory))


# ---------------------------------------------------------------- EasyOCR


def check_easyocr() -> RepoCheck:
    directory = engine_dir("easyocr")
    if not (directory / EASYOCR_DETECTOR).exists():
        return RepoCheck(False, str(directory), f"Missing detector weights: {EASYOCR_DETECTOR}")
    recognizers = [p for p in directory.glob("*.pth") if p.name != EASYOCR_DETECTOR]
    if not recognizers:
        return RepoCheck(False, str(directory), "Missing recognition weights (e.g. english_g2.pth, arabic.pth)")
    return RepoCheck(True, str(directory))


# ---------------------------------------------------------------- QARI (Qwen2-VL)

# QARI v0.2 = LoRA adapter (NAMAA-Space/Qari-OCR-0.2.2.1-VL-2B-Instruct) loaded on a
# local Qwen2-VL-2B base. QARI v0.3 = standalone fine-tune (Qari-OCR-v0.3-VL-2B-Instruct).

QARI_VERSIONS = ("v0.2", "v0.3")


def qari_dir(version: str = "") -> Path:
    root = Path(settings.qari_model_dir)
    return root / version if version else root


def qari_base_dir() -> Path:
    return Path(settings.qari_base_model_dir)


def _is_full_model(directory: Path) -> bool:
    """A standalone transformers checkpoint (config.json + weights)."""
    if not (directory / "config.json").is_file():
        return False
    weights = list(directory.glob("model*.safetensors")) + list(directory.glob("pytorch_model*.bin"))
    return bool(weights)


def _is_lora_adapter(directory: Path) -> bool:
    """A PEFT LoRA adapter (adapter_config.json + adapter weights)."""
    if not (directory / "adapter_config.json").is_file():
        return False
    return (directory / "adapter_model.safetensors").is_file() or (directory / "adapter_model.bin").is_file()


def _base_available() -> bool:
    """QARI v0.2 needs a local Qwen2-VL-2B base model (QARI_BASE_MODEL_DIR)."""
    return _is_full_model(qari_base_dir())


def check_qari(version: Optional[str] = None) -> RepoCheck:
    """Readiness for one QARI version. Ok = full model, or LoRA adapter + local base."""
    versions = [version] if version else list(QARI_VERSIONS)
    for v in versions:
        directory = qari_dir(v)
        if _is_full_model(directory):
            return RepoCheck(True, str(directory))
        if _is_lora_adapter(directory):
            if _base_available():
                return RepoCheck(True, str(directory), reason="LoRA adapter (requires local base)")
            return RepoCheck(
                False,
                str(directory),
                f"LoRA adapter found but its local Qwen2-VL-2B base is missing (expected under {qari_base_dir()})",
            )
        return RepoCheck(
            False,
            str(directory),
            f"No QARI v{v} model found. Expected a standalone transformers checkpoint "
            "(config.json + model.safetensors) or a LoRA adapter (adapter_config.json + adapter_model.safetensors).",
        )
    return RepoCheck(False, str(qari_dir()), "No QARI versions configured")


def qari_ready_versions() -> list[str]:
    """Download-free scan of which QARI versions can run locally. Never downloads."""
    ready = [v for v in QARI_VERSIONS if check_qari(v).ok]
    if _is_lora_adapter(qari_dir("v0.2")) and not _base_available():
        ready = [v for v in ready if v != "v0.2"]
    return ready


# ---------------------------------------------------------------- WeVisDoc (Qwen3-VL)

WEVISDOC_MODEL_TYPES = ("qwen3_vl", "qwen3-vl")


def wevisdoc_dir() -> Path:
    return Path(settings.wevisdoc_model_dir)


def wevisdoc_variant(directory: Optional[Path] = None) -> str:
    """Best-effort 2B/4B label from the checkpoint config (never downloads)."""
    cfg = (directory or wevisdoc_dir()) / "config.json"
    try:
        import json

        data = json.loads(cfg.read_text(encoding="utf-8"))
    except Exception:
        return ""
    name = str(data.get("_name_or_path") or data.get("name_or_path") or "")
    for token in ("4B", "4b", "2B", "2b"):
        if token in name:
            return "2B" if "2" in token else "4B"
    # Qwen3-VL configs nest the text LM under text_config; hidden_size maps to the
    # release size (2B=2048, 4B=2560 verified against the official Tencent repos).
    hidden = (data.get("text_config") or {}).get("hidden_size")
    if hidden == 2560:
        return "4B"
    if hidden == 2048:
        return "2B"
    return ""


def _wevisdoc_ok(directory: Path) -> tuple[bool, Optional[str]]:
    """Weights + config present AND the checkpoint is a Qwen3-VL document parser."""
    if not (directory / "config.json").is_file():
        return False, "No config.json found. Expected a local WeVisDoc checkpoint (config.json + model.safetensors)."
    weights = list(directory.glob("model*.safetensors")) + list(directory.glob("pytorch_model*.bin"))
    if not weights:
        return False, "No model weights found (.safetensors). Expected a full WeVisDoc checkpoint, not an adapter."
    import json

    try:
        model_type = json.loads((directory / "config.json").read_text(encoding="utf-8")).get("model_type") or ""
    except Exception as exc:
        return False, f"config.json could not be read: {type(exc).__name__}: {str(exc)[:120]}"
    if model_type not in WEVISDOC_MODEL_TYPES:
        return False, f"config.json says model_type='{model_type}', expected one of qwen3_vl WeVisDoc checkpoints."
    return True, None


def check_wevisdoc() -> RepoCheck:
    directory = wevisdoc_dir()
    ok, reason = _wevisdoc_ok(directory)
    return RepoCheck(ok, str(directory), reason)


# ---------------------------------------------------------------- PaddleOCR (local inference models)

# PaddleX "paddle3.0.0" inference format: inference.pdiparams (weights) plus a
# model file (inference.json under PIR, or legacy inference.pdmodel). Recognizer
# dirs typically also carry a config.json. Models are passed to PaddleOCR by
# explicit directory so nothing is ever resolved from PaddleX's model hub.

PADDLE_DET_NAME = "PP-OCRv6_medium_det"
PADDLE_REC_LATIN_NAME = "latin_PP-OCRv5_mobile_rec"
PADDLE_REC_ARABIC_NAME = "arabic_PP-OCRv5_mobile_rec"


def paddle_dir() -> Path:
    return Path(settings.paddle_dir)


def paddle_rec_dir(sub: str = "") -> Path:
    root = paddle_dir()
    return root / sub if sub else root


def _paddle_inference_ok(directory: Path) -> bool:
    if not (directory / "inference.pdiparams").is_file():
        return False
    return (directory / "inference.json").is_file() or (directory / "inference.pdmodel").is_file()


def check_paddle() -> RepoCheck:
    """Readiness of the local PaddleOCR models. Requires det + at least one
    recognizer (Latin). Arabic docs degrade until rec_arabic is installed, which
    is reported as READY with a reason rather than a hard failure — Latin is the
    baseline and must always work once det + rec_latin exist."""
    root = paddle_dir()
    det = root / "det"
    if not _paddle_inference_ok(det):
        return RepoCheck(
            False,
            str(root),
            f"Detection engine missing (expected {det}\\inference.pdiparams + inference.json). "
            f"Provision it with python -m app.tools.download_models --engines paddle, or copy "
            f"the {PADDLE_DET_NAME} infer package locally.",
        )
    missing = [sub for sub in ("rec_latin", "rec_arabic") if not _paddle_inference_ok(root / sub)]
    if "rec_latin" in missing:
        return RepoCheck(
            False,
            str(root),
            f"Latin recognizer missing (expected {root / 'rec_latin'}). Required for English and Latin-script docs.",
        )
    if "rec_arabic" in missing:
        return RepoCheck(True, str(root), reason="rec_arabic missing — Arabic/Farsi/Urdu will be unavailable until installed")
    return RepoCheck(True, str(root))


# ---------------------------------------------------------------- Storage / disk


def dir_size(path: str) -> int:
    total = 0
    if not os.path.isdir(path):
        return 0
    for root, _dirs, files in os.walk(path):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    return total


def disk_free_mb(path: str) -> float:
    target = path if os.path.exists(path) else os.path.dirname(os.path.abspath(path)) or "."
    usage = shutil.disk_usage(target)
    return usage.free / (1024 * 1024)


def storage_report() -> dict:
    storage = os.path.abspath(settings.STORAGE_PATH)
    areas = {
        "documents": os.path.join(storage, "uploads"),
        "ocr_outputs": os.path.join(storage, "processed"),
        "exports": os.path.join(storage, "exports"),
        "temp": os.path.join(storage, "tmp"),
        "logs": settings.logs_path,
        "models": settings.models_path,
    }
    usage = shutil.disk_usage(storage if os.path.exists(storage) else ".")
    return {
        "areas": [{"name": name, "path": path, "bytes": dir_size(path)} for name, path in areas.items()],
        "disk_total_bytes": usage.total,
        "disk_free_bytes": usage.free,
    }


def cleanup(targets: list[str]) -> dict:
    """Delete ONLY application-owned temporary data. Never touches OS folders."""
    storage = os.path.abspath(settings.STORAGE_PATH)
    freed = 0
    done: list[str] = []
    for target in targets:
        if target == "temp":
            tmp = os.path.join(storage, "tmp")
            freed += dir_size(tmp)
            shutil.rmtree(tmp, ignore_errors=True)
            os.makedirs(tmp, exist_ok=True)
            processed = os.path.join(storage, "processed")
            if os.path.isdir(processed):
                for job_dir in os.listdir(processed):
                    raw = os.path.join(processed, job_dir, "raw")
                    if os.path.isdir(raw):
                        freed += dir_size(raw)
                        shutil.rmtree(raw, ignore_errors=True)
            done.append("temp")
        elif target == "exports":
            exports = os.path.join(storage, "exports")
            freed += dir_size(exports)
            shutil.rmtree(exports, ignore_errors=True)
            os.makedirs(exports, exist_ok=True)
            done.append("exports")
        elif target == "logs":
            logs = settings.logs_path
            for f in os.listdir(logs) if os.path.isdir(logs) else []:
                if f.endswith(".log") and "." in f[:-4]:  # rotated backups only (ocr_jobs.log.1 ...)
                    p = os.path.join(logs, f)
                    freed += os.path.getsize(p)
                    os.remove(p)
            done.append("logs")
    return {"cleaned": done, "freed_bytes": freed}


# ---------------------------------------------------------------- Seeding (container start)


def seed_from(seed_root: str) -> list[str]:
    """Copy models baked into the image into MODELS_DIR when they are absent.

    Local copy only — no network. Used by the container entrypoint so a fresh
    models volume starts populated with whatever the image build could fetch.
    """
    actions: list[str] = []
    seed = Path(seed_root)
    if not seed.is_dir():
        return actions
    root = models_root()
    for engine in ("tesseract", "easyocr"):
        src = seed / engine
        if not src.is_dir():
            continue
        dst = engine_dir(engine) if engine == "easyocr" else root / engine
        # Some producers write weights under <seed>/<engine>/models/ (easyocr's
        # own convention). Flatten that inner dir so the copy matches the
        # runtime layout expected by engine_dir().
        inner = src / "models"
        source = inner if inner.is_dir() else src
        added = 0
        for file in source.rglob("*"):
            if not file.is_file():
                continue
            relative = file.relative_to(source)
            target_file = dst / relative
            if target_file.exists():
                continue  # never overwrite runtime-provisioned models
            target_file.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(file, target_file)
            added += 1
        if added:
            actions.append(f"seeded {engine} -> {dst} ({added} files)")
    for reserved in ("qari", "qwen", "wevisdoc", "paddle"):
        (root / reserved).mkdir(parents=True, exist_ok=True)
    return actions
