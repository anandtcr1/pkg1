"""OCR evaluation metrics. CER / WER are the primary metrics; confidence is NOT accuracy."""

import re
import unicodedata

_TASHKEEL = re.compile(r"[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u0640]")


def strip_diacritics(text: str) -> str:
    """Remove Arabic tashkeel + tatweel."""
    return _TASHKEEL.sub("", text or "")


def normalize(text: str, *, ignore_diacritics: bool = False) -> str:
    text = unicodedata.normalize("NFC", text or "")
    if ignore_diacritics:
        text = strip_diacritics(text)
    return " ".join(text.split())


def levenshtein(a: list | str, b: list | str) -> int:
    if a == b:
        return 0
    if not a:
        return len(b)
    if not b:
        return len(a)
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, start=1):
        cur = [i]
        for j, cb in enumerate(b, start=1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


def cer(reference: str, hypothesis: str, *, ignore_diacritics: bool = False) -> float:
    ref = normalize(reference, ignore_diacritics=ignore_diacritics)
    hyp = normalize(hypothesis, ignore_diacritics=ignore_diacritics)
    if not ref:
        return 0.0 if not hyp else 1.0
    return round(levenshtein(ref, hyp) / len(ref), 4)


def wer(reference: str, hypothesis: str, *, ignore_diacritics: bool = False) -> float:
    ref = normalize(reference, ignore_diacritics=ignore_diacritics).split()
    hyp = normalize(hypothesis, ignore_diacritics=ignore_diacritics).split()
    if not ref:
        return 0.0 if not hyp else 1.0
    return round(levenshtein(ref, hyp) / len(ref), 4)


def evaluate(reference: str, hypothesis: str) -> dict:
    return {
        "cer": cer(reference, hypothesis),
        "wer": wer(reference, hypothesis),
        "cer_no_diacritics": cer(reference, hypothesis, ignore_diacritics=True),
        "wer_no_diacritics": wer(reference, hypothesis, ignore_diacritics=True),
        "reference_chars": len(normalize(reference)),
        "reference_words": len(normalize(reference).split()),
    }
