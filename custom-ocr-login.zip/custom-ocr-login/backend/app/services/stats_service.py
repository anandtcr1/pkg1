"""Dashboard statistics — always computed from the database, never hardcoded."""

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.models.models import OCRCorrection, OCRJob, OCRPage


def overview(db: Session) -> dict:
    jobs = db.query(OCRJob).filter(OCRJob.status == "completed")
    documents_processed = jobs.count()
    pages_processed = (
        db.query(func.coalesce(func.sum(OCRJob.page_count), 0))
        .filter(OCRJob.status == "completed")
        .scalar()
        or 0
    )
    avg_conf = (
        db.query(func.avg(OCRJob.confidence))
        .filter(OCRJob.status == "completed", OCRJob.confidence.isnot(None))
        .scalar()
    )
    avg_time = (
        db.query(func.avg(OCRJob.processing_time)).filter(OCRJob.status == "completed").scalar() or 0.0
    )
    total_corrections = db.query(OCRCorrection).count()
    failed_jobs = db.query(OCRJob).filter(OCRJob.status == "failed").count()
    total_tokens = (
        db.query(func.coalesce(func.sum(OCRJob.tokens_processed), 0))
        .filter(OCRJob.status == "completed")
        .scalar()
        or 0
    )

    # Verified accuracy exists ONLY where ground truth produced a CER. Never derived from confidence.
    verified_rows = db.query(OCRJob.verified_cer).filter(OCRJob.verified_cer.isnot(None)).all()
    verified_samples = len(verified_rows)
    verified_accuracy = (
        round(max(0.0, 1.0 - sum(float(v) for (v,) in verified_rows) / verified_samples), 4)
        if verified_samples
        else None
    )
    return {
        "documents_processed": int(documents_processed),
        "pages_processed": int(pages_processed),
        "average_confidence": round(float(avg_conf), 4) if avg_conf is not None else None,
        "verified_accuracy": verified_accuracy,
        "verified_samples": verified_samples,
        "average_processing_time": round(float(avg_time), 2),
        "failed_jobs": int(failed_jobs),
        "total_corrections": int(total_corrections),
        "total_tokens_processed": int(total_tokens),
    }


def charts(db: Session) -> dict:
    day = func.date(OCRJob.created_at)

    requests_per_day = [
        {"date": str(d), "count": int(c)}
        for d, c in db.query(day, func.count(OCRJob.id)).group_by(day).order_by(day).all()
        if d is not None
    ]

    confidence_per_day = [
        {"date": str(d), "confidence": round(float(v), 4), "documents": int(c)}
        for d, v, c in db.query(day, func.avg(OCRJob.confidence), func.count(OCRJob.id))
        .filter(OCRJob.status == "completed")
        .group_by(day)
        .order_by(day)
        .all()
        if d is not None and v is not None
    ]

    language_distribution = [
        {"language": lang or "unknown", "count": int(c)}
        for lang, c in db.query(OCRJob.language, func.count(OCRJob.id))
        .filter(OCRJob.status == "completed")
        .group_by(OCRJob.language)
        .all()
    ]

    file_types = [
        {"type": _friendly_type(mt), "count": int(c)}
        for mt, c in db.query(OCRJob.mime_type, func.count(OCRJob.id)).group_by(OCRJob.mime_type).all()
    ]

    engine_usage = [
        {"engine": eng or "unknown", "count": int(c)}
        for eng, c in db.query(OCRJob.engine, func.count(OCRJob.id))
        .filter(OCRJob.status == "completed")
        .group_by(OCRJob.engine)
        .all()
    ]

    return {
        "requests_per_day": requests_per_day,
        "confidence_per_day": confidence_per_day,
        "language_distribution": language_distribution,
        "file_types": file_types,
        "engine_usage": engine_usage,
    }


def engine_performance(db: Session) -> list[dict]:
    """Per-engine averages — the core of performance monitoring.

    Throughput is computed from recorded sums (never from confidence or
    averages of averages): seconds/page and output-tokens/second for the
    generative engines that report tokens (QARI / WeVisDoc).
    """
    rows = (
        db.query(
            OCRJob.engine,
            func.count(OCRJob.id),
            func.coalesce(func.sum(OCRJob.page_count), 0),
            func.avg(OCRJob.processing_time),
            func.coalesce(func.sum(OCRJob.processing_time), 0),
            func.avg(OCRJob.confidence),
            func.coalesce(func.sum(OCRJob.tokens_processed), 0),
        )
        .filter(OCRJob.status == "completed", OCRJob.engine.isnot(None))
        .group_by(OCRJob.engine)
        .all()
    )
    out = []
    for eng, count, pages, avg_time, time_sum, avg_conf, tokens in rows:
        seconds_per_page = time_sum / pages if pages else None
        tokens_per_sec = (tokens / time_sum) if (time_sum and tokens) else None
        out.append(
            {
                "engine": eng,
                "jobs": int(count),
                "pages": int(pages),
                "avg_processing_time": round(float(avg_time or 0), 3),
                "avg_confidence": round(float(avg_conf), 4) if avg_conf is not None else None,
                "avg_seconds_per_page": round(float(seconds_per_page), 3) if seconds_per_page is not None else None,
                "avg_tokens_per_sec": round(float(tokens_per_sec), 2) if tokens_per_sec is not None else None,
                "total_tokens": int(tokens),
            }
        )
    return out


def _friendly_type(mime: str) -> str:
    mapping = {
        "application/pdf": "PDF",
        "image/jpeg": "JPG",
        "image/png": "PNG",
        "image/webp": "WEBP",
        "image/tiff": "TIFF",
        "image/bmp": "BMP",
    }
    return mapping.get(mime or "", (mime or "other").split("/")[-1].upper())
