"""Central registry of supported OCR languages.

Single source of truth mapping one canonical code per language to the codes
expected by each engine, plus script/direction. Engines that cannot handle a
language map to ``None`` and are skipped for it, so requests never route to an
engine that would fail (Tesseract is the broad-coverage engine).

Canonical codes are BCP-47-ish: ``en``, ``ar``, ``zh-Hans``, ``zh-Hant`` ...
plus the special ``mixed`` (Arabic + English) and ``auto`` (detect).
"""

from dataclasses import dataclass
from typing import Optional

RTL_LANGUAGES = frozenset({"ar", "fa", "ur", "he", "mixed"})
QARI_LANGUAGES = frozenset({"ar", "mixed"})
# PaddleOCR covers Latin-script languages with its Latin recognizer and
# Arabic-script languages (ar/fa/ur/mixed) with its dedicated Arabic recognizer.
# Other scripts (Cyrillic, Devanagari, CJK ...) are NOT claimed.
_PADDLE_SCRIPTS = frozenset({"latin", "arabic"})
# WeVisDoc is a script-agnostic page parser (Qwen3-VL fine-tune): it handles any
# registered language and needs no per-language files, like Tesseract. No accuracy
# claims are implied — see docs for what is / is not tested.
_BROAD_COVERAGE = frozenset({"tesseract", "wevisdoc"})


@dataclass(frozen=True)
class Language:
    code: str
    name_en: str
    name_ar: str
    script: str
    tesseract: str
    easyocr: Optional[tuple[str, ...]]

    @property
    def direction(self) -> str:
        return "rtl" if self.code in RTL_LANGUAGES else "ltr"

    def to_dict(self) -> dict:
        return {
            "code": self.code,
            "name_en": self.name_en,
            "name_ar": self.name_ar,
            "script": self.script,
            "direction": self.direction,
            "engines": {
                "tesseract": bool(self.tesseract),
                "easyocr": self.easyocr is not None,
                "qari": self.code in QARI_LANGUAGES,
                "wevisdoc": True,  # script-agnostic page parser
                "paddle": self.code == "mixed" or self.script in _PADDLE_SCRIPTS,
            },
        }


# Order is the order shown in the UI.
_LANGUAGES: tuple[Language, ...] = (
    Language("en", "English", "الإنجليزية", "latin", "eng", ("en",)),
    Language("ar", "Arabic", "العربية", "arabic", "ara+eng", ("ar", "en")),
    Language("mixed", "Arabic + English", "عربي + إنجليزي", "mixed", "ara+eng", ("ar", "en")),
    Language("zh-Hans", "Chinese (Simplified)", "الصينية (مبسّط)", "han", "chi_sim+eng", ("ch_sim", "en")),
    Language("zh-Hant", "Chinese (Traditional)", "الصينية (تقليدي)", "han", "chi_tra+eng", ("ch_tra", "en")),
    Language("fr", "French", "الفرنسية", "latin", "fra", ("fr",)),
    Language("de", "German", "الألمانية", "latin", "deu", ("de",)),
    Language("es", "Spanish", "الإسبانية", "latin", "spa", ("es",)),
    Language("it", "Italian", "الإيطالية", "latin", "ita", ("it",)),
    Language("pt", "Portuguese", "البرتغالية", "latin", "por", ("pt",)),
    Language("nl", "Dutch", "الهولندية", "latin", "nld", ("nl",)),
    Language("pl", "Polish", "البولندية", "latin", "pol", ("pl",)),
    Language("sv", "Swedish", "السويدية", "latin", "swe", ("sv",)),
    Language("tr", "Turkish", "التركية", "latin", "tur", ("tr",)),
    Language("vi", "Vietnamese", "الفيتنامية", "latin", "vie", ("vi",)),
    Language("id", "Indonesian", "الإندونيسية", "latin", "ind", ("id",)),
    Language("ru", "Russian", "الروسية", "cyrillic", "rus", ("ru",)),
    Language("uk", "Ukrainian", "الأوكرانية", "cyrillic", "ukr", ("uk",)),
    Language("fa", "Persian", "الفارسية", "arabic", "fas+eng", ("fa", "en")),
    Language("ur", "Urdu", "الأردية", "arabic", "urd+eng", ("ur", "en")),
    Language("hi", "Hindi", "الهندية", "devanagari", "hin+eng", ("hi",)),
    Language("ja", "Japanese", "اليابانية", "kana", "jpn+eng", ("ja",)),
    Language("ko", "Korean", "الكورية", "hangul", "kor+eng", ("ko",)),
    Language("th", "Thai", "التايلاندية", "thai", "tha", ("th",)),
    Language("el", "Greek", "اليونانية", "greek", "ell", None),
    Language("he", "Hebrew", "العبرية", "hebrew", "heb", None),
)

_BY_CODE = {lang.code.lower(): lang for lang in _LANGUAGES}

# Short/legacy/HF aliases → canonical code.
_ALIASES = {
    "zh": "zh-Hans",
    "zh-cn": "zh-Hans",
    "zh-sg": "zh-Hans",
    "zh-hans": "zh-Hans",
    "chi_sim": "zh-Hans",
    "ch_sim": "zh-Hans",
    "zh-tw": "zh-Hant",
    "zh-hk": "zh-Hant",
    "zh-hant": "zh-Hant",
    "chi_tra": "zh-Hant",
    "ch_tra": "zh-Hant",
    "ara": "ar",
    "eng": "en",
    "fas": "fa",
    "per": "fa",
    "urd": "ur",
    "hin": "hi",
    "jpn": "ja",
    "kor": "ko",
    "tha": "th",
    "ell": "el",
    "gre": "el",
    "heb": "he",
    "iw": "he",
    "ukr": "uk",
    "russian": "ru",
    "vietnamese": "vi",
}

# Unicode script name (Tesseract OSD) → canonical code.
_OSD_SCRIPTS = {
    "latin": "en",
    "arabic": "ar",
    "han": "zh-Hans",
    "chinese": "zh-Hans",
    "cyrillic": "ru",
    "devanagari": "hi",
    "japanese": "ja",
    "korean": "ko",
    "hangul": "ko",
    "greek": "el",
    "hebrew": "he",
    "thai": "th",
    "tamil": "en",
    "bengali": "en",
}

AUTO = "auto"

#: Fallback used when "auto" detection cannot decide (keeps legacy Arabic+English docs working).
DEFAULT_AUTO = "mixed"


def all_languages() -> list[Language]:
    return list(_LANGUAGES)


def normalize(code: Optional[str]) -> Optional[str]:
    if code is None:
        return None
    value = str(code).strip()
    if not value:
        return None
    low = value.lower()
    if low == AUTO:
        return AUTO
    lang = _BY_CODE.get(low)
    if lang is not None:
        return lang.code
    return _ALIASES.get(low)


def get(code: Optional[str]) -> Optional[Language]:
    canonical = normalize(code)
    if canonical in (None, AUTO):
        return None
    return _BY_CODE.get(canonical.lower())


def tesseract_code(code: Optional[str], fallback: str = "eng") -> str:
    lang = get(code)
    return lang.tesseract if lang else fallback


def easyocr_langs(code: Optional[str]) -> Optional[tuple[str, ...]]:
    lang = get(code)
    return lang.easyocr if lang else None


def supports(engine: str, code: Optional[str]) -> bool:
    if normalize(code) == AUTO:
        return True
    lang = get(code)
    if lang is None:
        return False
    if engine in _BROAD_COVERAGE:
        return True
    if engine == "easyocr":
        return lang.easyocr is not None
    if engine == "qari":
        return lang.code in QARI_LANGUAGES
    if engine == "paddle":
        return lang.code == "mixed" or lang.script in _PADDLE_SCRIPTS
    return False


def languages_for_engine(engine: str) -> list[str]:
    return [lang.code for lang in _LANGUAGES if supports(engine, lang.code)]


def direction(code: Optional[str]) -> str:
    lang = get(code)
    if lang is not None:
        return lang.direction
    return "rtl" if normalize(code) == "mixed" else "ltr"


def script_to_language(script: Optional[str]) -> Optional[str]:
    if not script:
        return None
    return _OSD_SCRIPTS.get(str(script).strip().lower())
