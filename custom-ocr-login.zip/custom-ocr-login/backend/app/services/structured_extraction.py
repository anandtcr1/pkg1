"""Modular structured field extraction per document type.

Each extractor is a pure function (text, language) -> dict. Register new
extractors in EXTRACTORS to extend the platform.
"""

import re
from typing import Callable, Optional

DATE_PATTERNS = [
    r"\b(\d{4}[-/]\d{1,2}[-/]\d{1,2})\b",
    r"\b(\d{1,2}[-/]\d{1,2}[-/]\d{4})\b",
    r"\b(\d{1,2}\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{4})\b",
]
AMOUNT_PATTERN = r"([0-9][0-9,]*(?:\.[0-9]{1,2})?)"
ARABIC_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789")


def _normalize_digits(text: str) -> str:
    return text.translate(ARABIC_DIGITS)


def _find_after_label(lines: list[str], labels: list[str]) -> Optional[str]:
    """Return the value following a label, either on the same line or the next."""
    for i, line in enumerate(lines):
        low = line.lower()
        for label in labels:
            if label.lower() in low:
                # value on same line after the label / colon
                after = re.split(r"[:：]", line, maxsplit=1)
                if len(after) == 2 and after[1].strip():
                    return after[1].strip(" :-")
                if i + 1 < len(lines) and lines[i + 1].strip():
                    return lines[i + 1].strip()
    return None


def _find_date(text: str) -> Optional[str]:
    norm = _normalize_digits(text)
    for pattern in DATE_PATTERNS:
        match = re.search(pattern, norm, flags=re.IGNORECASE)
        if match:
            return match.group(1)
    return None


def _find_amount_after(text: str, labels: list[str]) -> Optional[float]:
    norm = _normalize_digits(text)
    for label in labels:
        pattern = re.escape(label) + r"[^\d]{0,20}" + AMOUNT_PATTERN
        match = re.search(pattern, norm, flags=re.IGNORECASE)
        if match:
            try:
                return float(match.group(1).replace(",", ""))
            except ValueError:
                continue
    return None


def extract_invoice(text: str, language: str) -> dict:
    lines = [l for l in text.splitlines() if l.strip()]
    return {
        "invoice_number": _find_after_label(
            lines, ["invoice no", "invoice number", "invoice #", "رقم الفاتورة", "فاتورة رقم"]
        ),
        "date": _find_date(text),
        "supplier": lines[0].strip() if lines else None,
        "customer": _find_after_label(lines, ["bill to", "customer", "العميل", "فاتورة إلى"]),
        "total": _find_amount_after(text, ["total", "grand total", "الإجمالي", "المجموع الكلي", "المبلغ الإجمالي"]),
        "tax": _find_amount_after(text, ["vat", "tax", "الضريبة", "ضريبة القيمة المضافة"]),
        "currency": "SAR" if ("ريال" in text or "sar" in text.lower()) else None,
    }


def extract_letter(text: str, language: str) -> dict:
    lines = [l for l in text.splitlines() if l.strip()]
    subject = _find_after_label(lines, ["subject", "الموضوع", " RE:"])
    body_start = 0
    for i, line in enumerate(lines):
        if any(k in line for k in ("تحية طيبة", "Dear", "السيد", "المحترم")):
            body_start = i + 1
            break
    body = "\n".join(lines[body_start:]).strip() if lines else ""
    if len(body) > 2000:
        body = body[:2000]
    return {
        "reference_number": _find_after_label(lines, ["reference", "ref", "رقم الإشارة", "الإشارة", "رقم الخطاب"]),
        "date": _find_date(text),
        "sender": lines[0].strip() if lines else None,
        "recipient": _find_after_label(lines, ["to", "إلى", "السيد", "سعادة"]),
        "subject": subject,
        "body": body or None,
    }


def extract_id_document(text: str, language: str) -> dict:
    norm = _normalize_digits(text)
    id_match = re.search(r"\b([12]\d{9})\b", norm)  # Saudi-style national id / iqama
    return {
        "id_number": id_match.group(1) if id_match else None,
        "name": _find_after_label(text.splitlines(), ["name", "الاسم", "اسم"]),
        "date_of_birth": _find_after_label(text.splitlines(), ["date of birth", "تاريخ الميلاد"]) or None,
        "nationality": _find_after_label(text.splitlines(), ["nationality", "الجنسية"]),
        "expiry_date": _find_after_label(text.splitlines(), ["expiry", "تاريخ الانتهاء", "صالحة حتى"]),
    }


def extract_receipt(text: str, language: str) -> dict:
    lines = [l for l in text.splitlines() if l.strip()]
    return {
        "receipt_number": _find_after_label(lines, ["receipt no", "receipt #", "رقم الإيصال", "إيصال رقم"]),
        "date": _find_date(text),
        "merchant": lines[0].strip() if lines else None,
        "total": _find_amount_after(text, ["total", "الإجمالي", "المجموع", "المبلغ"]),
        "payment_method": (
            "cash" if re.search(r"\bcash\b|نقد", text, re.IGNORECASE)
            else "card" if re.search(r"\bcard\b|visa|mastercard|شبكة|مدى", text, re.IGNORECASE)
            else None
        ),
    }


def extract_generic(text: str, language: str) -> dict:
    norm = _normalize_digits(text)
    emails = re.findall(r"[\w.+-]+@[\w-]+\.[\w.]+", text)
    phones = re.findall(r"(?:\+?\d{1,3}[\s-]?)?(?:\(?\d{2,4}\)?[\s-]?)?\d{3,4}[\s-]\d{4}", norm)
    return {
        "date": _find_date(text),
        "emails": emails[:5] or None,
        "phones": [p.strip() for p in phones[:5]] or None,
        "title": (text.splitlines() or [None])[0],
    }


EXTRACTORS: dict[str, Callable[[str, str], dict]] = {
    "invoice": extract_invoice,
    "letter": extract_letter,
    "government_document": extract_letter,  # official letters share the same fields
    "id_document": extract_id_document,
    "receipt": extract_receipt,
    "contract": extract_generic,
    "certificate": extract_generic,
    "report": extract_generic,
    "form": extract_generic,
    "screenshot": extract_generic,
    "other": extract_generic,
}


def extract_structured_fields(text: str, document_type: str, language: str) -> dict:
    extractor = EXTRACTORS.get(document_type, extract_generic)
    fields = extractor(text, language)
    # Drop keys whose value is None/empty to keep payloads clean.
    return {k: v for k, v in fields.items() if v not in (None, "", [], {})}
