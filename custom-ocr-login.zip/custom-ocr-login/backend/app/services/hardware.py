"""Hardware detection for adaptive OCR engine configuration.

Engines consult this module so the same codebase performs well on GPU hosts
and degrades gracefully on CPU-only machines (no throttling, no idle cores).
"""

import os
import platform
import shutil
import subprocess
import time
from contextlib import contextmanager
from typing import Iterator, Optional

from app.core.config import settings
from app.core.errors import ErrorCode, OCRError

_gpu_probe_cache: bool | None = None


def affinity_cores(path_getter=None) -> Optional[int]:
    """CPUs the process is actually allowed to run on (Linux sched_setaffinity)."""
    try:
        getter = path_getter or os.sched_getaffinity
        return max(1, len(getter(0)))
    except (AttributeError, OSError, TypeError):
        return None


def cgroup_cpu_quota(
    v2_path: str = "/sys/fs/cgroup/cpu.max",
    v1_quota_path: str = "/sys/fs/cgroup/cpu/cpu.cfs_quota_us",
    v1_period_path: str = "/sys/fs/cgroup/cpu/cpu.cfs_period_us",
) -> Optional[float]:
    """Container CPU limit in cores, accounting for cgroup v2 and v1.

    Docker/Kubernetes --cpus and Compose `cpus:` are enforced as a CFS quota far
    below the host core count. Ignoring it makes the app spawn more threads than
    the quota allows, which the kernel then throttles (the reported "processor
    throttling"). Returns None when unlimited / not containerized.
    """
    try:
        with open(v2_path, "r", encoding="utf-8") as fh:
            parts = fh.read().split()
        if len(parts) >= 2 and parts[0] != "max":
            quota, period = int(parts[0]), int(parts[1])
            if quota > 0 and period > 0:
                return quota / period
    except (OSError, ValueError):
        pass
    try:
        with open(v1_quota_path, "r", encoding="utf-8") as fh:
            quota = int(fh.read().strip())
        with open(v1_period_path, "r", encoding="utf-8") as fh:
            period = int(fh.read().strip())
        if quota > 0 and period > 0:
            return quota / period
    except (OSError, ValueError):
        pass
    return None


def cpu_budget_cores() -> int:
    """Effective CPU budget = min(host cores, affinity, cgroup quota)."""
    limits = [os.cpu_count() or 1]
    affinity = affinity_cores()
    if affinity:
        limits.append(affinity)
    quota = cgroup_cpu_quota()
    if quota:
        limits.append(max(1, int(quota)))
    return max(1, min(limits))


def cpu_budget_details() -> dict:
    return {
        "host_cores": os.cpu_count() or 1,
        "affinity_cores": affinity_cores(),
        "cgroup_quota_cores": cgroup_cpu_quota(),
        "effective_cores": cpu_budget_cores(),
    }


def cpu_cores() -> int:
    return cpu_budget_cores()


def inference_threads() -> int:
    """torch intra-op thread budget for heavy generative engines (QARI / WeVisDoc).

    Honors an explicit OCR_THREADS_PER_WORKER, otherwise derives from the real
    CPU budget and leaves one core for the feeding process/IO so the model never
    oversubscribes the quota (the CFS throttle that reads as "slow CPU").
    """
    explicit = (settings.OCR_THREADS_PER_WORKER or "auto").strip().lower()
    if explicit.isdigit() and int(explicit) >= 1:
        return int(explicit)
    return max(1, cpu_budget_cores() - 1)


def configure_inference_threads() -> int:
    """Pin torch intra-op threads to the CPU budget before a heavy generation."""
    n = inference_threads()
    os.environ.setdefault("OMP_NUM_THREADS", str(n))
    os.environ.setdefault("MKL_NUM_THREADS", str(n))
    try:
        import torch

        torch.set_num_threads(n)
    except Exception:  # noqa: BLE001 — torch optional in minimal installs
        pass
    return n


def _try_lock(handle) -> bool:
    if os.name == "nt":
        import msvcrt

        try:
            msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            return True
        except OSError:
            return False
    import fcntl

    try:
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        return True
    except OSError:
        return False


def _unlock(handle) -> None:
    if os.name == "nt":
        import msvcrt

        try:
            msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
        except OSError:
            pass
        return
    import fcntl

    try:
        fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
    except OSError:
        pass


@contextmanager
def heavy_inference_guard(wait_s: Optional[float] = None) -> Iterator[None]:
    """Cross-process exclusive lock: never run two heavy generative engines at once.

    Model decode is memory-bandwidth-bound; running QARI and WeVisDoc (or two
    deployments) simultaneously makes both slower and can push the CPU into
    power throttling. Every generative engine wraps its generation with this
    guard, so heavy jobs queue instead of thrashing. A rejected (timed-out)
    caller gets a stable ErrorCode.ENGINE_BUSY instead of a silent slowdown.
    """
    wait = float(settings.HEAVY_INFERENCE_WAIT_S if wait_s is None else wait_s)
    lock_dir = os.path.join(settings.STORAGE_PATH, "locks")
    os.makedirs(lock_dir, exist_ok=True)
    lock_path = os.path.join(lock_dir, "heavy_inference.lock")
    handle = open(lock_path, "a+")
    acquired = _try_lock(handle)
    if not acquired and wait > 0:
        deadline = time.monotonic() + wait
        while not acquired and time.monotonic() < deadline:
            time.sleep(0.25)
            acquired = _try_lock(handle)
    if not acquired:
        handle.close()
        raise OCRError(
            ErrorCode.ENGINE_BUSY,
            detail="Another heavy OCR engine job is already running on this host.",
        )
    try:
        yield
    finally:
        _unlock(handle)
        handle.close()


def gpu_available() -> bool:
    """Cached GPU probe. Controlled by OCR_USE_GPU: auto | always | never."""
    global _gpu_probe_cache
    if _gpu_probe_cache is not None:
        return _gpu_probe_cache
    setting = (settings.OCR_USE_GPU or "auto").strip().lower()
    if setting in ("never", "false", "off", "0"):
        _gpu_probe_cache = False
        return False
    _gpu_probe_cache = _probe_gpu()
    return _gpu_probe_cache


def _probe_gpu() -> bool:
    """A GPU only counts when a usable CUDA runtime AND a CUDA-capable ML build exist."""
    if shutil.which("nvidia-smi") is None:
        return False
    try:
        import torch

        if torch.cuda.is_available():
            return True
    except Exception:
        pass
    return False


def gpu_name() -> str | None:
    if shutil.which("nvidia-smi") is None:
        return None
    try:
        out = subprocess.run(["nvidia-smi", "-L"], capture_output=True, text=True, timeout=10).stdout
        first = out.splitlines()[0] if out else ""
        # Format: "GPU 0: NVIDIA GeForce RTX 3080 (UUID: ...)"
        if ": " in first:
            return first.split(": ", 1)[1].split(" (UUID")[0].strip()
    except Exception:
        pass
    return None


def hardware_report() -> dict:
    budget = cpu_budget_details()
    return {
        "cpu_cores": budget["effective_cores"],
        "cpu_host_cores": budget["host_cores"],
        "cpu_budget_cores": budget["effective_cores"],
        "cpu_cgroup_quota_cores": budget["cgroup_quota_cores"],
        "gpu_available": gpu_available(),
        "gpu_name": gpu_name(),
        "platform": platform.platform(),
        "python_version": platform.python_version(),
        "worker_mode": settings.WORKER_MODE,
        "default_engine": settings.OCR_DEFAULT_ENGINE,
        "omp_thread_limit": os.environ.get("OMP_THREAD_LIMIT"),
    }
