"""Image/PDF preprocessing: page rendering, orientation, deskew, denoise, contrast.

Every step is defensive — if an enhancement fails, the pipeline continues with the
best image it has rather than aborting the whole job.
"""

import math
import os
import shutil

import cv2
import numpy as np

PDF_MIME = "application/pdf"
SUPPORTED_IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".tif", ".tiff", ".bmp"}


def is_pdf(filename: str, mime_type: str) -> bool:
    return mime_type == PDF_MIME or filename.lower().endswith(".pdf")


def render_pdf_pages(pdf_path: str, out_dir: str, dpi: int = 200) -> list[dict]:
    """Render each PDF page to a PNG using PyMuPDF (no poppler needed)."""
    import fitz  # PyMuPDF

    os.makedirs(out_dir, exist_ok=True)
    pages = []
    zoom = dpi / 72.0
    matrix = fitz.Matrix(zoom, zoom)
    with fitz.open(pdf_path) as doc:
        for i, page in enumerate(doc, start=1):
            pix = page.get_pixmap(matrix=matrix, alpha=False)
            out_path = os.path.join(out_dir, f"page_{i}.png")
            pix.save(out_path)
            pages.append({"page_number": i, "path": out_path, "width": pix.width, "height": pix.height})
    return pages


def prepare_image_page(src_path: str, out_dir: str) -> list[dict]:
    """Copy a single image into the page workspace and return its metadata."""
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "page_1.png")
    img = cv2.imread(src_path)
    if img is None:
        raise ValueError("Unsupported or corrupt image file.")
    cv2.imwrite(out_path, img)
    h, w = img.shape[:2]
    return [{"page_number": 1, "path": out_path, "width": w, "height": h}]


def _auto_rotate(img: np.ndarray) -> np.ndarray:
    """Use Tesseract OSD to detect 90/180/270 rotation. Best-effort."""
    try:
        import pytesseract

        from app.services.model_repository import tesseract_config

        osd = pytesseract.image_to_osd(img, config=tesseract_config())
        angle = 0
        for line in osd.splitlines():
            if line.startswith("Rotate:"):
                angle = int(line.split(":")[1].strip())
                break
        if angle == 90:
            return cv2.rotate(img, cv2.ROTATE_90_CLOCKWISE)
        if angle == 180:
            return cv2.rotate(img, cv2.ROTATE_180)
        if angle == 270:
            return cv2.rotate(img, cv2.ROTATE_90_COUNTERCLOCKWISE)
    except Exception:
        pass
    return img


def _deskew(img: np.ndarray) -> np.ndarray:
    """Straighten small skew angles using minAreaRect on the text mask."""
    try:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]
        coords = np.column_stack(np.where(thresh > 0))
        if len(coords) < 100:
            return img
        angle = cv2.minAreaRect(coords)[-1]
        if angle < -45:
            angle = 90 + angle
        if abs(angle) < 0.3 or abs(angle) > 15:
            return img  # nothing to do / angle too wild to trust
        (h, w) = img.shape[:2]
        center = (w // 2, h // 2)
        m = cv2.getRotationMatrix2D(center, angle, 1.0)
        return cv2.warpAffine(img, m, (w, h), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)
    except Exception:
        return img


def _denoise(img: np.ndarray) -> np.ndarray:
    try:
        return cv2.fastNlMeansDenoisingColored(img, None, 7, 7, 7, 21)
    except Exception:
        return img


def _enhance_contrast(img: np.ndarray) -> np.ndarray:
    try:
        lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
        l_chan, a_chan, b_chan = cv2.split(lab)
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        l_chan = clahe.apply(l_chan)
        return cv2.cvtColor(cv2.merge((l_chan, a_chan, b_chan)), cv2.COLOR_LAB2BGR)
    except Exception:
        return img


def preprocess_page(
    page_path: str,
    out_path: str,
    *,
    deskew: bool = True,
    denoise: bool = True,
    auto_rotate: bool = True,
    enhance_contrast: bool = True,
) -> dict:
    """Run the preprocessing chain on one page image.

    Returns metadata including final width/height — OCR bounding boxes are
    expressed in this processed image's coordinate space, and the same image
    is served to the frontend so overlays always align.
    """
    img = cv2.imread(page_path)
    if img is None:
        raise ValueError(f"Could not read page image: {page_path}")

    if auto_rotate:
        img = _auto_rotate(img)
    if deskew:
        img = _deskew(img)
    if denoise:
        img = _denoise(img)
    if enhance_contrast:
        img = _enhance_contrast(img)

    cv2.imwrite(out_path, img)
    h, w = img.shape[:2]
    return {"path": out_path, "width": w, "height": h}


def validate_upload(filename: str, mime_type: str, first_bytes: bytes) -> None:
    """Extension + magic-byte validation (no execution of uploaded content)."""
    ext = os.path.splitext(filename)[1].lower()
    if is_pdf(filename, mime_type):
        if not first_bytes.startswith(b"%PDF"):
            raise ValueError("File claims to be a PDF but its content is not.")
        return
    if ext not in SUPPORTED_IMAGE_EXTS:
        raise ValueError(f"Unsupported file extension '{ext}'.")
    signatures = (
        b"\xff\xd8\xff",  # JPEG
        b"\x89PNG\r\n\x1a\n",  # PNG
        b"RIFF",  # WEBP container
        b"II*\x00",  # TIFF little-endian
        b"MM\x00*",  # TIFF big-endian
        b"BM",  # BMP
    )
    if not any(first_bytes.startswith(sig) for sig in signatures):
        raise ValueError("File content does not match a supported image format.")


def safe_join(base: str, *parts: str) -> str:
    """Join paths and refuse anything escaping the base directory."""
    base_abs = os.path.abspath(base)
    candidate = os.path.abspath(os.path.join(base_abs, *parts))
    if not candidate.startswith(base_abs + os.sep) and candidate != base_abs:
        raise ValueError("Path traversal attempt detected.")
    return candidate


def copy_file(src: str, dst: str) -> None:
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    shutil.copy2(src, dst)


def bytes_human(size: int) -> str:
    value = float(size)
    for unit in ("B", "KB", "MB", "GB"):
        if value < 1024 or unit == "GB":
            return f"{value:.1f} {unit}" if unit != "B" else f"{int(value)} B"
        value /= 1024
    return f"{value:.1f} GB"


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def angle_of_line(dx: float, dy: float) -> float:
    return math.degrees(math.atan2(dy, dx))
