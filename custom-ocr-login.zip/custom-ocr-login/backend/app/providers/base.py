import asyncio
import os
import tempfile
import time
from abc import ABC, abstractmethod
from dataclasses import asdict, dataclass, field
from typing import Any, Optional

STATUS_READY = "READY"
STATUS_MODEL_NOT_INSTALLED = "MODEL_NOT_INSTALLED"
STATUS_UNAVAILABLE = "UNAVAILABLE"
STATUS_ERROR = "ERROR"


@dataclass
class OCRBlockResult:
    text: str
    confidence: Optional[float] = None  # None = the engine does not report a native score (e.g. QARI)
    bbox: list[float] = field(default_factory=lambda: [0.0, 0.0, 0.0, 0.0])  # [x1, y1, x2, y2]
    language: Optional[str] = None
    block_type: str = "text"


@dataclass
class OCRResult:
    text: str
    blocks: list[OCRBlockResult] = field(default_factory=list)
    confidence: Optional[float] = None  # weighted mean over blocks; None when no block scores exist
    language: Optional[str] = None
    warnings: list[str] = field(default_factory=list)
    # Token accounting for generative engines (None for Tesseract/EasyOCR).
    # Used only for honest per-engine throughput monitoring; not a quality score.
    tokens_in: Optional[int] = None
    tokens_out: Optional[int] = None


@dataclass
class ModelStatus:
    """Cheap, download-free description of an engine's readiness."""

    status: str  # READY | MODEL_NOT_INSTALLED | UNAVAILABLE | ERROR
    reason: Optional[str] = None
    model_path: Optional[str] = None
    version: Optional[str] = None
    device: str = "cpu"
    internet_required: bool = False
    model_source: str = "local"
    details: Optional[dict] = None  # engine-specific extras (e.g. QARI available versions)

    def to_dict(self) -> dict:
        return asdict(self)


class OCRProvider(ABC):
    """Abstract OCR provider.

    Subclass + register in app/providers/ocr/__init__.py to add an engine
    (QARI, Qwen-VL, cloud APIs behind the External Connectors module, ...).
    Providers must never download anything at runtime: model_status() reports
    MODEL_NOT_INSTALLED with the expected local path instead.
    """

    name: str = "base"
    languages: list[str] = ["en"]

    @abstractmethod
    async def extract(self, file_path: str, options: dict[str, Any]) -> OCRResult:
        raise NotImplementedError

    @classmethod
    @abstractmethod
    def model_status(cls) -> ModelStatus:
        raise NotImplementedError

    @classmethod
    def is_available(cls) -> bool:
        try:
            return cls.model_status().status == STATUS_READY
        except Exception:
            return False

    @classmethod
    def version(cls) -> Optional[str]:
        return None

    @classmethod
    def details(cls) -> Optional[dict]:
        """Engine-specific readiness extras surfaced to the UI (e.g. QARI versions)."""
        return None

    def device(self) -> str:
        return "cpu"

    def health_check(self) -> dict:
        """Run a real OCR call on a tiny synthetic image. PASS = engine executes locally."""
        from PIL import Image, ImageDraw

        started = time.perf_counter()
        tmp_dir = tempfile.mkdtemp(prefix="ocr-health-")
        path = os.path.join(tmp_dir, "probe.png")
        try:
            img = Image.new("RGB", (320, 90), "white")
            ImageDraw.Draw(img).text((12, 30), "OCR 123 test", fill="black")
            img.save(path)
            result = asyncio.run(self.extract(path, {"language": "en", "quality_mode": "fast"}))
            return {
                "status": "PASS",
                "time": round(time.perf_counter() - started, 3),
                "text_sample": (result.text or "")[:60],
                "error": None,
            }
        except Exception as exc:  # noqa: BLE001 — report, don't crash
            return {
                "status": "FAIL",
                "time": round(time.perf_counter() - started, 3),
                "text_sample": None,
                "error": f"{type(exc).__name__}: {str(exc)[:200]}",
            }
        finally:
            try:
                os.remove(path)
                os.rmdir(tmp_dir)
            except OSError:
                pass
