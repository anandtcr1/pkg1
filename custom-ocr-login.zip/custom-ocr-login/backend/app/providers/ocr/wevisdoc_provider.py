"""WeVisDoc: Tencent's end-to-end document parser (Qwen3-VL-2B/4B fine-tunes).

Turns one page image into structured Markdown (LaTeX formulas, HTML tables).
The checkpoint lives under WEVISDOC_MODEL_DIR (default <MODELS_DIR>/wevisdoc)
and is loaded with the NATIVE transformers class Qwen3VLForConditionalGeneration
— no trust_remote_code, no remote code, no downloads. HF_HUB_OFFLINE /
HF_DATASETS_OFFLINE are enforced here as well as by the process-wide network
guard, and model_status() reports MODEL_NOT_INSTALLED with the exact expected
path.

Inference mirrors the upstream wevisdoc/local.py path: processor
apply_chat_template with the official document-parsing system prompt, greedy
generation capped by WEVISDOC_MAX_TOKENS, plus the upstream truncation guard
(output reaching the limit without an EOS token is rejected, not returned
silently) and empty-output handling.

WeVisDoc emits no per-token confidence score, so OCRResult confidence is left
as None (never an invented number). Each page becomes one whole-page block
(marked block_type="markdown") with the reconstructed Markdown.
"""

import asyncio
import os
from typing import Any, Optional

from app.core.config import settings
from app.core.errors import ErrorCode, OCRError
from app.providers.base import (
    STATUS_MODEL_NOT_INSTALLED,
    STATUS_READY,
    STATUS_UNAVAILABLE,
    ModelStatus,
    OCRBlockResult,
    OCRProvider,
    OCRResult,
)
from app.services import model_repository as mr
from app.services.hardware import gpu_available
from app.services.language_detect import detect_language, detect_script
from app.services.languages import languages_for_engine

# Official WeVisDoc prompts (Upstream wevisdoc/prompts.py).
DEFAULT_SYSTEM_PROMPT = r"""You are a document OCR conversion engine specialized in converting PDF images to Markdown format. Please follow these instructions for the conversion:

1. Text Processing:
- Accurately recognize all text content in the PDF image without guessing or inferring.
- Convert the recognized text into Markdown format.
- Maintain the original document structure, including headings, paragraphs, lists, etc.

2. Mathematical Formula Processing:
- Convert all mathematical formulas to LaTeX format.
- Enclose inline formulas with \( \). For example: This is an inline formula \( E = mc^2 \)
- Enclose block formulas with \[ \]. For example: \[ \frac{-b \pm \sqrt{b^2 - 4ac}}{2a} \]

3. Table Processing:
- Convert tables to HTML format.
- Wrap the entire table with <table> and </table>.

4. Figure Handling:
- Ignore figures content in the PDF image. Do not attempt to describe or convert images.

5. Output Format:
- Ensure the output Markdown document has a clear structure with appropriate line breaks between elements.
- For complex layouts, try to maintain the original document's structure and format as closely as possible.

Please strictly follow these guidelines to ensure accuracy and consistency in the conversion. Your task is to accurately convert the content of the PDF image into Markdown format without adding any extra explanations or comments.
"""

DEFAULT_PROMPT = "Convert this document image to Markdown."

_OFFLINE_ENV = {"HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1", "HF_DATASETS_OFFLINE": "1"}


def build_messages(image_path: str, prompt: str = DEFAULT_PROMPT, system_prompt: str = DEFAULT_SYSTEM_PROMPT) -> list[dict]:
    """Backend-local message list for one page image (pure, testable, no imports)."""
    messages: list[dict] = []
    if system_prompt:
        messages.append({"role": "system", "content": [{"type": "text", "text": system_prompt}]})
    messages.append(
        {
            "role": "user",
            "content": [{"type": "image", "path": image_path}, {"type": "text", "text": prompt}],
        }
    )
    return messages


def is_truncated(generated_len: int, last_token_id: Optional[int], eos_ids: list[int], max_new_tokens: int) -> bool:
    """Upstream guard: hitting the token limit without an EOS token = truncated."""
    if generated_len < max_new_tokens:
        return False
    return last_token_id is None or last_token_id not in eos_ids


def env_supported() -> tuple[bool, str]:
    """Cheap check that the runtime can load a Qwen3-VL checkpoint. Never downloads."""
    for pkg in ("transformers", "torch"):
        try:
            __import__(pkg)
        except ImportError as exc:
            return False, f"{pkg} is not installed: {exc}"
    try:
        from transformers import Qwen3VLForConditionalGeneration  # noqa: F401
    except ImportError as exc:
        return False, f"transformers lacks Qwen3VLForConditionalGeneration (need >=4.57): {exc}"
    return True, ""


class WeVisDocProvider(OCRProvider):
    """Tencent WeVisDoc (Qwen3-VL-2B/4B page parser). Local weights only, offline by design."""

    name = "wevisdoc"
    languages = languages_for_engine("wevisdoc")

    def __init__(self) -> None:
        status = self.model_status()
        if status.status != STATUS_READY:
            raise OCRError(ErrorCode.MODEL_NOT_INSTALLED, detail=f"{status.reason} (expected in {status.model_path})")
        self._models: dict[str, tuple[Any, Any]] = {}  # checkpoint path -> (model, processor)

    # ------------------------------------------------------------ status

    @classmethod
    def model_status(cls) -> ModelStatus:
        if not settings.WEVISDOC_ENABLED:
            return ModelStatus(STATUS_UNAVAILABLE, reason="WeVisDoc is disabled by WEVISDOC_ENABLED=false")
        ok, reason = env_supported()
        if not ok:
            return ModelStatus(STATUS_UNAVAILABLE, reason=reason)

        check = mr.check_wevisdoc()
        if not check.ok:
            return ModelStatus(
                STATUS_MODEL_NOT_INSTALLED,
                reason=f"{check.reason} — install a WeVisDoc checkpoint offline, see models/README.md",
                model_path=check.path,
            )
        return ModelStatus(
            STATUS_READY,
            reason=f"WeVisDoc {mr.wevisdoc_variant()} ready (Qwen3-VL)",
            model_path=check.path,
            version=cls.version(),
            device="cuda" if gpu_available() else "cpu",
            model_source="local",
            details={"variant": mr.wevisdoc_variant(), "output": "markdown", "max_tokens": settings.WEVISDOC_MAX_TOKENS},
        )

    @staticmethod
    def version() -> Optional[str]:
        variant = mr.wevisdoc_variant() or "2B/4B"
        return f"WeVisDoc {variant} (Qwen3-VL)"

    def device(self) -> str:
        return "cuda" if gpu_available() else "cpu"

    @classmethod
    def details(cls) -> Optional[dict]:
        return {"variant": mr.wevisdoc_variant(), "output": "markdown", "max_tokens": settings.WEVISDOC_MAX_TOKENS}

    # ------------------------------------------------------------ heavy resources

    def _load(self) -> tuple[Any, Any]:
        directory = str(mr.wevisdoc_dir())
        if directory in self._models:
            return self._models[directory]
        import torch
        from transformers import AutoProcessor, Qwen3VLForConditionalGeneration

        for key, value in _OFFLINE_ENV.items():
            os.environ.setdefault(key, value)

        # device_map="auto" matches the upstream local path (no hard-coded CUDA):
        # it places layers on a GPU when present and falls back to CPU otherwise.
        torch_dtype = torch.float16 if gpu_available() else torch.bfloat16
        try:
            model = Qwen3VLForConditionalGeneration.from_pretrained(
                directory, torch_dtype=torch_dtype, device_map="auto", local_files_only=True
            )
            processor = AutoProcessor.from_pretrained(directory, local_files_only=True)
        except Exception as exc:
            raise OCRError(
                ErrorCode.MODEL_NOT_INSTALLED,
                detail=f"WeVisDoc checkpoint could not load from {directory}: {type(exc).__name__}: {str(exc)[:200]}",
            ) from exc
        model.eval()
        self._models[directory] = (model, processor)
        return model, processor

    # ------------------------------------------------------------ OCR

    async def extract(self, file_path: str, options: dict[str, Any]) -> OCRResult:
        model, processor = self._load()
        max_new_tokens = max(16, int(settings.WEVISDOC_MAX_TOKENS))
        return await asyncio.to_thread(self._run_generation, model, processor, file_path, max_new_tokens)

    def _run_generation(
        self, model: Any, processor: Any, file_path: str, max_new_tokens: int
    ) -> OCRResult:
        import torch
        from PIL import Image

        from app.services.hardware import configure_inference_threads, heavy_inference_guard

        configure_inference_threads()
        image = Image.open(file_path).convert("RGB")
        width, height = image.size
        messages = build_messages(file_path)

        inputs = processor.apply_chat_template(
            messages,
            tokenize=True,
            add_generation_prompt=True,
            return_dict=True,
            return_tensors="pt",
        )
        device = model.device
        inputs = {k: v.to(device) if hasattr(v, "to") else v for k, v in inputs.items()}

        with heavy_inference_guard():
            with torch.inference_mode():
                outputs = model.generate(**inputs, max_new_tokens=max_new_tokens, do_sample=False)
        output_ids = outputs[:, inputs["input_ids"].shape[1]:]

        eos = model.generation_config.eos_token_id
        eos_ids = [eos] if not isinstance(eos, list) else eos
        if is_truncated(output_ids.shape[1], output_ids[0, -1].item(), eos_ids, max_new_tokens):
            raise OCRError(
                ErrorCode.OCR_TIMEOUT,
                detail=(
                    "WeVisDoc generation was truncated (page richer than the token budget). "
                    f"Increase WEVISDOC_MAX_TOKENS (currently {max_new_tokens})."
                ),
            )

        extracted = processor.batch_decode(
            output_ids, skip_special_tokens=True, clean_up_tokenization_spaces=False
        )[0].strip()

        warnings: list[str] = []
        if not extracted:
            warnings.append("WeVisDoc returned empty content for this page.")
        detected = None
        if extracted.split():
            detected = detect_language(extracted) or "en"

        block = OCRBlockResult(
            text=extracted,
            confidence=None,  # WeVisDoc has no native confidence score — never invented
            bbox=[0.0, 0.0, float(width), float(height)],
            language=detect_script(extracted) if extracted else None,
            block_type="markdown",
        )
        return OCRResult(
            text=extracted,
            blocks=[block] if extracted else [],
            confidence=None,
            language=detected,
            warnings=warnings,
            tokens_in=int(inputs["input_ids"].shape[1]),
            tokens_out=int(output_ids.shape[1]),
        )