from typing import Optional

from app.providers.base import STATUS_READY, OCRProvider
from app.providers.ocr.easyocr_provider import EasyOCRProvider
from app.providers.ocr.paddle_provider import PaddleOCRProvider
from app.providers.ocr.qari_provider import QARIOCRProvider
from app.providers.ocr.tesseract_provider import TesseractOCRProvider
from app.providers.ocr.wevisdoc_provider import WeVisDocProvider
from app.services.languages import AUTO, normalize, supports

_PROVIDERS: dict[str, type[OCRProvider]] = {
    TesseractOCRProvider.name: TesseractOCRProvider,
    PaddleOCRProvider.name: PaddleOCRProvider,
    EasyOCRProvider.name: EasyOCRProvider,
    QARIOCRProvider.name: QARIOCRProvider,
    WeVisDocProvider.name: WeVisDocProvider,
}

# Preference when the user asks for "auto". QARI is the Arabic-quality engine
# and gets preferred for Arabic/mixed documents when it is READY; otherwise the
# light engines come first. WeVisDoc (an expensive Qwen3-VL parser) is always
# last and only completes the list when the lighter engines are missing.
_ARABIC = ["ar", "mixed"]
_FALLBACK_ORDER = ["tesseract", "paddle", "easyocr", "qari", "wevisdoc"]

_INSTANCES: dict[str, OCRProvider] = {}


def provider_names() -> list[str]:
    return list(_PROVIDERS.keys())


def get_provider(name: str) -> Optional[OCRProvider]:
    cls = _PROVIDERS.get(name)
    if cls is None:
        return None
    if name not in _INSTANCES:
        try:
            _INSTANCES[name] = cls()
        except Exception:
            return None
    return _INSTANCES[name]


def engine_statuses() -> list[dict]:
    """Download-free status of every registered engine (for /engines and health)."""
    out = []
    for name, cls in _PROVIDERS.items():
        try:
            status = cls.model_status().to_dict()
        except Exception as exc:  # noqa: BLE001
            status = {"status": "ERROR", "reason": f"{type(exc).__name__}: {exc}"[:200]}
        try:
            status["details"] = cls.details()
        except Exception:  # noqa: BLE001
            status["details"] = None
        out.append({"name": name, "languages": cls.languages, "available": status.get("status") == STATUS_READY, **status})
    return out


def available_engines() -> list[dict]:
    return engine_statuses()


def _default_order(language: Optional[str], high_quality: bool = False) -> list[str]:
    # Arabic/mixed documents prefer QARI (the Arabic-quality engine) whenever it
    # is READY, regardless of mode.
    if language in _ARABIC and QARIOCRProvider.is_available():
        return ["qari", "tesseract", "paddle", "easyocr", "wevisdoc"]
    # "high" quality / prefer_quality → the structured Markdown parser (WeVisDoc)
    # leads for non-Arabic documents, because its output preserves tables and
    # formulas that Tesseract flattens. Cheap, accurate engines stay as failover.
    if high_quality and WeVisDocProvider.is_available():
        return ["wevisdoc", "tesseract", "easyocr", "paddle", "qari"]
    return list(_FALLBACK_ORDER)


def resolve_providers_ordered(
    requested: Optional[str], language: Optional[str] = None, high_quality: bool = False
) -> list[OCRProvider]:
    """Usable engines, preferred first. 'auto'/None → language-aware default order.

    For Arabic/mixed documents QARI is preferred whenever it is installed and
    READY. quality_mode="high" / prefer_quality routes non-Arabic documents to
    the structured WeVisDoc parser when it is installed. A requested engine that
    is not installed is skipped (never routed to), so the next ready engine is
    used instead.
    """
    order: list[str] = []
    if requested and requested != "auto":
        order.append(requested)
    order += _default_order(language, high_quality=high_quality)

    explicit = normalize(language) not in (None, AUTO)
    providers: list[OCRProvider] = []
    seen: set[str] = set()
    for name in order:
        if name in seen:
            continue
        seen.add(name)
        if explicit and not supports(name, language):
            continue  # engine cannot handle this language; fail over
        cls = _PROVIDERS.get(name)
        if cls and cls.is_available():
            provider = get_provider(name)
            if provider is not None:
                providers.append(provider)
    return providers


def resolve_provider(requested: Optional[str]) -> OCRProvider:
    providers = resolve_providers_ordered(requested)
    if not providers:
        raise RuntimeError("No OCR engine available. Install local models under MODELS_DIR (see docs/OFFLINE.md).")
    return providers[0]