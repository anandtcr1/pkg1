import asyncio
import os
import threading
from typing import Any, Optional

from app.core.config import settings
from app.core.errors import ErrorCode, OCRError
from app.providers.base import (
    STATUS_MODEL_NOT_INSTALLED,
    STATUS_READY,
    STATUS_UNAVAILABLE,
    ModelStatus,
    OCRBlockResult,
    OCRProvider,
    OCRResult,
)
from app.services.language_detect import detect_image_language, detect_script
from app.services.languages import DEFAULT_AUTO
from app.services.languages import AUTO, languages_for_engine, normalize
from app.services.model_repository import _paddle_inference_ok, check_paddle, paddle_rec_dir

# Script → local recognition-model directory under <MODELS_DIR>/paddle.
# Arabic script (incl. Farsi/Urdu) uses a dedicated Arabic recognizer; every
# other registered language is handled by the Latin recognizer.
_PADDLE_REC_BY_CODE = {"ar": "rec_arabic", "fa": "rec_arabic", "ur": "rec_arabic", "mixed": "rec_arabic"}

_IMPORT_CACHE: Optional[tuple[bool, Optional[str]]] = None

#: How long the wrapper waits for one page before failing the engine.
PADDLE_PAGE_TIMEOUT_S = 600.0


def _paddle_import() -> tuple[bool, Optional[str]]:
    """Import paddleocr once and memoise (import takes ~seconds on first call)."""
    global _IMPORT_CACHE
    if _IMPORT_CACHE is None:
        try:
            import paddle  # noqa: F401
            import paddleocr  # noqa: F401

            _IMPORT_CACHE = (True, None)
        except Exception as exc:  # noqa: BLE001
            _IMPORT_CACHE = (False, f"{type(exc).__name__}: {str(exc)[:160]}")
    return _IMPORT_CACHE


# ---------------------------------------------------------------- subprocess isolation
#
# PaddleOCR runs inside its own fresh Python interpreter, launched with plain
# subprocess.Popen (fork + exec). Two independent problems are solved:
#   * Celery prefork workers are daemonic, so multiprocessing.Process is banned
#     there ("daemonic processes are not allowed to have children").
#   * Forked celery children inherit the parent's OpenMP/OneDNN budget
#     (OMP_NUM_THREADS=5 from apply_thread_budget); under that state Paddle
#     3.3.1's CPU recognizer returned garbage text ("3" instead of "Paddle OCR
#     123 test"). Popen runs a clean interpreter whose libgomp initializes from
#     a wiped env, so inference is correct AND isolated: a paddlex crash can
#     never take the worker down. The child stays warm across pages (JSON over
#     stdin/stdout).


PADDLE_WORKER_BOOTSTRAP = (
    "import app.providers.ocr.paddle_provider as _p; _p.paddle_worker_stdin_main()"
)


def paddle_worker_stdin_main() -> None:
    """Run inside the isolated interpreter: serve JSON requests over stdin.

    PaddlePaddle 3.3.1's CPU recognizer produced CORRUPT text when the forked
    celery worker's OpenMP budget (OMP_NUM_THREADS=5 via apply_thread_budget)
    was inherited ("3" instead of "Paddle OCR 123 test"). This process is
    started with a cleaned environment (Popen = fork + exec, fresh libgomp), and
    we additionally wipe the OMP vars here so Paddle uses its own proven-correct
    default — unless an operator pins PADDLE_OMP_THREADS.
    """
    import json
    import sys

    _omp = os.environ.pop("PADDLE_OMP_THREADS", None)
    for var in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "OMP_THREAD_LIMIT"):
        if _omp:
            os.environ[var] = _omp
        else:
            os.environ.pop(var, None)

    _engines: dict[str, Any] = {}
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
        except ValueError:
            sys.stdout.write(json.dumps({"error": "ENGINE_UNAVAILABLE", "detail": "bad request frame"}) + "\n")
            sys.stdout.flush()
            continue
        if req.get("cmd") == "shutdown":
            break
        file_path = req.get("path")
        rec_key = req.get("rec_key") or "rec_latin"
        try:
            if rec_key not in _engines:
                rec_model, rec_dir = _localize(rec_key)
                if not _paddle_inference_ok(paddle_rec_dir(rec_key)):
                    raise OCRError(
                        ErrorCode.MODEL_NOT_INSTALLED,
                        detail=f"PaddleOCR weights missing for '{rec_key}' (expected in {rec_dir})",
                    )
                from paddleocr import PaddleOCR

                _engines[rec_key] = PaddleOCR(
                    text_detection_model_name=settings.PADDLE_DET_MODEL,
                    text_detection_model_dir=str(paddle_rec_dir("det")),
                    text_recognition_model_name=rec_model,
                    text_recognition_model_dir=rec_dir,
                    use_doc_orientation_classify=False,
                    use_doc_unwarping=False,
                    use_textline_orientation=False,
                    enable_mkldnn=False,  # 3.3.1 PIR+oneDNN CPU bug (verified)
                )
            raw = _engines[rec_key].predict(file_path)
            sys.stdout.write(json.dumps({"ok": _blocks_from_raw(raw)}) + "\n")
        except BaseException as exc:  # noqa: BLE001
            err = exc if isinstance(exc, OCRError) else OCRError(
                ErrorCode.ENGINE_UNAVAILABLE, detail=f"paddle (subprocess): {type(exc).__name__}: {str(exc)[:200]}"
            )
            sys.stdout.write(json.dumps({"error": err.code.value, "detail": str(err.detail)[:2000]}) + "\n")
        finally:
            sys.stdout.flush()


def _blocks_from_raw(raw: Any) -> list[dict]:
    region = raw[0] if isinstance(raw, (list, tuple)) and raw else {}
    texts = region.get("rec_texts") or []
    scores = region.get("rec_scores") or []
    polys = region.get("rec_polys") or []

    use_ratio = False
    width = height = None
    from PIL import Image

    try:
        width, height = Image.open(region.get("input_path") or "").size
        use_ratio = bool(width and height)
    except Exception:  # noqa: BLE001
        pass

    out: list[dict] = []
    for i in range(len(texts)):
        text = str(texts[i] or "").strip()
        if not text:
            continue
        try:
            score = float(scores[i])
        except (TypeError, ValueError, IndexError):
            score = 0.0
        xs, ys = [], []
        for pt in polys[i]:
            xs.append(float(pt[0]))
            ys.append(float(pt[1]))
        if not xs:
            continue
        x1, y1, x2, y2 = min(xs), min(ys), max(xs), max(ys)
        if use_ratio:
            x1, y1 = x1 / width, y1 / height
            x2, y2 = x2 / width, y2 / height
        out.append(
            {
                "text": text,
                "confidence": round(score, 4),
                "bbox": [round(x1, 4), round(y1, 4), round(x2, 4), round(y2, 4)],
            }
        )
    out.sort(key=lambda b: (b["bbox"][1], b["bbox"][0]))
    return out


def _localize(rec_key: str) -> tuple[str, str]:
    if rec_key == "rec_arabic":
        return settings.PADDLE_REC_ARABIC_MODEL, str(paddle_rec_dir("rec_arabic"))
    return settings.PADDLE_REC_LATIN_MODEL, str(paddle_rec_dir("rec_latin"))


def _child_base_dir() -> str:
    return os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))


def _clean_child_env() -> dict:
    """Child env identical to the worker's, minus BLAS/OpenMP budget vars."""
    env = dict(os.environ)
    if not os.environ.get("PADDLE_OMP_THREADS"):
        for var in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS", "OMP_THREAD_LIMIT"):
            env.pop(var, None)
    env.setdefault("PYTHONPATH", _child_base_dir())
    return env


class _PaddleChild:
    """One long-lived isolated interpreter (Popen), one page at a time.

    Celery prefork workers are daemonic, so multiprocessing cannot spawn from
    them ("daemonic processes are not allowed to have children"); plain Popen
    (fork+exec) is allowed and gives a clean interpreter + clean libgomp.
    """

    def __init__(self) -> None:
        self._proc: Any = None

    def _ensure(self, rec_key: str) -> None:
        if self._proc is not None and self._proc.poll() is None:
            return
        self._stop()
        import subprocess
        import sys

        self._proc = subprocess.Popen(
            [sys.executable, "-u", "-c", PADDLE_WORKER_BOOTSTRAP],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            env=_clean_child_env(),
            cwd=_child_base_dir(),
            text=True,
            bufsize=1,
        )

    def _stop(self) -> None:
        if self._proc is None:
            return
        try:
            self._proc.stdin.write('{"cmd": "shutdown"}\n')
            self._proc.stdin.flush()
        except Exception:  # noqa: BLE001
            pass
        try:
            self._proc.stdin.close()
        except Exception:  # noqa: BLE001
            pass
        try:
            self._proc.wait(timeout=5)
        except Exception:  # noqa: BLE001 - subprocess still alive
            try:
                self._proc.kill()
            except Exception:  # noqa: BLE001
                pass
        self._proc = None

    def request(self, file_path: str, rec_key: str, options: dict[str, Any], timeout: float) -> list[dict]:
        import json
        import select

        self._ensure(rec_key)
        req = json.dumps({"path": file_path, "rec_key": rec_key}) + "\n"
        self._proc.stdin.write(req)
        self._proc.stdin.flush()
        deadline = (timeout or PADDLE_PAGE_TIMEOUT_S)
        if hasattr(select, "select"):
            ready, _, _ = select.select([self._proc.stdout], [], [], deadline)
            if not ready or self._proc.poll() is not None:
                raise OCRError(
                    ErrorCode.ENGINE_BUSY,
                    detail=f"paddle subprocess did not return within {deadline:.0f}s",
                )
        line = self._proc.stdout.readline()
        if not line:
            raise OCRError(ErrorCode.ENGINE_UNAVAILABLE, detail="paddle subprocess exited unexpectedly")
        try:
            msg = json.loads(line)
        except ValueError:
            raise OCRError(ErrorCode.ENGINE_UNAVAILABLE, detail=f"paddle subprocess: bad reply {line[:80]!r}")  # noqa: BLE001
        if "error" in msg:
            raise OCRError(ErrorCode(msg["error"]), detail=msg["detail"])
        return msg["ok"]


class PaddleOCRProvider(OCRProvider):
    """PaddleOCR 3.x on pinned CPU-only PaddlePaddle wheels.

    100% local and isolated: recognition runs in a spawned child process with a
    clean OpenMP runtime (celery-fork pollution made the CPU recognizer output
    garbage; a fresh interpreter is deterministic). Weights must exist under
    <MODELS_DIR>/paddle/{det,rec_latin,rec_arabic} and are always passed by
    explicit directory so PaddleX never queries its model hub.
    """

    name = "paddle"
    languages = languages_for_engine("paddle")
    _lock = threading.Lock()

    def __init__(self) -> None:
        status = self.model_status()
        if status.status != STATUS_READY:
            raise OCRError(ErrorCode.MODEL_NOT_INSTALLED, detail=f"{status.reason} (expected in {status.model_path})")
        self._child: Optional[_PaddleChild] = None

    @classmethod
    def model_status(cls) -> ModelStatus:
        if not settings.PADDLE_ENABLED:
            return ModelStatus(STATUS_UNAVAILABLE, reason="PADDLE_ENABLED=false")
        ok, exc = _paddle_import()
        if not ok:
            return ModelStatus(STATUS_UNAVAILABLE, reason=f"paddle/paddleocr not importable: {exc}")
        check = check_paddle()
        if not check.ok:
            return ModelStatus(STATUS_MODEL_NOT_INSTALLED, reason=check.reason, model_path=check.path)
        return ModelStatus(
            STATUS_READY,
            model_path=check.path,
            version=cls.version(),
            details=cls.details(),
        )

    @classmethod
    def version(cls) -> Optional[str]:
        try:
            import paddle
            import paddleocr

            return f"paddleocr {paddleocr.__version__} / paddle {paddle.__version__}"
        except Exception:
            return None

    @classmethod
    def details(cls) -> Optional[dict]:
        return {
            "det": settings.PADDLE_DET_MODEL,
            "rec": {
                "latin": settings.PADDLE_REC_LATIN_MODEL,
                "arabic": settings.PADDLE_REC_ARABIC_MODEL,
            },
            "mkldnn": False,  # disabled: 3.3.1 oneDNN/PIR path crashes on this CPU toolchain
            "isolation": "subprocess (spawn)",
        }

    async def extract(self, file_path: str, options: dict[str, Any]) -> OCRResult:
        language = options.get("language") or AUTO
        if normalize(language) == AUTO:
            language = detect_image_language(file_path) or DEFAULT_AUTO
        rec_key = _PADDLE_REC_BY_CODE.get(normalize(language) or "", "rec_latin")
        raw_blocks = await asyncio.to_thread(self._run_page, file_path, rec_key)
        blocks: list[OCRBlockResult] = []
        for b in raw_blocks:
            blocks.append(
                OCRBlockResult(
                    text=b["text"],
                    confidence=b["confidence"],
                    bbox=list(b["bbox"]),
                    language=detect_script(b["text"]),
                )
            )
        text = "\n".join(b.text for b in blocks)
        confidence = round(sum(b.confidence for b in blocks) / len(blocks), 4) if blocks else 0.0
        return OCRResult(text=text, blocks=blocks, confidence=confidence, language=language)

    def _run_page(self, file_path: str, rec_key: str) -> list[dict]:
        with self._lock:
            if self._child is None:
                self._child = _PaddleChild()
            try:
                return self._child.request(file_path, rec_key, {}, PADDLE_PAGE_TIMEOUT_S)
            except OCRError:
                # One "fatal" subprocess failure → start clean; a respawn usually
                # works if the child merely died. Persistent failures raise.
                self._child = _PaddleChild()
                return self._child.request(file_path, rec_key, {}, PADDLE_PAGE_TIMEOUT_S)

    @staticmethod
    def _parse(raw: Any, language: str) -> OCRResult:
        """Unit-testable mapping of a raw region dict → OCRResult (in-process)."""
        blocks: list[OCRBlockResult] = []
        for b in _blocks_from_raw([raw] if isinstance(raw, dict) else raw):
            blocks.append(
                OCRBlockResult(
                    text=b["text"],
                    confidence=b["confidence"],
                    bbox=list(b["bbox"]),
                    language=detect_script(b["text"]),
                )
            )
        text = "\n".join(b.text for b in blocks)
        confidence = round(sum(b.confidence for b in blocks) / len(blocks), 4) if blocks else 0.0
        return OCRResult(text=text, blocks=blocks, confidence=confidence, language=language)