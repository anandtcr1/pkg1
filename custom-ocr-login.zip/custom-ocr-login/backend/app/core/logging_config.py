"""Logging setup: console + rotating local job log. Never logs document contents."""

import logging
import os
from logging.handlers import RotatingFileHandler

from app.core.config import settings

_configured = False


def configure_logging() -> None:
    global _configured
    if _configured:
        return
    level = logging.DEBUG if settings.is_development else logging.INFO
    logging.basicConfig(level=level, format="%(asctime)s %(levelname)s %(name)s: %(message)s")

    os.makedirs(settings.logs_path, exist_ok=True)
    job_logger = logging.getLogger("ocr.jobs")
    job_logger.setLevel(logging.INFO)
    handler = RotatingFileHandler(
        os.path.join(settings.logs_path, "ocr_jobs.log"),
        maxBytes=10 * 1024 * 1024,
        backupCount=5,
        encoding="utf-8",
    )
    handler.setFormatter(logging.Formatter("%(asctime)s %(message)s"))
    job_logger.addHandler(handler)
    _configured = True


def job_logger() -> logging.Logger:
    return logging.getLogger("ocr.jobs")
