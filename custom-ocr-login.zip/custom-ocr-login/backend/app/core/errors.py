"""Understandable, stable error codes for OCR jobs and the API.

Users see a safe message; development mode additionally exposes the detail.
Raw Python stack traces are never returned to normal users.
"""

from enum import Enum
from typing import Optional


class ErrorCode(str, Enum):
    MODEL_NOT_INSTALLED = "MODEL_NOT_INSTALLED"
    ENGINE_UNAVAILABLE = "ENGINE_UNAVAILABLE"
    CUDA_UNAVAILABLE = "CUDA_UNAVAILABLE"
    OUT_OF_MEMORY = "OUT_OF_MEMORY"
    UNSUPPORTED_FILE = "UNSUPPORTED_FILE"
    CORRUPTED_PDF = "CORRUPTED_PDF"
    CORRUPTED_IMAGE = "CORRUPTED_IMAGE"
    OCR_TIMEOUT = "OCR_TIMEOUT"
    ENGINE_BUSY = "ENGINE_BUSY"
    INSUFFICIENT_DISK_SPACE = "INSUFFICIENT_DISK_SPACE"
    NETWORK_BLOCKED = "NETWORK_BLOCKED"
    INTERNAL_ERROR = "INTERNAL_ERROR"


SAFE_MESSAGES: dict[ErrorCode, str] = {
    ErrorCode.MODEL_NOT_INSTALLED: "A required OCR model is not installed locally.",
    ErrorCode.ENGINE_UNAVAILABLE: "No OCR engine is available to process this document.",
    ErrorCode.CUDA_UNAVAILABLE: "GPU acceleration was requested but CUDA is not available.",
    ErrorCode.OUT_OF_MEMORY: "The system ran out of memory while processing this document.",
    ErrorCode.UNSUPPORTED_FILE: "This file type is not supported.",
    ErrorCode.CORRUPTED_PDF: "The PDF could not be read. It may be corrupted or encrypted.",
    ErrorCode.CORRUPTED_IMAGE: "The image could not be decoded.",
    ErrorCode.OCR_TIMEOUT: "OCR took too long and was stopped.",
    ErrorCode.ENGINE_BUSY: "Another heavy OCR job is already running on this host. Try again shortly.",
    ErrorCode.INSUFFICIENT_DISK_SPACE: "Not enough free disk space to process this document.",
    ErrorCode.NETWORK_BLOCKED: "An engine tried to reach the network, which is disabled in offline mode.",
    ErrorCode.INTERNAL_ERROR: "An unexpected error occurred while processing this document.",
}


class OCRError(Exception):
    def __init__(self, code: ErrorCode, message: Optional[str] = None, detail: Optional[str] = None):
        self.code = code
        self.message = message or SAFE_MESSAGES[code]
        self.detail = detail
        super().__init__(f"{code.value}: {self.message}")

    def public_message(self, development: bool) -> str:
        if development and self.detail:
            return f"{self.message} ({self.detail})"
        return self.message


def classify_exception(exc: BaseException) -> OCRError:
    """Map any exception raised inside the pipeline to a stable OCRError."""
    if isinstance(exc, OCRError):
        return exc
    if isinstance(exc, MemoryError):
        return OCRError(ErrorCode.OUT_OF_MEMORY, detail=str(exc)[:300])
    name = type(exc).__name__
    if name == "NetworkAccessBlocked":
        return OCRError(ErrorCode.NETWORK_BLOCKED, detail=str(exc)[:300])
    text = str(exc).lower()
    if "cuda" in text and ("not available" in text or "no cuda" in text):
        return OCRError(ErrorCode.CUDA_UNAVAILABLE, detail=str(exc)[:300])
    if "out of memory" in text:
        return OCRError(ErrorCode.OUT_OF_MEMORY, detail=str(exc)[:300])
    return OCRError(ErrorCode.INTERNAL_ERROR, detail=f"{name}: {str(exc)[:300]}")
