import os
from typing import Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, UploadFile
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.database import get_db
from app.core.errors import OCRError
from app.core.security import require_auth
from app.models.models import Benchmark
from app.schemas import schemas
from app.services import benchmark_service, ocr_service

router = APIRouter(prefix="/benchmark", tags=["ocr-lab"], dependencies=[Depends(require_auth)])


def _lab_guard() -> None:
    if not settings.lab_enabled:
        raise HTTPException(status_code=403, detail="OCR Lab is disabled in this environment (OCR_LAB_ENABLED).")


@router.post("", response_model=schemas.BenchmarkCreated, status_code=202)
async def create_benchmark(
    file: UploadFile = File(...),
    engines: Optional[str] = Form(default=None),  # comma separated
    ground_truth: Optional[str] = Form(default=None),
    language: str = Form(default="auto"),
    db: Session = Depends(get_db),
):
    """Run one document through several engines (OCR Lab)."""
    _lab_guard()
    data = await file.read()
    if not data:
        raise HTTPException(status_code=400, detail="Empty file.")
    filename = os.path.basename(file.filename or "upload")
    mime = file.content_type or "application/octet-stream"
    try:
        stored, _ = ocr_service.save_upload(filename, data, mime)
    except OCRError as exc:
        raise HTTPException(status_code=400, detail={"error_code": exc.code.value, "message": exc.public_message(settings.is_development)})

    wanted = [e.strip() for e in (engines or "").split(",") if e.strip()]
    bench = benchmark_service.create_benchmark(db, filename, mime, stored, wanted, ground_truth, language)
    try:
        benchmark_service.enqueue_benchmark(bench.id)
    except Exception:
        bench.status = "failed"
        bench.error = "Could not queue benchmark (worker/Redis unavailable)."
        db.commit()
        raise HTTPException(status_code=503, detail="Benchmark queue unavailable.")
    return schemas.BenchmarkCreated(benchmark_id=bench.id, status=bench.status)


@router.get("", response_model=list[schemas.BenchmarkOut])
def list_benchmarks(limit: int = Query(default=20, ge=1, le=100), db: Session = Depends(get_db)):
    _lab_guard()
    return db.query(Benchmark).order_by(Benchmark.created_at.desc()).limit(limit).all()


@router.get("/{benchmark_id}", response_model=schemas.BenchmarkOut)
def get_benchmark(benchmark_id: str, db: Session = Depends(get_db)):
    _lab_guard()
    bench = db.get(Benchmark, benchmark_id)
    if bench is None:
        raise HTTPException(status_code=404, detail="Benchmark not found.")
    return bench


@router.get("/{benchmark_id}/file")
def get_benchmark_file(benchmark_id: str, db: Session = Depends(get_db)):
    """Serve the original uploaded document (document preview in the Lab — offline)."""
    _lab_guard()
    bench = db.get(Benchmark, benchmark_id)
    if bench is None:
        raise HTTPException(status_code=404, detail="Benchmark not found.")
    path = ocr_service.get_storage().path_for(f"uploads/{bench.stored_filename}")
    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail="Stored file missing.")
    return FileResponse(path, media_type=bench.mime_type, filename=bench.filename)


@router.delete("/{benchmark_id}", status_code=204)
def delete_benchmark(benchmark_id: str, db: Session = Depends(get_db)):
    _lab_guard()
    bench = db.get(Benchmark, benchmark_id)
    if bench is None:
        raise HTTPException(status_code=404, detail="Benchmark not found.")
    storage = ocr_service.get_storage()
    storage.delete(f"uploads/{bench.stored_filename}")
    storage.delete_prefix(f"processed/benchmarks/{bench.id}")
    db.delete(bench)
    db.commit()
