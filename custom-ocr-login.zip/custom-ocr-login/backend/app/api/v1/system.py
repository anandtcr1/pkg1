import asyncio
import os
from datetime import datetime, timezone

from fastapi import APIRouter, Depends
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.core import network_guard
from app.core.config import settings
from app.core.database import get_db
from app.core.security import require_auth
from app.providers.ocr import engine_statuses, get_provider
from app.schemas import schemas
from app.services import model_repository, resources

router = APIRouter(prefix="/system", tags=["system"], dependencies=[Depends(require_auth)])

APP_VERSION = "1.6.0"

# Results of the last "Run Health Check" per engine (process-local cache).
_last_checks: dict[str, dict] = {}


def _db_status(db: Session) -> str:
    try:
        db.execute(text("SELECT 1"))
        return "ok"
    except Exception as exc:  # noqa: BLE001
        return f"error: {type(exc).__name__}"


def _queue_status() -> str:
    if settings.WORKER_MODE != "celery":
        return "inline"
    length = resources.queue_length()
    return "ok" if length is not None else "unreachable"


def _health(db: Session) -> dict:
    engines = []
    for status in engine_statuses():
        status["last_check"] = _last_checks.get(status["name"])
        engines.append(status)
    return {
        "app_env": settings.APP_ENV,
        "version": APP_VERSION,
        "offline": {
            "offline_mode": settings.OFFLINE_MODE,
            "network_access": settings.NETWORK_ACCESS,
            "network_guard_active": network_guard.is_installed(),
            "model_source": settings.MODEL_SOURCE,
            "auto_download_models": settings.AUTO_DOWNLOAD_MODELS,
            "telemetry": settings.TELEMETRY,
            "models_dir": settings.models_path,
            "models_dir_exists": os.path.isdir(settings.models_path),
        },
        "engines": engines,
        "database": _db_status(db),
        "queue": _queue_status(),
        "disk_free_mb": round(model_repository.disk_free_mb(settings.STORAGE_PATH), 1),
        "lab_enabled": settings.lab_enabled,
        "swagger_enabled": settings.swagger_enabled,
    }


@router.get("/health", response_model=schemas.SystemHealth)
def system_health(db: Session = Depends(get_db)):
    """Offline status + per-engine readiness (download-free checks)."""
    return _health(db)


@router.post("/health/check", response_model=schemas.SystemHealth)
async def run_health_check(db: Session = Depends(get_db)):
    """Execute a real local OCR probe on every READY engine and cache the result."""

    def _run_all() -> None:
        for status in engine_statuses():
            name = status["name"]
            if status.get("status") != "READY":
                _last_checks[name] = {
                    "status": "SKIPPED",
                    "time": None,
                    "text_sample": None,
                    "error": status.get("reason"),
                    "checked_at": datetime.now(timezone.utc).isoformat(),
                }
                continue
            provider = get_provider(name)
            if provider is None:
                _last_checks[name] = {
                    "status": "FAIL",
                    "time": None,
                    "text_sample": None,
                    "error": "engine failed to initialize",
                    "checked_at": datetime.now(timezone.utc).isoformat(),
                }
                continue
            result = provider.health_check()
            result["checked_at"] = datetime.now(timezone.utc).isoformat()
            _last_checks[name] = result

    await asyncio.to_thread(_run_all)
    return _health(db)


@router.get("/resources", response_model=schemas.SystemResources)
def system_resources(db: Session = Depends(get_db)):
    """Live CPU / RAM / GPU, worker sizing, queue depth, job counts and latency percentiles."""
    return resources.snapshot(db)


@router.get("/storage", response_model=schemas.StorageReport)
def system_storage():
    return model_repository.storage_report()


@router.post("/maintenance/cleanup", response_model=schemas.CleanupResult)
def maintenance_cleanup(payload: schemas.CleanupRequest):
    """Safe cleanup of application-owned temporary data only."""
    return model_repository.cleanup(payload.targets)
