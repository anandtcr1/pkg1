from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import Response
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.security import require_auth
from app.models.models import OCRCorrection, OCRJob
from app.schemas import schemas
from app.services import export_service

router = APIRouter(prefix="/corrections", tags=["corrections"], dependencies=[Depends(require_auth)])


@router.post("", response_model=schemas.CorrectionOut, status_code=201)
def create_correction(payload: schemas.CorrectionCreate, db: Session = Depends(get_db)):
    if db.get(OCRJob, payload.job_id) is None:
        raise HTTPException(status_code=404, detail="OCR job not found.")
    correction = OCRCorrection(**payload.model_dump())
    db.add(correction)
    db.commit()
    db.refresh(correction)
    return correction


@router.get("", response_model=list[schemas.CorrectionOut])
def list_corrections(
    job_id: str | None = Query(default=None),
    limit: int = Query(default=200, ge=1, le=1000),
    offset: int = Query(default=0, ge=0),
    db: Session = Depends(get_db),
):
    query = db.query(OCRCorrection)
    if job_id:
        query = query.filter(OCRCorrection.job_id == job_id)
    return query.order_by(OCRCorrection.created_at.desc()).offset(offset).limit(limit).all()


@router.get("/export")
def export_corrections(
    format: str = Query(default="jsonl", pattern="^(json|csv|jsonl)$"),
    db: Session = Depends(get_db),
):
    rows = db.query(OCRCorrection).order_by(OCRCorrection.created_at).all()
    if format == "csv":
        content, media, ext = export_service.corrections_to_csv(rows), "text/csv; charset=utf-8", "csv"
    elif format == "json":
        content, media, ext = export_service.corrections_to_json(rows), "application/json; charset=utf-8", "json"
    else:
        content, media, ext = (
            export_service.corrections_to_jsonl(rows),
            "application/x-ndjson; charset=utf-8",
            "jsonl",
        )
    return Response(
        content=content.encode("utf-8"),
        media_type=media,
        headers={"Content-Disposition": f'attachment; filename="ocr_corrections.{ext}"'},
    )


@router.delete("/{correction_id}", status_code=204)
def delete_correction(correction_id: str, db: Session = Depends(get_db)):
    correction = db.get(OCRCorrection, correction_id)
    if correction is None:
        raise HTTPException(status_code=404, detail="Correction not found.")
    db.delete(correction)
    db.commit()
    return Response(status_code=204)
