"""User management: search Active Directory and register users in the application.

Only registered, enabled users can sign in (AD users only while they still exist in AD).
Users are never deleted — an admin disables them and can enable them again.
All endpoints require a signed-in administrator.
"""

import logging

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.api.v1.auth import find_user
from app.core.database import get_db
from app.core.security import require_admin
from app.models.models import User
from app.schemas import schemas
from app.services import ldap_service

logger = logging.getLogger("ocr.users")

router = APIRouter(prefix="/users", tags=["users"])


def _directory_error(exc: ldap_service.LdapError) -> HTTPException:
    return HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail=str(exc))


@router.get("", response_model=list[schemas.UserOut])
def list_users(db: Session = Depends(get_db), _: dict = Depends(require_admin)):
    return db.query(User).order_by(User.created_at.asc()).all()


@router.get("/directory", response_model=list[schemas.DirectoryUserOut])
def search_directory(
    q: str = Query(..., min_length=2, max_length=64),
    limit: int = Query(25, ge=1, le=100),
    db: Session = Depends(get_db),
    _: dict = Depends(require_admin),
):
    try:
        found = ldap_service.search_users(q, limit)
    except ldap_service.LdapError as exc:
        raise _directory_error(exc) from exc
    registered = {
        (u.username or "").lower() for u in db.query(User.username).filter(User.username.isnot(None)).all()
    }
    return [
        schemas.DirectoryUserOut(
            username=u.username,
            display_name=u.display_name,
            email=u.email,
            upn=u.upn,
            department=u.department,
            title=u.title,
            registered=u.username.lower() in registered,
        )
        for u in found
    ]


@router.post("", response_model=schemas.UserOut, status_code=201)
def add_user(payload: schemas.UserCreate, db: Session = Depends(get_db), admin: dict = Depends(require_admin)):
    try:
        ad_user = ldap_service.find_user(payload.username)
    except ldap_service.LdapError as exc:
        raise _directory_error(exc) from exc
    if ad_user is None:
        raise HTTPException(status_code=404, detail="User not found in Active Directory (or the account is disabled).")
    existing = find_user(db, ad_user.username)
    if existing is not None:
        detail = (
            "User is already registered."
            if existing.enabled
            else "User is already registered but disabled. Enable them instead."
        )
        raise HTTPException(status_code=409, detail=detail)

    email = ad_user.email
    if email and db.query(User).filter(User.email == email).first() is not None:
        email = None  # e-mail is informational; never block registration on it
    user = User(
        username=ad_user.username,
        display_name=ad_user.display_name,
        email=email,
        # AD users never authenticate locally; this value can't match any bcrypt check.
        hashed_password="!ldap",
        is_admin=payload.is_admin,
        auth_source="ldap",
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    logger.info("USERS - %s added %s (admin=%s)", admin["username"], user.username, user.is_admin)
    return user


@router.patch("/{user_id}", response_model=schemas.UserOut)
def update_user(
    user_id: str, payload: schemas.UserUpdate, db: Session = Depends(get_db), admin: dict = Depends(require_admin)
):
    """Change a user's role and/or enable/disable them. Users are never deleted."""
    if payload.is_admin is None and payload.is_active is None:
        raise HTTPException(status_code=422, detail="Nothing to change.")
    user = db.get(User, user_id)
    if user is None:
        raise HTTPException(status_code=404, detail="User not found.")
    if user.username == admin["username"]:
        # The acting admin always stays an active admin, so nobody can lock everyone out.
        raise HTTPException(status_code=400, detail="You cannot change your own account.")
    if payload.is_admin is not None:
        user.is_admin = payload.is_admin
    if payload.is_active is not None:
        # Disabled users cannot sign in and their existing sessions stop working
        # immediately (tokens are checked against the users table on every request).
        user.is_active = payload.is_active
    db.commit()
    db.refresh(user)
    logger.info(
        "USERS - %s updated %s (admin=%s, active=%s)", admin["username"], user.username, user.is_admin, user.enabled
    )
    return user
