from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.security import require_auth
from app.schemas import schemas
from app.services import stats_service
from app.services.hardware import hardware_report

router = APIRouter(prefix="/stats", tags=["stats"], dependencies=[Depends(require_auth)])


@router.get("/overview", response_model=schemas.StatsOverview)
def stats_overview(db: Session = Depends(get_db)):
    return stats_service.overview(db)


@router.get("/charts", response_model=schemas.StatsCharts)
def stats_charts(db: Session = Depends(get_db)):
    return stats_service.charts(db)


@router.get("/engines", response_model=list[schemas.EnginePerformance])
def stats_engines(db: Session = Depends(get_db)):
    """Per-engine averages: jobs, pages, mean processing time, mean confidence."""
    return stats_service.engine_performance(db)


@router.get("/system", response_model=schemas.SystemInfo)
def stats_system():
    """Hardware the OCR stack is running on (CPU cores, GPU, worker mode)."""
    return hardware_report()
