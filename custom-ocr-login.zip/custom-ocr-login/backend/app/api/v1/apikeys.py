from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.security import generate_api_key, require_auth
from app.models.models import APIKey
from app.schemas import schemas

router = APIRouter(prefix="/api-keys", tags=["api-keys"], dependencies=[Depends(require_auth)])


@router.get("", response_model=list[schemas.APIKeyOut])
def list_api_keys(db: Session = Depends(get_db)):
    return db.query(APIKey).order_by(APIKey.created_at.desc()).all()


@router.post("", response_model=schemas.APIKeyCreated, status_code=201)
def create_api_key(payload: schemas.APIKeyCreate, db: Session = Depends(get_db)):
    plain, key_hash = generate_api_key()
    record = APIKey(name=payload.name, prefix=plain[:20], key_hash=key_hash)
    db.add(record)
    db.commit()
    db.refresh(record)
    # The plain key is returned exactly once — store it somewhere safe.
    return schemas.APIKeyCreated(
        id=record.id,
        name=record.name,
        key=plain,
        prefix=record.prefix,
        created_at=record.created_at,
    )


@router.delete("/{key_id}", status_code=204)
def revoke_api_key(key_id: str, db: Session = Depends(get_db)):
    record = db.get(APIKey, key_id)
    if record is None:
        raise HTTPException(status_code=404, detail="API key not found.")
    record.revoked = True
    db.commit()
    return Response(status_code=204)
