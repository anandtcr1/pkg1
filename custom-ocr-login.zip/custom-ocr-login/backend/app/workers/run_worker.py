"""Resource-aware Celery worker launcher.

Concurrency is derived from cores/RAM (OCR_WORKER_CONCURRENCY=auto) and each
worker's OpenMP/MKL thread budget is capped so parallel workers never
oversubscribe the CPU — the throttling pattern reported on CPU-only hosts.
"""

import logging

from app.core import network_guard
from app.core.config import settings
from app.core.database import ensure_schema
from app.core.logging_config import configure_logging
from app.services.resources import apply_thread_budget, effective_workers, recommended_workers


def main() -> None:
    configure_logging()
    log = logging.getLogger("ocr.worker")

    if not settings.NETWORK_ACCESS:
        network_guard.install()

    workers = effective_workers()
    threads = apply_thread_budget()

    ensure_schema()
    log.info(
        "worker starting | concurrency=%s (recommended=%s) threads/worker=%s offline=%s guard=%s",
        workers,
        recommended_workers(),
        threads,
        settings.OFFLINE_MODE,
        network_guard.is_installed(),
    )
    # Security posture, logged explicitly at startup (also in the API).
    log.info("SEC - QARI model source: %s", settings.MODEL_SOURCE.upper())
    log.info("SEC - Network inference: %s", "DISABLED" if not settings.NETWORK_ACCESS else "ENABLED")
    log.info("SEC - Automatic downloads: %s", "DISABLED" if not settings.AUTO_DOWNLOAD_MODELS else "ENABLED")

    from app.workers.celery_app import celery

    celery.worker_main(["worker", "--loglevel=info", f"--concurrency={workers}"])


if __name__ == "__main__":
    main()
