from celery import Celery
from celery.signals import worker_process_init

from app.core import network_guard
from app.core.config import settings

celery = Celery(
    "ocr_worker",
    broker=settings.REDIS_URL,
    backend=settings.REDIS_URL,
    include=["app.workers.tasks"],
)

celery.conf.update(
    task_serializer="json",
    result_serializer="json",
    accept_content=["json"],
    task_acks_late=True,
    worker_prefetch_multiplier=1,
    task_track_started=True,
    result_expires=3600,
)


@worker_process_init.connect
def _init_worker_process(**_kwargs) -> None:
    """Each prefork child enforces offline mode independently."""
    if not settings.NETWORK_ACCESS:
        network_guard.install()
