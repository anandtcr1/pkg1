from app.workers.celery_app import celery


@celery.task(name="ocr.process_job", bind=True, max_retries=0)
def process_ocr_job_task(self, job_id: str) -> dict:
    from app.services.ocr_service import process_job

    process_job(job_id)
    return {"job_id": job_id, "done": True}


@celery.task(name="ocr.run_benchmark", bind=True, max_retries=0)
def run_benchmark_task(self, benchmark_id: str) -> dict:
    from app.services.benchmark_service import run_benchmark

    run_benchmark(benchmark_id)
    return {"benchmark_id": benchmark_id, "done": True}
