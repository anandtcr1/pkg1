#!/usr/bin/env python3
"""
Pre-download EasyOCR model weights for the IOCR project.

Example:
    python download_easyocr_models.py
    python download_easyocr_models.py --languages en ar --model-dir ./models/easyocr
    python download_easyocr_models.py --languages en ar --cpu

After downloading, copy the model directory to the offline server and use the
same model_storage_directory when creating easyocr.Reader, with
download_enabled=False.
"""

import argparse
import sys
from pathlib import Path


def parse_args():
    parser = argparse.ArgumentParser(
        description="Download EasyOCR models for the selected languages."
    )
    parser.add_argument(
        "--languages",
        nargs="+",
        default=["en", "ar"],
        help="EasyOCR language codes (default: en ar).",
    )
    parser.add_argument(
        "--model-dir",
        default="./models/easyocr",
        help="Directory where EasyOCR model weights will be stored.",
    )
    parser.add_argument(
        "--cpu",
        action="store_true",
        help="Force CPU mode (recommended for a portable model-download step).",
    )
    return parser.parse_args()


def main():
    args = parse_args()
    model_dir = Path(args.model_dir).expanduser().resolve()
    model_dir.mkdir(parents=True, exist_ok=True)

    try:
        import easyocr
    except ImportError:
        print(
            "EasyOCR is not installed. Install it in your Python environment first:\n"
            "  python -m pip install easyocr==1.7.2",
            file=sys.stderr,
        )
        return 1

    print(f"Languages: {args.languages}")
    print(f"Model directory: {model_dir}")
    print("Initializing EasyOCR. Missing model weights will be downloaded now...")

    try:
        reader = easyocr.Reader(
            args.languages,
            gpu=not args.cpu,
            model_storage_directory=str(model_dir),
            download_enabled=True,
            verbose=True,
        )

        # A lightweight initialization confirms that EasyOCR loaded the models.
        # Actual OCR can be run later by the application.
        del reader
    except Exception as exc:
        print(f"EasyOCR model setup failed: {exc}", file=sys.stderr)
        return 1

    model_files = sorted(
        path for path in model_dir.rglob("*")
        if path.is_file() and path.suffix.lower() in {".pth", ".pt"}
    )

    if not model_files:
        print(
            "EasyOCR initialized, but no .pth/.pt model files were found under "
            f"{model_dir}. Check EasyOCR's output and model directory.",
            file=sys.stderr,
        )
        return 1

    print("\nModel files found:")
    for path in model_files:
        print(f"  {path.relative_to(model_dir)} ({path.stat().st_size:,} bytes)")

    print("\nDownload/initialization complete.")
    print("Copy this entire model directory to the target server.")
    print("On the offline server, initialize EasyOCR with:")
    print(
        "  easyocr.Reader("
        f"{args.languages!r}, "
        f"model_storage_directory={str(model_dir)!r}, "
        "download_enabled=False, gpu=False)"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
