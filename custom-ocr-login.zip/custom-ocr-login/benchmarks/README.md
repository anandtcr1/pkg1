# OCR Lab benchmark corpus

Ground-truth documents used by the OCR Lab (System → OCR Lab).
Each file pairs a scan/image with an `.txt` ground truth:

```
doc_01.png   doc_01.txt   (Arabic printed)
doc_02.pdf   doc_02.txt   (Arabic invoice)
doc_03.png   doc_03.txt   (English letter)
```

The benchmark endpoint accepts ground truth text directly; keeping the corpus here
makes CER/WER runs reproducible across engine versions.