# Local OCR model repository

IOCR never downloads models at runtime. Provision them offline with:

```bash
python -m app.tools.download_models --target ./models --engines tesseract,easyocr,qari
```

`--engines qari`, `--engines wevisdoc` and `--engines paddle` only print file
manifests (none of them is ever fetched by the tool).

By default every language in `backend/app/services/languages.py` is provisioned.
Pass `--langs` to slim an air-gapped transfer down to the languages you need:

```bash
python -m app.tools.download_models --target ./models --engines tesseract,easyocr --langs en,ar,zh-Hans,fr
```

`auto` and `mixed` are expanded automatically (`mixed` needs `en` + `ar`);
unsupported combinations (e.g. EasyOCR with `el`/`he`) are skipped with a warning.

Layout expected by the providers (see `backend/app/services/model_repository.py`):

```
models/
  tesseract/          one <lang>.traineddata per language (+ eng.traineddata,
                      osd.traineddata for auto-detection), e.g. ara, eng, chi_sim...
    fast/             (optional, quality=faster)
    best/             (optional, quality=accuracy)
  easyocr/models/     *.pth weights (craft + recognition, one per script group)
  qari/               QARI-OCR (Qwen2-VL-2B-Instruct Arabic OCR)
    base/             Qwen2-VL-2B-Instruct base (required by the v0.2 adapter and
                      used by health probes) — ~4.4 GB
    v0.2/             Qari-OCR v0.2.2.1 LoRA adapter (~127 MB)
    v0.3/             Qari-OCR v0.3 standalone Qwen2-VL-2B (F16 ~4.4 GB)
  wevisdoc/           Tencent WeVisDoc page→Markdown parser (Qwen3-VL-2B or -4B)
                      ONE checkpoint: config.json + model*.safetensors + tokenizer files
  paddle/             PaddleOCR 3.x inference models (local-only, paddle3.0.0 format)
    det/              PP-OCRv6_medium_det
    rec_latin/        latin_PP-OCRv5_mobile_rec (English + Latin-script docs)
    rec_arabic/       arabic_PP-OCRv5_mobile_rec (Arabic/Farsi/Urdu)
```

`MODELS_SEED_DIR` seeding is a **per-file merge**: files that already exist in
`MODELS_DIR` are never overwritten, and only missing files are added. This lets an
existing deployment add new languages without clobbering a customized repository.

Copy the directory to MODELS_DIR (`/models` in Docker) on the air-gapped host.
`MODELS_SEED_DIR=/opt/models-seed` is copied into `/models` by the container entrypoint.

## Verified download manifest (for provisioning / security review)

Every URL below was verified to return **HTTP 200** on 2026-09-22. These are
**provisioning-only** links — the runtime never contacts any of them.

| Engine | Component | Verified URL |
|---|---|---|
| Tesseract (fast set) | per-language `*.traineddata` | `https://github.com/tesseract-ocr/tessdata_fast/raw/main/<lang>.traineddata` (e.g. `eng`, `ara`, `osd`) |
| Tesseract (best set) | per-language `*.traineddata` | `https://github.com/tesseract-ocr/tessdata_best/raw/main/<lang>.traineddata` |
| EasyOCR | detector (craft) | `https://github.com/JaidedAI/EasyOCR/releases/download/pre-v1.1.6/craft_mlt_25k.zip` |
| EasyOCR | Latin-script recognizer | `https://github.com/JaidedAI/EasyOCR/releases/download/v1.3/latin_g2.zip` |
| EasyOCR | Arabic recognizer | `https://github.com/JaidedAI/EasyOCR/releases/download/pre-v1.1.6/arabic.zip` |
| EasyOCR | (full modelzoo list, easyocr 1.7.2) | `easyocr/config.py` → `https://github.com/JaidedAI/EasyOCR/releases/download/<tag>/<name>.zip` |
| PaddleOCR | detection `PP-OCRv6_medium_det_infer.tar` | `http://paddle-model-ecology.bj.bcebos.com/paddlex/official_inference_model/paddle3.0.0/PP-OCRv6_medium_det_infer.tar` |
| PaddleOCR | Latin rec `latin_PP-OCRv5_mobile_rec_infer.tar` | `http://paddle-model-ecology.bj.bcebos.com/paddlex/official_inference_model/paddle3.0.0/latin_PP-OCRv5_mobile_rec_infer.tar` |
| PaddleOCR | Arabic rec `arabic_PP-OCRv5_mobile_rec_infer.tar` | `http://paddle-model-ecology.bj.bcebos.com/paddlex/official_inference_model/paddle3.0.0/arabic_PP-OCRv5_mobile_rec_infer.tar` |
| QARI v0.2 (LoRA) | HF repo | `https://huggingface.co/NAMAA-Space/Qari-OCR-0.2.2.1-VL-2B-Instruct` |
| QARI v0.3 (standalone) | HF repo | `https://huggingface.co/NAMAA-Space/Qari-OCR-v0.3-VL-2B-Instruct` |
| QARI base | HF repo (Qwen2-VL-2B-Instruct) | `https://huggingface.co/Qwen/Qwen2-VL-2B-Instruct` |
| WeVisDoc (2B) | HF repo | `https://huggingface.co/tencent/WeVisDoc-2B` |
| WeVisDoc (4B) | HF repo | `https://huggingface.co/tencent/WeVisDoc-4B` |

Notes:

- **PaddleOCR** links are shown over plain HTTP because the CDN's HTTPS front
  is unreachable from some networks (TLS/handshake failure) while the same
  files serve `200` over HTTP. On hosts where HTTPS works, use the same path
  with `https://`.
- **Tesseract/EasyOCR** are fetched automatically by the CLI; the manifest above
  documents exactly what the CLI downloads so a review does not have to run it.
- **QARI/WeVisDoc** are fetched manually with `huggingface-cli download <repo>
  --local-dir <path>` (offline install), never by the tool.

## Installing QARI-OCR (offline, one time)

QARI-OCR uses the official **NAMAA-Space** Qwen2-VL-2B-Instruct Arabic OCR models
(apache-2.0, gated=false — see the paper, arXiv:2506.02295). All releases are
indexed in the official collection:
<https://huggingface.co/collections/NAMAA-Space/qari-ocr-a-high-accuracy-model-for-arabic-optical-character-67c6cdff9584ef0684391335>

- v0.2 — `https://huggingface.co/NAMAA-Space/Qari-OCR-0.2.2.1-VL-2B-Instruct`
  (a PEFT **LoRA adapter**, ~127 MB: `adapter_config.json`,
  `adapter_model.safetensors`, tokenizer files).
- v0.3 — `https://huggingface.co/NAMAA-Space/Qari-OCR-v0.3-VL-2B-Instruct`
  (a **standalone** `Qwen2-VL-2B-Instruct` fine-tune, F16 shards ~4.4 GB:
  `config.json`, `model.safetensors*`, tokenizer files, `preprocessor_config.json`).
- base — `https://huggingface.co/Qwen/Qwen2-VL-2B-Instruct` (the plain VL base
  that the v0.2 adapter is applied on top of).

On a **connected** host:

```bash
huggingface-cli download NAMAA-Space/Qari-OCR-0.2.2.1-VL-2B-Instruct \
    --local-dir models/qari/v0.2
huggingface-cli download NAMAA-Space/Qari-OCR-v0.3-VL-2B-Instruct \
    --local-dir models/qari/v0.3
huggingface-cli download Qwen/Qwen2-VL-2B-Instruct \
    --local-dir models/qari/base
```

Check the checksums in each HF repo after downloading. Then copy `models/qari`
onto the target as `MODELS_DIR/qari`. Per-engine readiness (and the v0.2 adapter's
dependency on `base/`) is verified by `GET /api/v1/engines`.

Where each version is used:

| QARI mode     | Version                       | Loaded as                                  |
|---------------|-------------------------------|--------------------------------------------|
| Auto          | `QARI_DEFAULT_VERSION` (default v0.2) | v0.2 = adapter on `base/`; v0.3 = standalone |
| Printed       | v0.2 (adapter on `base/`)     |                                            |
| Handwritten/Layout | v0.3 (standalone)        |                                            |

CPU runs use `torch.bfloat16`; CUDA uses float16. Generation is capped at
`QARI_MAX_TOKENS` (default 2000). Missing files make the engine report
`MODEL_NOT_INSTALLED` with the exact expected paths — nothing is downloaded.

## Installing WeVisDoc (offline, one time)

WeVisDoc is Tencent's end-to-end document parser: one page image in →
structured Markdown out (LaTeX formulas, HTML tables). It is a fine-tune of
**Qwen3-VL-2B-Instruct / Qwen3-VL-4B-Instruct** (apache-2.0), see
<https://huggingface.co/tencent/WeVisDoc-2B> and <https://huggingface.co/tencent/WeVisDoc-4B>.

On a **connected** host, download one variant:

```bash
# 2B — lighter, works on weaker machines
huggingface-cli download tencent/WeVisDoc-2B --local-dir models/wevisdoc
# or 4B — better on OmniDocBench/PureDocBench, needs a capable GPU
# huggingface-cli download tencent/WeVisDoc-4B --local-dir models/wevisdoc
```

Check the checksums in the HF repo after downloading, then copy `models/wevisdoc`
onto the target as `MODELS_DIR/wevisdoc` (or point `WEVISDOC_MODEL_DIR` at the
checkpoint). The expected layout inside `models/wevisdoc/`:

```
config.json               model_type must be "qwen3_vl"
model*.safetensors        full weights (a LoRA adapter alone is NOT accepted)
tokenizer_config.json, tokenizer.json, processor_config.json, ...
```

Readiness is verified by `GET /api/v1/engines`. Loading uses the native
transformers `Qwen3VLForConditionalGeneration` class — **no trust_remote_code,
no downloads** (the process-wide network guard stays active). Generation is
greedy and capped at `WEVISDOC_MAX_TOKENS` (default 8192); output that hits the
cap without an end token is rejected rather than silently truncated. WeVisDoc
reports no confidence score, and its declared languages are English/Chinese —
Arabic support is untested and not claimed.

## Installing PaddleOCR (offline, one time)

PaddleOCR 3.x is an Apache-2.0 local OCR toolkit. We use it as a **local CPU
alternative** engine (no cloud component; PaddlePaddle here is the CPU wheel).
Its inference models are official PaddleX "paddle3.0.0" tar packages, published
at:

```
https://paddle-model-ecology.bj.bcebos.com/paddlex/official_inference_model/paddle3.0.0/<NAME>_infer.tar
```

On a **connected** host:

> Network note: the CDN answers `200` over plain HTTP but some corporate
> networks block its HTTPS/TLS front (it hangs or returns errors even though
> the files are fine — `curl -I` over HTTPS may fail while the same file
> downloads over HTTP). Use the commands below as-is; if HTTPS fails for you,
> just replace `https` with `http` in the URL.

```bash
mkdir -p models/paddle/{det,rec_latin,rec_arabic}
# detection
curl -Lo det.tar https://paddle-model-ecology.bj.bcebos.com/paddlex/official_inference_model/paddle3.0.0/PP-OCRv6_medium_det_infer.tar
tar -xf det.tar --strip-components=1 -C models/paddle/det
# English / Latin-script recognition
curl -Lo latin.tar https://paddle-model-ecology.bj.bcebos.com/paddlex/official_inference_model/paddle3.0.0/latin_PP-OCRv5_mobile_rec_infer.tar
tar -xf latin.tar --strip-components=1 -C models/paddle/rec_latin
# Arabic / Farsi / Urdu recognition (optional but recommended)
curl -Lo arabic.tar https://paddle-model-ecology.bj.bcebos.com/paddlex/official_inference_model/paddle3.0.0/arabic_PP-OCRv5_mobile_rec_infer.tar
tar -xf arabic.tar --strip-components=1 -C models/paddle/rec_arabic
```

HTTP equivalents (same files, verified available):

```
http://paddle-model-ecology.bj.bcebos.com/paddlex/official_inference_model/paddle3.0.0/PP-OCRv6_medium_det_infer.tar
http://paddle-model-ecology.bj.bcebos.com/paddlex/official_inference_model/paddle3.0.0/latin_PP-OCRv5_mobile_rec_infer.tar
http://paddle-model-ecology.bj.bcebos.com/paddlex/official_inference_model/paddle3.0.0/arabic_PP-OCRv5_mobile_rec_infer.tar
```

Copy `models/paddle` onto the target as `MODELS_DIR/paddle`. Each dir must keep
the PaddleX layout: `inference.pdiparams` + `inference.json` (the PIR model file;
legacy packages ship `inference.pdmodel` instead) and optionally
`inference.yml`/`config.json`. Readiness is verified by `GET /api/v1/engines`:
`det` + `rec_latin` are required; `rec_arabic` may be added later, and Arabic
jobs stay routed away until it exists. Model dirs are always passed explicitly
so PaddleX never contacts its model hub.