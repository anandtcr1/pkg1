# Scripts

Operational helpers for the IOCR platform.

- Model provisioning: `backend/app/tools/download_models.py` (run on an Internet-connected host, copy `models/` to the air-gapped machine).