"""WeVisDoc engine: registration, deterministic model_status paths, message building, guards."""

from pathlib import Path

from app.providers.base import STATUS_MODEL_NOT_INSTALLED, STATUS_READY, STATUS_UNAVAILABLE
from app.providers.ocr import engine_statuses, get_provider, provider_names
from app.providers.ocr import wevisdoc_provider as wd
from app.providers.ocr.wevisdoc_provider import WeVisDocProvider, build_messages, env_supported, is_truncated
from app.services import model_repository as mr


def _write_wevisdoc(root: Path) -> None:
    (root / "config.json").write_text(
        '{"model_type": "qwen3_vl", "_name_or_path": "tencent/WeVisDoc-2B"}', encoding="utf-8"
    )
    (root / "model.safetensors").write_bytes(b"w")


def test_wevisdoc_registered_in_registry():
    assert "wevisdoc" in provider_names()
    names = [s["name"] for s in engine_statuses()]
    assert "wevisdoc" in names


def test_env_supported_shape():
    ok, reason = env_supported()
    assert isinstance(ok, bool)
    assert isinstance(reason, str)


def test_model_status_disabled(monkeypatch):
    monkeypatch.setattr(wd.settings, "WEVISDOC_ENABLED", False)
    status = WeVisDocProvider.model_status()
    assert status.status == STATUS_UNAVAILABLE
    assert "disabled" in status.reason


def test_model_status_reports_missing_path(monkeypatch, tmp_path):
    monkeypatch.setattr(wd, "env_supported", lambda: (True, ""))
    monkeypatch.setattr(mr, "wevisdoc_dir", lambda: tmp_path / "wevisdoc")
    status = WeVisDocProvider.model_status()
    assert status.status == STATUS_MODEL_NOT_INSTALLED
    assert status.model_path == str(tmp_path / "wevisdoc")


def test_model_status_rejects_wrong_architecture(monkeypatch, tmp_path):
    (tmp_path / "config.json").write_text('{"model_type": "qwen2_vl"}', encoding="utf-8")
    (tmp_path / "model.safetensors").write_bytes(b"w")
    monkeypatch.setattr(wd, "env_supported", lambda: (True, ""))
    monkeypatch.setattr(mr, "wevisdoc_dir", lambda: tmp_path)
    status = WeVisDocProvider.model_status()
    assert status.status == STATUS_MODEL_NOT_INSTALLED
    assert "model_type" in status.reason


def test_model_status_ready(monkeypatch, tmp_path):
    _write_wevisdoc(tmp_path)
    monkeypatch.setattr(wd, "env_supported", lambda: (True, ""))
    monkeypatch.setattr(mr, "wevisdoc_dir", lambda: tmp_path)
    status = WeVisDocProvider.model_status()
    assert status.status == STATUS_READY
    assert "2B" in (status.version or "")
    assert status.model_path == str(tmp_path)
    assert status.model_source == "local"
    assert not status.internet_required
    assert status.details["output"] == "markdown"


def test_get_provider_none_without_model(monkeypatch, tmp_path):
    # Not READY → __init__ raises OCRError → registry returns None (never routed to).
    # Isolate the instance cache: a previously constructed provider (e.g. when the
    # real checkpoint is installed) must not survive across monkeypatched state.
    from app.providers import ocr as ocr_pkg

    monkeypatch.setattr(ocr_pkg, "_INSTANCES", {})
    monkeypatch.setattr(wd, "env_supported", lambda: (True, ""))
    monkeypatch.setattr(mr, "wevisdoc_dir", lambda: tmp_path / "missing")
    assert get_provider("wevisdoc") is None


def test_build_messages_default():
    messages = build_messages("C:/tmp/page.png")
    assert messages[0]["role"] == "system"
    assert messages[1]["role"] == "user"
    content = messages[1]["content"]
    assert content[0] == {"type": "image", "path": "C:/tmp/page.png"}
    assert content[1] == {"type": "text", "text": "Convert this document image to Markdown."}


def test_build_messages_can_omit_system():
    messages = build_messages("page.png", system_prompt="")
    assert len(messages) == 1
    assert messages[0]["role"] == "user"


def test_is_truncated_guard():
    eos = [151645, 151643]
    assert is_truncated(100, 2, eos, 8192) is False  # under budget
    assert is_truncated(8192, 151645, eos, 8192) is False  # at cap with EOS token
    assert is_truncated(8192, 55, eos, 8192) is True  # at cap without EOS
    assert is_truncated(8192, None, eos, 8192) is True  # no detectable last token