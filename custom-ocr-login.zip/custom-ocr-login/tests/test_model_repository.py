"""Seed-from-image flattening: <seed>/<engine>/models/ must map to <models>/<engine>/models."""

import shutil
from pathlib import Path

from app.services import model_repository as mr


def _seed_tree(root: Path) -> None:
    # easyocr producer writes under <seed>/easyocr/models/
    easy = root / "easyocr" / "models"
    easy.mkdir(parents=True)
    (easy / "craft_mlt_25k.pth").write_bytes(b"det")
    (easy / "english_g2.pth").write_bytes(b"rec")
    # tesseract producer writes flat traineddata
    tess = root / "tesseract"
    tess.mkdir(parents=True)
    (tess / "ara.traineddata").write_bytes(b"ara")
    (tess / "eng.traineddata").write_bytes(b"eng")


def test_seed_flattens_inner_models_dir(tmp_path, monkeypatch):
    seed_root = tmp_path / "seed"
    _seed_tree(seed_root)
    models = tmp_path / "models"
    monkeypatch.setattr(mr, "models_root", lambda: models)

    actions = mr.seed_from(str(seed_root))
    assert len(actions) == 2

    # correct runtime layout, not seed/easyocr/models/models/*.pth
    easy_target = models / "easyocr" / "models"
    assert (easy_target / "craft_mlt_25k.pth").exists()
    assert not (easy_target / "models").exists()
    assert (models / "tesseract" / "eng.traineddata").exists()


def test_seed_merges_and_keeps_existing_files(tmp_path, monkeypatch):
    seed_root = tmp_path / "seed"
    _seed_tree(seed_root)
    models = tmp_path / "models"
    (models / "easyocr" / "models").mkdir(parents=True)
    (models / "easyocr" / "models" / "craft_mlt_25k.pth").write_bytes(b"keep")
    monkeypatch.setattr(mr, "models_root", lambda: models)

    actions = mr.seed_from(str(seed_root))
    # both engines merge their missing files in
    assert any("tesseract" in a for a in actions)
    assert any("easyocr" in a for a in actions)
    # existing files are never overwritten; new ones are added
    assert (models / "easyocr" / "models" / "craft_mlt_25k.pth").read_bytes() == b"keep"
    assert (models / "easyocr" / "models" / "english_g2.pth").read_bytes() == b"rec"


def test_seed_noop_with_empty_root(tmp_path, monkeypatch):
    monkeypatch.setattr(mr, "models_root", lambda: tmp_path / "models")
    assert mr.seed_from(str(tmp_path / "missing")) == []


# ---------------------------------------------------------------- QARI

def _write_qari(root: Path) -> Path:
    (root / "base").mkdir(parents=True)
    (root / "base" / "config.json").write_bytes(b"{}")
    (root / "base" / "model.safetensors").write_bytes(b"w")
    (root / "v0.2").mkdir(parents=True)
    (root / "v0.2" / "adapter_config.json").write_bytes(b"{}")
    (root / "v0.2" / "adapter_model.safetensors").write_bytes(b"a")
    (root / "v0.3").mkdir(parents=True)
    (root / "v0.3" / "config.json").write_bytes(b"{}")
    (root / "v0.3" / "model.safetensors").write_bytes(b"w")
    return root


def _patch_qari(monkeypatch, root: Path) -> None:
    monkeypatch.setattr(mr, "qari_dir", lambda version="": root if not version else root / version)
    monkeypatch.setattr(mr, "qari_base_dir", lambda: root / "base")


def test_qari_missing_reports_paths(tmp_path, monkeypatch):
    _patch_qari(monkeypatch, tmp_path / "qari")
    check = mr.check_qari("v0.2")
    assert not check.ok
    assert "v0.2" in check.reason
    assert mr.qari_ready_versions() == []


def test_qari_v02_adapter_requires_local_base(tmp_path, monkeypatch):
    root = _write_qari(tmp_path)
    _patch_qari(monkeypatch, root)
    assert mr.check_qari("v0.2").ok
    assert mr.check_qari("v0.3").ok
    assert mr.qari_ready_versions() == ["v0.2", "v0.3"]

    # adapter present but the Qwen2-VL-2B base disappears -> v0.2 alone is not ready
    shutil.rmtree(root / "base")
    check = mr.check_qari("v0.2")
    assert not check.ok
    assert "base" in check.reason
    assert mr.check_qari("v0.3").ok
    assert mr.qari_ready_versions() == ["v0.3"]


def test_qari_v03_standalone_ready_without_base(tmp_path, monkeypatch):
    root = _write_qari(tmp_path)
    _patch_qari(monkeypatch, root)
    # v0.3 is standalone: it needs no LoRA adapter and no base model.
    shutil.rmtree(root / "v0.2")
    assert not mr.check_qari("v0.2").ok
    assert mr.check_qari("v0.3").ok
    assert mr.qari_ready_versions() == ["v0.3"]


# ---------------------------------------------------------------- WeVisDoc

def test_wevisdoc_missing_reports_path(monkeypatch):
    monkeypatch.setattr(mr, "wevisdoc_dir", lambda: Path("does-not-exist/wevisdoc"))
    check = mr.check_wevisdoc()
    assert not check.ok
    assert "config.json" in check.reason


def test_wevisdoc_needs_full_checkpoint_and_qwen3_vl_type(tmp_path, monkeypatch):
    monkeypatch.setattr(mr, "wevisdoc_dir", lambda: tmp_path)

    # empty dir → not ok
    assert not mr.check_wevisdoc().ok

    # weights but wrong architecture → not ok
    (tmp_path / "config.json").write_text('{"model_type": "qwen2_vl"}', encoding="utf-8")
    (tmp_path / "model.safetensors").write_bytes(b"w")
    bad = mr.check_wevisdoc()
    assert not bad.ok
    assert "qwen3_vl" in bad.reason

    # a real WeVisDoc (Qwen3-VL) checkpoint → ok, variant detected from config
    (tmp_path / "config.json").write_text(
        '{"model_type": "qwen3_vl", "_name_or_path": "tencent/WeVisDoc-4B"}', encoding="utf-8"
    )
    assert mr.check_wevisdoc().ok
    assert mr.wevisdoc_variant() == "4B"

    (tmp_path / "config.json").write_text(
        '{"model_type": "qwen3_vl", "_name_or_path": "Qwen/Qwen3-VL-2B-Instruct"}', encoding="utf-8"
    )
    assert mr.wevisdoc_variant() == "2B"


def test_wevisdoc_variant_from_nested_text_config(tmp_path, monkeypatch):
    monkeypatch.setattr(mr, "wevisdoc_dir", lambda: tmp_path)
    # WeVisDoc 2B / 4B don't set _name_or_path; the size lives under text_config.
    (tmp_path / "config.json").write_text(
        '{"model_type": "qwen3_vl", "text_config": {"hidden_size": 2048}}', encoding="utf-8"
    )
    assert mr.wevisdoc_variant() == "2B"
    (tmp_path / "config.json").write_text(
        '{"model_type": "qwen3_vl", "text_config": {"hidden_size": 2560}}', encoding="utf-8"
    )
    assert mr.wevisdoc_variant() == "4B"
    (tmp_path / "config.json").write_text(
        '{"model_type": "qwen3_vl", "text_config": {"hidden_size": 999}}', encoding="utf-8"
    )
    assert mr.wevisdoc_variant() == ""


def test_wevisdoc_rejects_adapter_only_checkpoint(tmp_path, monkeypatch):
    monkeypatch.setattr(mr, "wevisdoc_dir", lambda: tmp_path)
    (tmp_path / "config.json").write_text('{"model_type": "qwen3_vl"}', encoding="utf-8")
    # adapter config only (no weights): must NOT be treated as a full checkpoint
    (tmp_path / "adapter_config.json").write_text("{}", encoding="utf-8")
    assert not mr.check_wevisdoc().ok