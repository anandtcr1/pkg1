"""Performance release v1.5.0: CPU resource mgmt (heavy-engine lock, thread
budget), adaptive engine selection, and honest throughput monitoring."""

import os
from typing import ClassVar

import sqlalchemy as sa

from app.core.database import Base
from app.core.errors import ErrorCode, OCRError
from app.models.models import OCRJob
from app.providers import ocr as providers
from app.providers.base import STATUS_READY, ModelStatus, OCRResult
from app.services import hardware, stats_service


# ---------------------------------------------------------------- thread budget

def test_inference_threads_respects_explicit_override(monkeypatch):
    monkeypatch.setattr(hardware.settings, "OCR_THREADS_PER_WORKER", "6")
    assert hardware.inference_threads() == 6


def test_inference_threads_leaves_headroom(monkeypatch):
    monkeypatch.setattr(hardware.settings, "OCR_THREADS_PER_WORKER", "auto")
    monkeypatch.setattr(hardware, "cpu_budget_cores", lambda: 16)
    assert hardware.inference_threads() == 15


def test_inference_threads_min_one(monkeypatch):
    monkeypatch.setattr(hardware.settings, "OCR_THREADS_PER_WORKER", "auto")
    monkeypatch.setattr(hardware, "cpu_budget_cores", lambda: 1)
    assert hardware.inference_threads() == 1


def test_configure_inference_threads_sets_env(monkeypatch):
    monkeypatch.setattr(hardware.settings, "OCR_THREADS_PER_WORKER", "4")
    monkeypatch.delenv("OMP_NUM_THREADS", raising=False)
    monkeypatch.delenv("MKL_NUM_THREADS", raising=False)
    assert hardware.configure_inference_threads() == 4
    assert os.environ["OMP_NUM_THREADS"] == "4"
    assert os.environ["MKL_NUM_THREADS"] == "4"


# ---------------------------------------------------------------- heavy lock

def test_heavy_lock_roundtrip(tmp_path, monkeypatch):
    monkeypatch.setattr(hardware.settings, "STORAGE_PATH", str(tmp_path))
    with hardware.heavy_inference_guard(wait_s=0):
        pass
    # after release the lock file is closed/unlocked; acquiring again is legal
    with hardware.heavy_inference_guard(wait_s=0):
        pass


def test_heavy_lock_rejects_concurrent_holder(tmp_path, monkeypatch):
    monkeypatch.setattr(hardware.settings, "STORAGE_PATH", str(tmp_path))
    with hardware.heavy_inference_guard(wait_s=0):
        try:
            with hardware.heavy_inference_guard(wait_s=0):
                raise AssertionError("second heavy inference should be rejected")
        except OCRError as exc:
            assert exc.code == ErrorCode.ENGINE_BUSY


def test_heavy_lock_queues_until_release(tmp_path, monkeypatch):
    import threading

    monkeypatch.setattr(hardware.settings, "STORAGE_PATH", str(tmp_path))
    results: list[str] = []

    def holder():
        with hardware.heavy_inference_guard(wait_s=0):
            results.append("first_start")
            import time

            time.sleep(0.3)
            results.append("first_end")

    t = threading.Thread(target=holder)
    t.start()
    import time

    time.sleep(0.05)
    with hardware.heavy_inference_guard(wait_s=5):
        results.append("second")
    t.join()
    assert results == ["first_start", "first_end", "second"]


# ---------------------------------------------------------------- token accounting

def test_ocr_result_carries_tokens():
    result = OCRResult(text="x", tokens_in=42, tokens_out=11)
    assert result.tokens_in == 42
    assert result.tokens_out == 11
    plain = OCRResult(text="y")
    assert plain.tokens_out is None


# ---------------------------------------------------------------- adaptive selection

class _FakeProvider:
    name: ClassVar[str] = ""
    languages: ClassVar[list[str]] = ["en"]
    _avail: ClassVar[bool] = True

    @classmethod
    def model_status(cls) -> ModelStatus:
        return ModelStatus(STATUS_READY)

    @classmethod
    def is_available(cls) -> bool:
        return cls._avail


def _fake_registry(monkeypatch, names, unavailable=()):
    classes = {}
    for n in names:
        cls = type(f"Fake{n}", (_FakeProvider,), {"name": n, "_avail": n not in unavailable})
        classes[n] = cls
    monkeypatch.setattr(providers, "_PROVIDERS", classes)
    monkeypatch.setattr(providers, "_INSTANCES", {})


def test_high_quality_prefers_wevisdoc_for_non_arabic(monkeypatch):
    _fake_registry(monkeypatch, ["tesseract", "easyocr", "qari", "wevisdoc"])
    order = [p.name for p in providers.resolve_providers_ordered("auto", language=None, high_quality=True)]
    assert order[0] == "wevisdoc"
    assert order[-1] == "qari"


def test_balanced_stays_fast_for_non_arabic(monkeypatch):
    _fake_registry(monkeypatch, ["tesseract", "easyocr", "qari", "wevisdoc"])
    order = [p.name for p in providers.resolve_providers_ordered("auto", language=None, high_quality=False)]
    assert order[0] == "tesseract"


def test_arabic_always_prefers_qari(monkeypatch):
    _fake_registry(monkeypatch, ["tesseract", "easyocr", "qari", "wevisdoc"])
    for high in (False, True):
        order = [p.name for p in providers.resolve_providers_ordered("auto", language="ar", high_quality=high)]
        assert order[0] == "qari"


def test_high_quality_falls_back_when_wevisdoc_missing(monkeypatch):
    _fake_registry(monkeypatch, ["tesseract", "easyocr", "qari", "wevisdoc"], unavailable=("wevisdoc",))
    order = [p.name for p in providers.resolve_providers_ordered("auto", language=None, high_quality=True)]
    assert order[0] == "tesseract"
    assert "wevisdoc" not in order


# ---------------------------------------------------------------- stats aggregation

def _memdb(tmp_path):
    engine = sa.create_engine(f"sqlite:///{tmp_path / 'perf.db'}", connect_args={"check_same_thread": False})
    Base.metadata.create_all(engine)
    from sqlalchemy.orm import sessionmaker

    return sessionmaker(bind=engine)()


def test_engine_performance_reports_throughput(tmp_path):
    db = _memdb(tmp_path)
    for i, (engine, pages, secs, tokens, status) in enumerate([
        ("wevisdoc", 1, 400.0, 312, "completed"),
        ("wevisdoc", 1, 480.0, 375, "completed"),
        ("tesseract", 3, 2.4, None, "completed"),
        ("wevisdoc", 1, 55.0, 10, "failed"),  # excluded
    ]):
        db.add(OCRJob(filename=f"doc_{i}.png", stored_filename=f"{i}.png", mime_type="image/png",
                      engine=engine, page_count=pages, processing_time=secs,
                      tokens_processed=tokens, status=status))
    db.commit()

    rows = {r["engine"]: r for r in stats_service.engine_performance(db)}
    wv = rows["wevisdoc"]
    assert wv["jobs"] == 2
    assert wv["pages"] == 2
    assert wv["total_tokens"] == 687
    # avg tokens/sec = sum(tokens) / sum(seconds) = 687 / 880
    assert abs(wv["avg_tokens_per_sec"] - 687 / 880.0) < 0.001
    assert abs(wv["avg_seconds_per_page"] - 880.0 / 2) < 0.001
    assert rows["tesseract"]["avg_tokens_per_sec"] is None
    assert rows["tesseract"]["total_tokens"] == 0

    ov = stats_service.overview(db)
    assert ov["total_tokens_processed"] == 687
    assert ov["documents_processed"] == 3