"""Selective OCR (Region OCR) — schema validation, model defaults, normalized coords."""

import pytest
from pydantic import ValidationError

from app.models.models import OCRBlock, OCRRegion
from app.schemas import schemas


def test_ocr_mode_defaults_to_full():
    opts = schemas.OCROptions()
    assert opts.ocr_mode == "full"
    assert opts.region_specs is None


def test_ocr_options_accepts_region_specs_roundtrip():
    opts = schemas.OCROptions(
        ocr_mode="multi",
        region_specs=[
            {"page_number": 1, "label": "1", "x": 0.1, "y": 0.2, "width": 0.4, "height": 0.3, "order": 0},
            {"page_number": 2, "label": "2", "x": 0.5, "y": 0.5, "width": 0.5, "height": 0.5, "order": 1},
        ],
    )
    dump = opts.model_dump()
    assert dump["ocr_mode"] == "multi"
    assert dump["region_specs"][0]["x"] == 0.1
    assert dump["region_specs"][1]["page_number"] == 2


def test_area_mode_accepts_single_region():
    opts = schemas.OCROptions(
        ocr_mode="area",
        region_specs=[{"page_number": 1, "x": 0.0, "y": 0.0, "width": 1.0, "height": 1.0}],
    )
    assert opts.region_specs[0].label == ""


def test_region_spec_requires_all_coordinates():
    with pytest.raises(ValidationError):
        schemas.RegionSpec(page_number=1, x=0.1, y=0.1, width=0.5)


def test_region_spec_order_defaults_zero():
    r = schemas.RegionSpec(page_number=1, x=0, y=0, width=0.5, height=0.5)
    assert r.order == 0


def test_region_out_from_attributes():
    class _Fake:
        page_number = 1
        label = "3"
        x = 0.2
        y = 0.3
        width = 0.4
        height = 0.5
        order = 2

    out = schemas.RegionOut.model_validate(_Fake())
    assert out.label == "3"
    assert out.order == 2


def test_block_region_label_default_is_none():
    block = OCRBlock(text="hello", page_id="p1")
    assert block.region_label is None


def test_block_region_label_stored():
    block = OCRBlock(text="hello", page_id="p1", region_label="1")
    assert block.region_label == "1"


def test_region_stores_coordinates():
    region = OCRRegion(page_number=1, label="2", x=0.1, y=0.2, width=0.3, height=0.4, order=1)
    assert region.label == "2"
    assert region.x == 0.1
    assert region.order == 1