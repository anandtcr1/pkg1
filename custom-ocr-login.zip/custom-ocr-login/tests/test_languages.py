"""Language registry + script/language detection."""

import pytest

from app.services import languages
from app.services.language_detect import detect_language, detect_script, text_direction


def test_registry_codes_and_uniqueness():
    codes = [lang.code for lang in languages.all_languages()]
    assert len(codes) == len(set(codes))
    for required in ("en", "ar", "zh-Hans", "zh-Hant", "ru", "ja", "ko", "hi", "el", "he"):
        assert required in codes


def test_normalize_aliases():
    assert languages.normalize("zh") == "zh-Hans"
    assert languages.normalize("zh-CN") == "zh-Hans"
    assert languages.normalize("zh-tw") == "zh-Hant"
    assert languages.normalize("chi_sim") == "zh-Hans"
    assert languages.normalize("eng") == "en"
    assert languages.normalize("auto") == "auto"
    assert languages.normalize("nope") is None


def test_engine_coverage_rules():
    assert languages.tesseract_code("ar") == "ara+eng"
    assert languages.tesseract_code("zh-Hans") == "chi_sim+eng"
    assert languages.easyocr_langs("zh-Hant") == ("ch_tra", "en")
    assert languages.easyocr_langs("el") is None  # EasyOCR has no Greek
    assert languages.easyocr_langs("he") is None  # nor Hebrew
    assert languages.supports("tesseract", "el") is True
    assert languages.supports("easyocr", "el") is False
    assert languages.supports("qari", "ar") is True
    assert languages.supports("qari", "en") is False
    assert languages.supports("tesseract", "auto") is True


def test_languages_for_engine():
    tess = languages.languages_for_engine("tesseract")
    easy = languages.languages_for_engine("easyocr")
    assert "el" in tess and "el" not in easy
    assert "he" in tess and "he" not in easy
    assert set(languages.languages_for_engine("qari")) == {"ar", "mixed"}


def test_direction():
    assert languages.direction("ar") == "rtl"
    assert languages.direction("he") == "rtl"
    assert languages.direction("en") == "ltr"
    assert text_direction("fa") == "rtl"
    assert text_direction("zh-Hans") == "ltr"


def test_detect_script():
    assert detect_script("hello world") == "en"
    assert detect_script("مرحبا بالعالم") == "ar"
    assert detect_script("你好世界") == "zh-Hans"
    assert detect_script("Привет мир") == "ru"
    assert detect_script("こんにちは") == "ja"
    assert detect_script("مرحبا hello عالم") == "mixed"
    assert detect_script("") == "en"


def test_detect_language_document_level():
    assert detect_language("مرحبا بالعالم هذا نص عربي طويل") == "ar"
    assert detect_language("你好世界这是一个中文句子") == "zh-Hans"
    assert detect_language("") == "en"
    assert detect_language("مرحبا hello world هذا نص") == "mixed"
    # too little / noisy Latin text must not be misclassified by langdetect
    assert detect_language("|)00 TEST 12345") == "en"
    # a real Latin sentence is identified
    assert detect_language("Bonjour, ceci est un document en francais avec plusieurs mots pour la detection.") == "fr"


def test_tessdata_files_language_filter():
    from app.tools.download_models import tessdata_files

    full = tessdata_files()
    for name in ("ara.traineddata", "eng.traineddata", "chi_sim.traineddata", "ell.traineddata", "osd.traineddata"):
        assert name in full

    slim = tessdata_files(["en", "ar"])
    assert "eng.traineddata" in slim and "ara.traineddata" in slim
    assert "chi_sim.traineddata" not in slim

    # pseudo-codes pull in what they need
    assert "eng.traineddata" in tessdata_files(["auto"])
    mixed = tessdata_files(["mixed"])
    assert "ara.traineddata" in mixed and "eng.traineddata" in mixed


def test_ocr_options_language_validation():
    from app.schemas.schemas import OCROptions

    assert OCROptions(language="auto").language == "auto"
    assert OCROptions(language="zh").language == "zh-Hans"
    assert OCROptions(language="mixed").language == "mixed"
    with pytest.raises(Exception):
        OCROptions(language="klingon")
