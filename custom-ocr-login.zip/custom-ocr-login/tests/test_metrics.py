"""CER/WER metrics — confidence is NOT accuracy, so these come from ground truth."""

from app.services.metrics import cer, evaluate, normalize, strip_diacritics, wer


def test_exact_match_is_zero():
    assert cer("مرحبا بالعالم", "مرحبا بالعالم") == 0.0
    assert wer("مرحبا بالعالم", "مرحبا بالعالم") == 0.0
    assert evaluate("a b c", "a b c")["cer"] == 0.0


def test_exact_match_zero_ignoring_diacritics():
    assert cer("مرحبا", "مرحبا", ignore_diacritics=True) == 0.0
    assert cer("مَرْحَبًا", "مرحبا", ignore_diacritics=True) == 0.0


def test_diacritics_count_as_characters_by_default():
    # Tashkeel is part of the reference string, so a bare 'مرحبا' differs.
    assert cer("مَرْحَبًا", "مرحبا") > 0.0


def test_diacritics_insensitive_is_zero():
    assert cer("مَرْحَبًا", "مرحبا", ignore_diacritics=True) == 0.0


def test_wer_word_substitution():
    assert wer("one two three", "one X three") == round(1 / 3, 4)


def test_empty_reference_semantics():
    assert cer("", "") == 0.0
    assert cer("", "abc") == 1.0
    assert wer("", "") == 0.0


def test_strip_diacritics():
    assert strip_diacritics("مَرْحَبًا") == "مرحبا"


def test_normalize_collapses_whitespace():
    assert normalize("  a\n b\t c  ") == "a b c"


def test_levenshtein_simple():
    from app.services.metrics import levenshtein

    assert levenshtein("kitten", "sitting") == 3


def test_evaluate_shape():
    res = evaluate("hello world", "hello OCR world")
    assert set(res) == {
        "cer",
        "wer",
        "cer_no_diacritics",
        "wer_no_diacritics",
        "reference_chars",
        "reference_words",
    }
    assert res["reference_chars"] == len("hello world")
    assert res["reference_words"] == 2