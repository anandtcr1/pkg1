"""Auth unit tests: password hashing, admin seeding and the require_auth gate.

Run inside the container where bcrypt is installed: python -m pytest -q /app/tests
"""
from types import SimpleNamespace

import pytest

from app.api.v1 import auth as auth_router
from app.core import security
from app.core.config import settings


def test_password_hash_roundtrip():
    hashed = security.hash_password("s3cret-word")
    assert hashed != "s3cret-word"
    assert security.verify_password("s3cret-word", hashed) is True


def test_verify_password_rejects_wrong_value():
    hashed = security.hash_password("correct")
    assert security.verify_password("wrong", hashed) is False


def test_verify_password_rejects_garbage_hash():
    assert security.verify_password("anything", "not-a-bcrypt-hash") is False


class _FakeQuery:
    def __init__(self, result=None):
        self._result = result

    def filter(self, *a, **k):
        return self

    def first(self):
        return self._result


class _FakeDb:
    def __init__(self, user=None, apikey=None):
        self._user = user
        self._apikey = apikey

    def commit(self):
        return None

    def query(self, model):
        from app.models.models import APIKey, User

        if model is User:
            return _FakeQuery(self._user)
        if model is APIKey:
            return _FakeQuery(self._apikey)
        return _FakeQuery(None)


def _request(token=None, with_authorization=True):
    headers = {"Authorization": f"Bearer {token}"} if with_authorization and token else {}
    return SimpleNamespace(headers=headers, query_params={})


def test_require_auth_open_when_both_flags_off(monkeypatch):
    monkeypatch.setattr(settings, "REQUIRE_AUTH", False)
    monkeypatch.setattr(settings, "REQUIRE_API_KEY", False)
    # No credential at all is fine in open mode.
    assert security.require_auth(_request(), db=_FakeDb()) is None


def test_require_auth_rejects_missing_token(monkeypatch):
    monkeypatch.setattr(settings, "REQUIRE_AUTH", True)
    monkeypatch.setattr(settings, "REQUIRE_API_KEY", False)
    with pytest.raises(Exception, match="Authentication required"):
        security.require_auth(_request(with_authorization=False), db=_FakeDb())


def test_require_auth_rejects_deleted_user_token(monkeypatch):
    """A validly-signed JWT for a user that no longer exists must be rejected."""
    monkeypatch.setattr(settings, "REQUIRE_AUTH", True)
    monkeypatch.setattr(settings, "REQUIRE_API_KEY", False)
    token = security.create_access_token("ghost", expires_minutes=5)
    with pytest.raises(Exception, match="Invalid, expired or revoked credential"):
        security.require_auth(_request(token), db=_FakeDb(user=None, apikey=None))


def test_require_auth_accepts_valid_api_key(monkeypatch):
    monkeypatch.setattr(settings, "REQUIRE_AUTH", True)
    monkeypatch.setattr(settings, "REQUIRE_API_KEY", False)
    token = security.hash_api_key("ocr_live_fake-key-123")
    record = SimpleNamespace(last_used_at=None)
    db = _FakeDb(apikey=record)
    assert security.require_auth(_request("ocr_live_fake-key-123"), db=db) is None
    assert record.last_used_at is not None  # last_used_at was touched


def test_require_auth_accepts_logged_in_user(monkeypatch):
    monkeypatch.setattr(settings, "REQUIRE_AUTH", True)
    monkeypatch.setattr(settings, "REQUIRE_API_KEY", False)
    token = security.create_access_token("admin", expires_minutes=5)
    user = SimpleNamespace(username="admin", is_admin=True)
    assert security.require_auth(_request(token), db=_FakeDb(user=user)) is None


def test_current_identity_empty_when_no_token():
    assert security.current_identity(_request(with_authorization=False), db=_FakeDb()) is None


def test_ensure_admin_creates_user_and_is_idempotent(monkeypatch, tmp_path):
    monkeypatch.setattr(settings, "ADMIN_USERNAME", "root_admin")
    monkeypatch.setattr(settings, "ADMIN_PASSWORD", "fixed-pw-123")
    import sqlalchemy as sa
    from sqlalchemy.orm import sessionmaker

    from app.core.database import Base
    from app.models.models import User

    engine = sa.create_engine(f"sqlite:///{tmp_path / 'auth.db'}", connect_args={"check_same_thread": False})
    Base.metadata.create_all(bind=engine)
    Session = sessionmaker(bind=engine)

    with Session() as db:
        name = auth_router.ensure_admin(db)
        assert name == "root_admin"
        user = db.query(User).filter(User.username == "root_admin").first()
        assert user is not None
        assert user.is_admin is True
        assert security.verify_password("fixed-pw-123", user.hashed_password)

    with Session() as db:
        # Second call must be a no-op (no duplicate, no password change).
        name2 = auth_router.ensure_admin(db)
        assert name2 == "root_admin"
        assert db.query(User).filter(User.username == "root_admin").count() == 1


def test_ensure_admin_generates_password_when_unset(monkeypatch, tmp_path):
    monkeypatch.setattr(settings, "ADMIN_USERNAME", "gen_admin")
    monkeypatch.setattr(settings, "ADMIN_PASSWORD", "")
    import sqlalchemy as sa
    from sqlalchemy.orm import sessionmaker

    from app.core.database import Base
    from app.models.models import User

    engine = sa.create_engine(f"sqlite:///{tmp_path / 'auth_gen.db'}", connect_args={"check_same_thread": False})
    Base.metadata.create_all(bind=engine)
    Session = sessionmaker(bind=engine)

    with Session() as db:
        auth_router.ensure_admin(db)
        user = db.query(User).filter(User.username == "gen_admin").first()
        assert user is not None and user.hashed_password
        assert security.verify_password("", user.hashed_password) is False  # not empty password