# Backend tests

Run with pytest (`pip install -r requirements/dev.txt`).

- `test_metrics.py` — CER/WER + diacritics-insensitive scoring (next step).
- `test_network_guard.py` — offline guard blocks public hosts, allows private ranges (next step).
- `test_storage_cleanup.py` — cleanup never touches anything outside temp/exports/logs (next step).