"""Offline guard: public hosts are blocked, private/local ranges stay allowed."""

import socket

import pytest

from app.core import network_guard as ng
from app.core.network_guard import (
    NetworkAccessBlocked,
    host_allowed,
    install,
    is_installed,
)

PRIVATE = ["127.0.0.1", "10.1.2.3", "172.16.5.5", "192.168.0.1", "169.254.3.3", "::1"]
PUBLIC = ["8.8.8.8", "1.1.1.1", "172.32.0.1", "208.67.222.222"]


@pytest.fixture(scope="module", autouse=True)
def _guard_installed():
    # Guard is idempotent; install once for the whole module. Restoration is
    # intentionally not attempted — a blocked process must stay blocked.
    install()
    assert is_installed()
    yield


def test_allowed_private_ranges():
    for host in PRIVATE:
        assert host_allowed(host), host


def test_blocked_public_ranges():
    for host in PUBLIC:
        assert not host_allowed(host), host


def test_hostnames():
    assert host_allowed("localhost")
    # On an air-gapped host this even fails DNS; either way -> not allowed.
    assert not host_allowed("example.com")


def test_connect_to_public_raises():
    s = socket.socket()
    s.settimeout(2)
    with pytest.raises(NetworkAccessBlocked):
        s.connect(("8.8.8.8", 443))
    s.close()
    # connect_ex is guarded symmetrically — no silent error-code return.
    s2 = socket.socket()
    s2.settimeout(2)
    with pytest.raises(NetworkAccessBlocked):
        s2.connect_ex(("8.8.8.8", 443))
    s2.close()


def test_private_connect_not_blocked_by_guard():
    s = socket.socket()
    s.settimeout(2)
    # Nothing listens on 127.0.0.1:1, so this is ECONNREFUSED — but the guard
    # must NOT raise NetworkAccessBlocked for private targets.
    with pytest.raises(OSError) as exc:
        s.connect(("127.0.0.1", 1))
    assert not isinstance(exc.value, NetworkAccessBlocked)
    s.close()


def test_allowlist_covers_docker_networks():
    # Docker bridge networks live in 172.16.0.0/12; postgres/redis stay reachable.
    assert all(not net.is_global for net in ng._ALLOWED_NETWORKS)