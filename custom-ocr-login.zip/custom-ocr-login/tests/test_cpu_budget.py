"""CPU budget: cgroup/affinity-aware sizing prevents throttling and idle cores."""

import os

from app.services import hardware, resources


def _write(tmp_path, name, text):
    path = os.path.join(str(tmp_path), name)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(text)
    return path


class _VM:
    total = 16 * 2**30
    available = 8 * 2**30
    used = 8 * 2**30
    percent = 50.0


def _patch_ram(monkeypatch):
    monkeypatch.setattr(resources.psutil, "virtual_memory", lambda: _VM())


def test_cgroup_v2_quota(tmp_path):
    v2 = _write(tmp_path, "cpu.max", "150000 100000\n")
    assert hardware.cgroup_cpu_quota(v2_path=v2, v1_quota_path="missing", v1_period_path="missing") == 1.5


def test_cgroup_v2_unlimited(tmp_path):
    v2 = _write(tmp_path, "cpu.max", "max 100000\n")
    assert hardware.cgroup_cpu_quota(v2_path=v2, v1_quota_path="missing", v1_period_path="missing") is None


def test_cgroup_v1_quota(tmp_path):
    quota = _write(tmp_path, "quota", "200000\n")
    period = _write(tmp_path, "period", "100000\n")
    assert hardware.cgroup_cpu_quota(v2_path="missing", v1_quota_path=quota, v1_period_path=period) == 2.0


def test_cgroup_v1_unlimited(tmp_path):
    quota = _write(tmp_path, "quota", "-1\n")
    period = _write(tmp_path, "period", "100000\n")
    assert hardware.cgroup_cpu_quota(v2_path="missing", v1_quota_path=quota, v1_period_path=period) is None


def test_affinity_cores(monkeypatch):
    monkeypatch.setattr(hardware.os, "sched_getaffinity", lambda pid: {0, 1, 2}, raising=False)
    assert hardware.affinity_cores() == 3


def test_cpu_budget_respects_cgroup_quota(monkeypatch):
    monkeypatch.setattr(hardware.os, "cpu_count", lambda: 16)
    monkeypatch.setattr(hardware, "affinity_cores", lambda *a, **k: None)
    monkeypatch.setattr(hardware, "cgroup_cpu_quota", lambda *a, **k: 2.0)
    assert hardware.cpu_budget_cores() == 2


def test_cpu_budget_respects_affinity(monkeypatch):
    monkeypatch.setattr(hardware.os, "cpu_count", lambda: 16)
    monkeypatch.setattr(hardware, "affinity_cores", lambda *a, **k: 4)
    monkeypatch.setattr(hardware, "cgroup_cpu_quota", lambda *a, **k: None)
    assert hardware.cpu_budget_cores() == 4


def test_auto_workers_and_threads_follow_budget(monkeypatch):
    _patch_ram(monkeypatch)
    monkeypatch.setattr(resources, "cpu_cores", lambda: 8)
    monkeypatch.setattr(resources, "_pinned_threads", lambda: None)
    # auto target is 4 threads/worker -> 2 workers, each using 4 threads (8 total)
    assert resources.recommended_workers() == 2
    assert resources.threads_per_worker() == 4


def test_pinned_threads_win(monkeypatch):
    _patch_ram(monkeypatch)
    monkeypatch.setattr(resources, "cpu_cores", lambda: 8)
    monkeypatch.setattr(resources, "_pinned_threads", lambda: 2)
    assert resources.threads_per_worker() == 2


def test_apply_thread_budget_sets_env(monkeypatch):
    monkeypatch.delenv("OMP_NUM_THREADS", raising=False)
    monkeypatch.delenv("MKL_NUM_THREADS", raising=False)
    value = resources.apply_thread_budget(3)
    assert value == 3
    assert os.environ["OMP_NUM_THREADS"] == "3"
    assert os.environ["MKL_NUM_THREADS"] == "3"