# Login & User Management — Implementation Guide

Everything needed to implement **login, Active Directory authentication, Windows SSO, first-run administrator setup and user management** in another copy of IOCR (offline development environment).

This document shows the **final state** of the code. It already includes all later changes (first-run setup, disable instead of delete, no default `administrator` account). Where it differs from `AuthenticationChanges.md`, **this document wins**.

All code blocks below were generated from the source files on 2026-10-17, so they match the working code exactly.

---

## Contents

1. [What you get](#1-what-you-get)
2. [Rules (final behaviour)](#2-rules-final-behaviour)
3. [Implementation order](#3-implementation-order)
4. [Python packages and system libraries](#4-python-packages-and-system-libraries)
5. [Configuration](#5-configuration)
6. [Database](#6-database)
7. [API reference](#7-api-reference)
8. [File list](#8-file-list)
9. [Backend: new files](#9-backend-new-files)
10. [Backend: modified files](#10-backend-modified-files)
11. [Frontend: new files](#11-frontend-new-files)
12. [Frontend: modified files](#12-frontend-modified-files)
13. [Deployment files](#13-deployment-files)
14. [Test user](#14-test-user)
15. [Verification checklist](#15-verification-checklist)
16. [Troubleshooting](#16-troubleshooting)
17. [Not included](#17-not-included)

---

## 1. What you get

| Feature | Summary |
|---|---|
| **Login required** | `REQUIRE_AUTH=true` by default. Anonymous visitors are redirected to the login page. |
| **First-run setup** | While the `users` table is empty, the app shows **"Create administrator"** (User name, Password, Re-enter password). The new local admin is signed in immediately. |
| **Local accounts** | Accounts with `auth_source="local"` (first-run admin, optional seeded admin, test users) sign in with a local bcrypt password. |
| **Active Directory accounts** | Admins search AD and add users. AD users sign in with their AD password and must exist in **both** the app DB **and** AD (enabled). |
| **Windows SSO** | Not-signed-in users are logged in automatically with their Windows Kerberos ticket (domain-joined PCs only); otherwise they get the login page. |
| **Users page** | List users, search AD and add, promote/demote admin, **disable** (confirmation modal "Do you want to disable the user?") and **enable**. Users are never deleted. |
| **Disabled users** | Cannot sign in (password or SSO); existing sessions stop working immediately. |
| **Login screen** | Centered card over a full-screen animated backdrop (sample Arabic certificate being scanned). English + Arabic. |
| **Downloads/previews** | Direct URLs (exports, original file, page images) carry the session token so they work with login required. |

---

## 2. Rules (final behaviour)

**Who can sign in**

| Account | How | Conditions |
|---|---|---|
| Local (`auth_source="local"`) | User name + local password | Exists in DB, **enabled**. Never checked against AD. Cannot use Windows SSO. An AD-style name (`DEV\name`) is refused for local accounts. |
| AD (`auth_source="ldap"`) | User name + **AD password**, or Windows SSO | Exists in DB (added by an admin), **enabled** in the app, **exists and enabled in AD**. |

- Accepted login names: `name`, `DEV\name`, `name@dev.team.ae`. Case-insensitive.
- Empty passwords are always rejected.
- Wrong password → `401 "Invalid username or password."`. Correct password but disabled → `403 "This account is disabled. Contact the administrator."` The disabled hint is never shown without a correct password.
- AD unreachable → `503`.

**Administrator account**

- No account is created automatically. While **no users exist**, the first-run screen creates the first local administrator.
- Optional seed: if `ADMIN_PASSWORD` is set, `ADMIN_USERNAME` (default `administrator`) is created/repaired as a local admin on every start, and its password is re-synced from `ADMIN_PASSWORD`.

**User management (admins only)**

- Add AD users from the directory search (disabled AD accounts never appear).
- Promote/demote admin, disable/enable. **Users are never deleted.**
- An admin cannot change **their own** account (role or status), so there is always at least one active admin.
- User-management endpoints always need a signed-in admin, even when `REQUIRE_AUTH=false`. API keys never count as admin.

---

## 3. Implementation order

1. **Packages:** install `ldap3` and `pyspnego[kerberos]` (offline wheels, §4).
2. **Backend:** add the new files (§9), apply the modified files (§10).
3. **Config:** set the environment variables (§5). At minimum `LDAP_BIND_USER` and `LDAP_BIND_PASSWORD` for AD.
4. **Start the backend once:** `ensure_schema()` adds the new columns; existing users are marked active (§6).
5. **Frontend:** add the new files (§11) including `assets/uae-emblem.png`, apply the modified files (§12), rebuild (`npm run build`).
6. **Deployment files:** Dockerfile, docker-compose, `.env.example` (§13).
7. **First run:** open the app → "Create administrator" → you are signed in → Users page → add AD users.
8. Run the checklist in §15.

---

## 4. Python packages and system libraries

| Package | Version | Used for |
|---|---|---|
| `ldap3` | `2.9.1` | AD search, service-account bind, AD password check. Pulls in `pyasn1`. |
| `pyspnego[kerberos]` | `0.11.2` | Windows SSO (Kerberos ticket validation). Pulls in `cryptography`, `cffi`, `pycparser`. **Windows:** `sspilib`. **Linux:** `gssapi` + `krb5` (compiled; need `libkrb5-dev`). |
| `gssapi` / `krb5` (Linux only) | `1.12.0` / `0.10.0` | Pin these for reproducible offline builds. |

Already present and reused: `python-jose` (JWT), `bcrypt` (local passwords), `sqlalchemy`, `fastapi`.

**Downloading wheels for offline installation**

Linux image (Python 3.11). Build inside a container; `pip download --platform` does **not** work here (it skips `gssapi`/`krb5`, which have no prebuilt Linux wheels):

```powershell
mkdir wheels-linux
docker run --rm -v "${PWD}\wheels-linux:/wheels" python:3.11-slim sh -c "apt-get update && apt-get install -y --no-install-recommends gcc libkrb5-dev && pip wheel --wheel-dir /wheels ldap3==2.9.1 pyspnego[kerberos]==0.11.2 gssapi==1.12.0 krb5==0.10.0"
```

Windows venv (run with the venv's Python version):

```powershell
pip download -d wheels-win ldap3==2.9.1 "pyspnego[kerberos]==0.11.2"
```

Behind the TLS-intercepting proxy add `--use-feature=truststore` to `pip` commands.

Offline install:

```powershell
pip install --no-index --find-links wheels-win ldap3==2.9.1 "pyspnego[kerberos]==0.11.2"
```

```dockerfile
COPY wheels-linux/ /wheels/
RUN pip install --no-index --find-links /wheels ldap3==2.9.1 "pyspnego[kerberos]==0.11.2"
```

If `gssapi`/`krb5` cannot be installed, everything works except Windows SSO on Linux (users simply get the login page).

No new **npm** packages: the frontend uses existing `lucide-react`, `tailwindcss-animate`, `next/image` and the existing shadcn `Dialog`, `Badge`, `Button`, `Input`, `Label`, `Checkbox`, `Card`, `Skeleton` components.

---

## 5. Configuration

| Variable | Default | Purpose |
|---|---|---|
| `REQUIRE_AUTH` | `true` | Login required for `/api/v1`. |
| `ADMIN_USERNAME` | `administrator` | Name of the optional seeded local admin. |
| `ADMIN_PASSWORD` | *(empty)* | Empty = no seed (first-run screen). Set = seed/repair `ADMIN_USERNAME` on every start. |
| `JWT_SECRET` | `CHANGE_ME` | **Set a strong random value.** Signs session tokens. |
| `JWT_EXPIRES_MINUTES` | `720` | Session lifetime. |
| `LDAP_ENABLED` | `true` | AD integration on/off. |
| `LDAP_SERVER` | `ldap://dev.team.ae` | `ldap://host` (389) or `ldaps://host` (636). |
| `LDAP_USE_STARTTLS` | `false` | TLS upgrade for `ldap://` (needed if the DC enforces LDAP signing). |
| `LDAP_BASE_DN` | *(empty)* | Empty = read from the DC (`defaultNamingContext`). |
| `LDAP_BIND_USER` | *(empty)* | **Required for AD.** Read-only service account (`svc@dev.team.ae`, `DEV\svc` or DN). |
| `LDAP_BIND_PASSWORD` | *(empty)* | **Required for AD.** |
| `LDAP_TIMEOUT_S` | `10` | LDAP timeouts (seconds). |
| `SSO_ENABLED` | `true` | Windows SSO endpoint. |
| `SSO_DOMAINS` | *(empty)* | Accepted Kerberos realms / NetBIOS domains; empty = derived from base DN (`DEV.TEAM.AE`, `DEV`). |
| `KRB5_KTNAME` | `/etc/krb5/http.keytab` (compose) | Keytab for `HTTP/<api-host>` (Linux SSO only). |
| `CORS_ORIGINS` | `http://localhost:3000` | Exact frontend origin(s). Also the only origins allowed to call Windows SSO. |

Startup log lines to check:

```
SEC - Auth require_login=True require_api_key=False admin_seed=off (first-run setup)
SEC - Active Directory enabled=True server=ldap://dev.team.ae service_account=configured windows_sso=True keytab=...
```

`service_account=MISSING` means AD search and AD logins will fail with "Active Directory is unavailable".

---

## 6. Database

Table **`users`**: three new nullable columns.

| Column | Type | Meaning |
|---|---|---|
| `auth_source` | `VARCHAR(16)` | `"local"` (local password) or `"ldap"` (Active Directory). |
| `display_name` | `VARCHAR(255)` | Shown in the UI; AD `displayName` refreshed on each AD login. |
| `is_active` | `BOOLEAN` | `false` = disabled. `NULL` is treated as active. |

They are added automatically on startup by the existing `ensure_schema()`, and `backfill_user_flags()` sets `is_active = TRUE` for existing rows. Manual SQL if your environment does not use `ensure_schema()`:

```sql
ALTER TABLE users ADD COLUMN auth_source VARCHAR(16);
ALTER TABLE users ADD COLUMN display_name VARCHAR(255);
ALTER TABLE users ADD COLUMN is_active BOOLEAN;
UPDATE users SET is_active = TRUE WHERE is_active IS NULL;
```

Data conventions:

- AD users: `auth_source="ldap"`, `hashed_password="!ldap"` (can never match bcrypt, so AD users can never log in locally).
- Local users: `auth_source="local"`, bcrypt hash in `hashed_password`.
- Rows from older versions with `auth_source = NULL` are treated as AD users.

> **SQLite:** while a tool such as *DB Browser for SQLite* has the database open, `ALTER TABLE` fails with `database is locked` and the backend does not start. Close the database in the tool first.

---

## 7. API reference

All paths under `/api/v1`.

**Auth (public)**

| Method & path | Request | Response |
|---|---|---|
| `POST /auth/login` | `{"username", "password"}` | `200` session · `401` invalid · `403` disabled · `503` AD unavailable |
| `GET /auth/me` | — | `{"authenticated", "kind", "username", "is_admin", "auth_required", "setup_required"}` |
| `GET /auth/setup` | — | `{"setup_required": bool}` |
| `POST /auth/setup` | `{"username", "password"}` | `201 {"username", "is_admin": true}` · `422` invalid (name 3-64 chars `A-Za-z0-9._-`, password ≥ 6) · `409` already done |
| `GET /auth/sso` | Browser `Authorization: Negotiate …` | `401` + `WWW-Authenticate: Negotiate` (challenge) · `200` session · `401` without challenge on any failure |

Session response:

```json
{
  "access_token": "<jwt>",
  "token_type": "bearer",
  "expires_in": 43200,
  "username": "test1",
  "display_name": "Test User 1",
  "is_admin": false,
  "auth_required": true
}
```

**Users (signed-in admin only)**

| Method & path | Request | Response |
|---|---|---|
| `GET /users` | — | `UserOut[]` |
| `GET /users/directory?q=<2-64>&limit=<1-100>` | — | `DirectoryUserOut[]` · `503` AD |
| `POST /users` | `{"username", "is_admin": false}` | `201 UserOut` · `404` not in AD/disabled · `409` already registered (message says if disabled) · `503` |
| `PATCH /users/{id}` | `{"is_admin"?: bool, "is_active"?: bool}` | `UserOut` · `400` own account · `404` · `422` nothing to change |

`UserOut`: `id, username, display_name, email, is_admin, auth_source, is_active, created_at`.
There is **no** `DELETE /users/{id}`: disable with `PATCH {"is_active": false}`.

**Token in query string:** every endpoint also accepts the session token as `?api_key=<token>`. The frontend uses this for downloads, `<img>` and the PDF viewer.

---

## 8. File list

**Backend**

| | File | Purpose |
|---|---|---|
| N | `backend/app/services/ldap_service.py` | AD search, lookup, password verification |
| N | `backend/app/api/v1/users.py` | Users API (list, AD search, add, role, enable/disable) |
| N | `backend/app/core/sso_cors.py` | Credentialed CORS for `/auth/sso` (trusted origins only) |
| M | `backend/app/api/v1/auth.py` | Login, first-run setup, admin seed, SSO, `/me` (complete file in §10) |
| M | `backend/app/core/security.py` | Disabled users' tokens rejected; `require_admin` (complete file in §10) |
| M | `backend/app/core/config.py` | Security / LDAP / SSO settings |
| M | `backend/app/core/network_guard.py` | `allow_host()` for the AD server |
| M | `backend/app/models/models.py` | `User.auth_source`, `display_name`, `is_active`, `enabled` |
| M | `backend/app/schemas/schemas.py` | `UserOut`, `DirectoryUserOut`, `UserCreate`, `UserUpdate` |
| M | `backend/app/main.py` | Users router, SSO CORS middleware, startup logs |
| M | `backend/requirements/base.txt` | `ldap3`, `pyspnego[kerberos]` |
| M | `backend/Dockerfile` | `gcc`, `libkrb5-dev` |

**Frontend**

| | File | Purpose |
|---|---|---|
| N | `frontend/app/(app)/users/page.tsx` | Users page (list, AD search/add, role, disable modal, enable) |
| N | `frontend/app/setup/page.tsx` | First-run "Create administrator" screen |
| N | `frontend/components/login-showcase.tsx` | Animated backdrop + logo for login/setup |
| N | `frontend/assets/uae-emblem.png` | Emblem on the sample certificate (binary: copy the file) |
| M | `frontend/app/login/page.tsx` | Login page (complete file in §12) |
| M | `frontend/components/auth-guard.tsx` | Setup redirect → Windows SSO → login redirect (complete file) |
| M | `frontend/app/layout.tsx` | Disables browser auto-translate (complete file) |
| M | `frontend/lib/api.ts` | Token/SSO helpers, `authUrl`, setup and users API |
| M | `frontend/lib/types.ts` | `LoginResponse`, `AuthMe`, `AppUser`, `DirectoryUser` |
| M | `frontend/lib/i18n.tsx` | `nav.users`, `auth.*`, `setup.*`, `users.*`, `login.*` keys (EN + AR) |
| M | `frontend/components/sidebar.tsx` | "Users" menu item; account row refresh |
| M | `frontend/components/document-viewer.tsx` | Page images via `authUrl()` |
| M | `frontend/app/globals.css` | Login animation styles |

**Deployment:** `docker-compose.yml`, `.env.example` (§13).

---

## 9. Backend: new files

**`backend/app/services/ldap_service.py`** (complete file)

```python
"""Active Directory lookups and password verification (ldap3, pure Python).

Flow used everywhere:
  1. bind with the read-only service account (LDAP_BIND_USER / LDAP_BIND_PASSWORD)
  2. search the directory (user picker, or resolve a login name to its DN)
  3. for logins, re-bind as the user's DN with the supplied password — AD decides.

Disabled AD accounts are filtered out of every search, so they can neither be
added nor sign in.
"""

import logging
from dataclasses import dataclass
from typing import Optional
from urllib.parse import urlparse

from ldap3 import DSA, SIMPLE, SUBTREE, Connection, Server
from ldap3.core.exceptions import LDAPException
from ldap3.utils.conv import escape_filter_chars

from app.core import network_guard
from app.core.config import settings

logger = logging.getLogger("ocr.ldap")

# Enabled AD user accounts only (bit 2 of userAccountControl = ACCOUNTDISABLE).
_USER_FILTER = "(&(objectCategory=person)(objectClass=user)(!(userAccountControl:1.2.840.113556.1.4.803:=2)))"
_ATTRIBUTES = ["sAMAccountName", "userPrincipalName", "displayName", "mail", "department", "title"]

_base_dn_cache: Optional[str] = None


class LdapError(Exception):
    """Directory unreachable or misconfigured (not a wrong password)."""


@dataclass
class LdapUser:
    username: str  # sAMAccountName — the login name stored in our DB
    dn: str
    display_name: Optional[str] = None
    email: Optional[str] = None
    upn: Optional[str] = None
    department: Optional[str] = None
    title: Optional[str] = None


def normalize_username(raw: str) -> str:
    """Accept 'jdoe', 'DEV\\jdoe' or 'jdoe@dev.team.ae' and return 'jdoe'."""
    name = (raw or "").strip()
    if "\\" in name:
        name = name.split("\\", 1)[1]
    if "@" in name:
        name = name.split("@", 1)[0]
    return name.strip()


def _server() -> Server:
    host = urlparse(settings.LDAP_SERVER).hostname or settings.LDAP_SERVER
    # The offline guard blocks public IPs; the DC is an explicitly trusted host.
    network_guard.allow_host(host)
    return Server(settings.LDAP_SERVER, get_info=DSA, connect_timeout=settings.LDAP_TIMEOUT_S)


def _bind(server: Server, user: str, password: str) -> Optional[Connection]:
    """Return a bound connection, None on bad credentials, LdapError when unreachable."""
    conn = Connection(
        server,
        user=user,
        password=password,
        authentication=SIMPLE,
        receive_timeout=settings.LDAP_TIMEOUT_S,
        raise_exceptions=False,
    )
    try:
        conn.open()
        if settings.LDAP_USE_STARTTLS:
            conn.start_tls()
        if conn.bind():
            return conn
    except (LDAPException, OSError) as exc:
        conn.unbind()
        raise LdapError(f"Active Directory is unreachable ({settings.LDAP_SERVER}): {exc}") from exc
    conn.unbind()
    return None


def _service_connection() -> Connection:
    if not settings.LDAP_ENABLED:
        raise LdapError("Active Directory integration is disabled (LDAP_ENABLED=false).")
    if not settings.LDAP_BIND_USER or not settings.LDAP_BIND_PASSWORD:
        raise LdapError("LDAP_BIND_USER / LDAP_BIND_PASSWORD are not configured.")
    conn = _bind(_server(), settings.LDAP_BIND_USER, settings.LDAP_BIND_PASSWORD)
    if conn is None:
        raise LdapError("The LDAP service account was rejected by Active Directory.")
    return conn


def _base_dn(conn: Connection) -> str:
    global _base_dn_cache
    if settings.LDAP_BASE_DN:
        return settings.LDAP_BASE_DN
    if _base_dn_cache is None:
        info = conn.server.info
        values = info.other.get("defaultNamingContext") if info is not None else None
        if not values:
            raise LdapError("Could not read defaultNamingContext from AD; set LDAP_BASE_DN.")
        _base_dn_cache = values[0]
    return _base_dn_cache


def directory_domains() -> set[str]:
    """Kerberos realm + NetBIOS name implied by the base DN (DC=dev,DC=team,DC=ae -> DEV.TEAM.AE, DEV)."""
    base = settings.LDAP_BASE_DN or _base_dn_cache
    if not base:
        conn = _service_connection()
        try:
            base = _base_dn(conn)
        finally:
            conn.unbind()
    labels = [part.split("=", 1)[1] for part in base.split(",") if part.strip().upper().startswith("DC=")]
    if not labels:
        return set()
    return {".".join(labels).upper(), labels[0].upper()}


def _first(attrs: dict, name: str) -> Optional[str]:
    value = attrs.get(name)
    if isinstance(value, list):
        value = value[0] if value else None
    return str(value) if value else None


def _search(conn: Connection, condition: str, limit: int) -> list[LdapUser]:
    try:
        ok = conn.search(
            _base_dn(conn),
            f"(&{_USER_FILTER}{condition})",
            search_scope=SUBTREE,
            attributes=_ATTRIBUTES,
            size_limit=limit,
        )
    except (LDAPException, OSError) as exc:
        raise LdapError(f"Active Directory search failed: {exc}") from exc
    # sizeLimitExceeded still returns the first `limit` entries — that's fine.
    if not ok and conn.result.get("result") not in (0, 4):
        raise LdapError(f"Active Directory search failed: {conn.result.get('description')}")
    users = []
    for entry in conn.response or []:
        if entry.get("type") != "searchResEntry":
            continue  # skip referrals
        attrs = entry["attributes"]
        username = _first(attrs, "sAMAccountName")
        if not username:
            continue
        users.append(
            LdapUser(
                username=username,
                dn=entry["dn"],
                display_name=_first(attrs, "displayName"),
                email=_first(attrs, "mail"),
                upn=_first(attrs, "userPrincipalName"),
                department=_first(attrs, "department"),
                title=_first(attrs, "title"),
            )
        )
    return users


def search_users(query: str, limit: int = 25) -> list[LdapUser]:
    """Directory picker: match login name, display name, e-mail or first/last name."""
    q = escape_filter_chars(query.strip())
    if not q:
        return []
    condition = (
        f"(|(sAMAccountName=*{q}*)(displayName=*{q}*)(mail=*{q}*)"
        f"(userPrincipalName={q}*)(givenName={q}*)(sn={q}*))"
    )
    conn = _service_connection()
    try:
        return _search(conn, condition, limit)
    finally:
        conn.unbind()


def find_user(username: str) -> Optional[LdapUser]:
    """Exact lookup by login name (sAMAccountName). None = not in AD or disabled."""
    name = escape_filter_chars(normalize_username(username))
    if not name:
        return None
    conn = _service_connection()
    try:
        found = _search(conn, f"(sAMAccountName={name})", 2)
    finally:
        conn.unbind()
    return found[0] if len(found) == 1 else None


def authenticate(username: str, password: str) -> Optional[LdapUser]:
    """Verify the password against AD. None = unknown/disabled user or wrong password."""
    # An empty password would be an "unauthenticated bind" that AD reports as
    # successful — never let it through.
    if not password:
        return None
    user = find_user(username)
    if user is None:
        return None
    conn = _bind(_server(), user.dn, password)
    if conn is None:
        return None
    conn.unbind()
    return user
```

**`backend/app/api/v1/users.py`** (complete file)

```python
"""User management: search Active Directory and register users in the application.

Only registered, enabled users can sign in (AD users only while they still exist in AD).
Users are never deleted — an admin disables them and can enable them again.
All endpoints require a signed-in administrator.
"""

import logging

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.api.v1.auth import find_user
from app.core.database import get_db
from app.core.security import require_admin
from app.models.models import User
from app.schemas import schemas
from app.services import ldap_service

logger = logging.getLogger("ocr.users")

router = APIRouter(prefix="/users", tags=["users"])


def _directory_error(exc: ldap_service.LdapError) -> HTTPException:
    return HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail=str(exc))


@router.get("", response_model=list[schemas.UserOut])
def list_users(db: Session = Depends(get_db), _: dict = Depends(require_admin)):
    return db.query(User).order_by(User.created_at.asc()).all()


@router.get("/directory", response_model=list[schemas.DirectoryUserOut])
def search_directory(
    q: str = Query(..., min_length=2, max_length=64),
    limit: int = Query(25, ge=1, le=100),
    db: Session = Depends(get_db),
    _: dict = Depends(require_admin),
):
    try:
        found = ldap_service.search_users(q, limit)
    except ldap_service.LdapError as exc:
        raise _directory_error(exc) from exc
    registered = {
        (u.username or "").lower() for u in db.query(User.username).filter(User.username.isnot(None)).all()
    }
    return [
        schemas.DirectoryUserOut(
            username=u.username,
            display_name=u.display_name,
            email=u.email,
            upn=u.upn,
            department=u.department,
            title=u.title,
            registered=u.username.lower() in registered,
        )
        for u in found
    ]


@router.post("", response_model=schemas.UserOut, status_code=201)
def add_user(payload: schemas.UserCreate, db: Session = Depends(get_db), admin: dict = Depends(require_admin)):
    try:
        ad_user = ldap_service.find_user(payload.username)
    except ldap_service.LdapError as exc:
        raise _directory_error(exc) from exc
    if ad_user is None:
        raise HTTPException(status_code=404, detail="User not found in Active Directory (or the account is disabled).")
    existing = find_user(db, ad_user.username)
    if existing is not None:
        detail = (
            "User is already registered."
            if existing.enabled
            else "User is already registered but disabled. Enable them instead."
        )
        raise HTTPException(status_code=409, detail=detail)

    email = ad_user.email
    if email and db.query(User).filter(User.email == email).first() is not None:
        email = None  # e-mail is informational; never block registration on it
    user = User(
        username=ad_user.username,
        display_name=ad_user.display_name,
        email=email,
        # AD users never authenticate locally; this value can't match any bcrypt check.
        hashed_password="!ldap",
        is_admin=payload.is_admin,
        auth_source="ldap",
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    logger.info("USERS - %s added %s (admin=%s)", admin["username"], user.username, user.is_admin)
    return user


@router.patch("/{user_id}", response_model=schemas.UserOut)
def update_user(
    user_id: str, payload: schemas.UserUpdate, db: Session = Depends(get_db), admin: dict = Depends(require_admin)
):
    """Change a user's role and/or enable/disable them. Users are never deleted."""
    if payload.is_admin is None and payload.is_active is None:
        raise HTTPException(status_code=422, detail="Nothing to change.")
    user = db.get(User, user_id)
    if user is None:
        raise HTTPException(status_code=404, detail="User not found.")
    if user.username == admin["username"]:
        # The acting admin always stays an active admin, so nobody can lock everyone out.
        raise HTTPException(status_code=400, detail="You cannot change your own account.")
    if payload.is_admin is not None:
        user.is_admin = payload.is_admin
    if payload.is_active is not None:
        # Disabled users cannot sign in and their existing sessions stop working
        # immediately (tokens are checked against the users table on every request).
        user.is_active = payload.is_active
    db.commit()
    db.refresh(user)
    logger.info(
        "USERS - %s updated %s (admin=%s, active=%s)", admin["username"], user.username, user.is_admin, user.enabled
    )
    return user
```

**`backend/app/core/sso_cors.py`** (complete file)

```python
"""CORS for the Windows sign-in endpoint.

The frontend calls /auth/sso with `credentials: "include"` so the browser
attaches the user's Kerberos ticket. A credentialed response must name one
explicit origin — and only trusted ones: if any origin were accepted, any
website an employee visits could silently mint a session for them. The global
CORSMiddleware answers "*" (unusable with credentials), so this outer
middleware rewrites the headers for the SSO path only, using CORS_ORIGINS.
"""

from starlette.datastructures import Headers, MutableHeaders
from starlette.types import ASGIApp, Message, Receive, Scope, Send


class SSOCorsMiddleware:
    def __init__(self, app: ASGIApp, paths: set[str], trusted_origins: list[str]) -> None:
        self.app = app
        self.paths = paths
        self.trusted = set(trusted_origins)

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http" or scope["path"] not in self.paths:
            await self.app(scope, receive, send)
            return
        origin = Headers(scope=scope).get("origin")

        async def send_wrapper(message: Message) -> None:
            if message["type"] == "http.response.start":
                headers = MutableHeaders(scope=message)
                for name in ("access-control-allow-origin", "access-control-allow-credentials"):
                    if name in headers:
                        del headers[name]
                if origin and origin in self.trusted:
                    headers["Access-Control-Allow-Origin"] = origin
                    headers["Access-Control-Allow-Credentials"] = "true"
                    headers.add_vary_header("Origin")
            await send(message)

        await self.app(scope, receive, send_wrapper)
```

---

## 10. Backend: modified files

### 10.1 `backend/app/api/v1/auth.py`

Replace the whole file.

**`backend/app/api/v1/auth.py`** (complete file)

```python
import base64
import binascii
import logging
import re
import threading
from typing import Optional

import spnego
from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from spnego.exceptions import SpnegoError
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.database import SessionLocal, get_db
from app.core.security import create_access_token, current_identity, hash_password, verify_password
from app.models.models import User
from app.services import ldap_service

logger = logging.getLogger("ocr.auth")

router = APIRouter(prefix="/auth", tags=["auth"])


class LoginRequest(BaseModel):
    username: str
    password: str


class SetupRequest(BaseModel):
    username: str
    password: str


USERNAME_RE = re.compile(r"[A-Za-z0-9._-]{3,64}")
MIN_PASSWORD_LENGTH = 6
_setup_lock = threading.Lock()


def find_user(db: Session, username: str) -> Optional[User]:
    """Case-insensitive lookup — AD login names are case-insensitive."""
    return db.query(User).filter(func.lower(User.username) == username.strip().lower()).first()


def is_local(user: User) -> bool:
    """Local accounts (first-run setup / ADMIN_PASSWORD seed) use a local password, never AD."""
    return (user.auth_source or "") == "local"


def setup_required(db: Session) -> bool:
    """First-run state: no users at all -> the UI shows the "create administrator" screen."""
    return db.query(User.id).first() is None


def ensure_admin(db: Session) -> Optional[str]:
    """Seed/repair a local administrator from ADMIN_USERNAME / ADMIN_PASSWORD (idempotent).

    Only runs when ADMIN_PASSWORD is set; the stored hash is then re-synced on
    every start. When it is empty nothing is seeded and, while the users table
    is empty, the first-run setup screen creates the first administrator.
    """
    password = settings.ADMIN_PASSWORD or ""
    if not password.strip():
        if setup_required(db):
            logger.warning("ADMIN - no users yet: open the web app to create the first administrator")
        return None

    username = (settings.ADMIN_USERNAME or "administrator").strip()
    user = find_user(db, username)
    if user is not None:
        user.auth_source = "local"
        user.is_admin = True
        if not verify_password(password, user.hashed_password):
            user.hashed_password = hash_password(password)
            logger.info("ADMIN - password for %s re-synced from ADMIN_PASSWORD", user.username)
        db.commit()
        return user.username

    db.add(
        User(
            username=username,
            email=f"{username}@local",
            hashed_password=hash_password(password),
            is_admin=True,
            auth_source="local",
            display_name="Local administrator",
        )
    )
    db.commit()
    logger.info("ADMIN - local administrator created. username=%s (password from ADMIN_PASSWORD)", username)
    return username


def backfill_user_flags(db: Session) -> None:
    """Rows created before users.is_active existed are active."""
    count = db.query(User).filter(User.is_active.is_(None)).update({User.is_active: True})
    if count:
        db.commit()
        logger.info("USERS - marked %d existing user(s) as active", count)


def ensure_admin_once() -> Optional[str]:
    with SessionLocal() as db:
        backfill_user_flags(db)
        return ensure_admin(db)


def _invalid() -> HTTPException:
    return HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid username or password.")


def _disabled() -> HTTPException:
    # Only raised after the credentials were verified, so it reveals nothing to a guesser.
    return HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail="This account is disabled. Contact the administrator.",
    )


@router.post("/login")
def login(payload: LoginRequest, db: Session = Depends(get_db)) -> dict:
    # Local accounts are verified here, never against AD.
    user = find_user(db, payload.username) if payload.username.strip() else None
    if user is not None and is_local(user):
        if not verify_password(payload.password, user.hashed_password):
            logger.warning("AUTH - local login failed for %s", user.username)
            raise _invalid()
        if not user.enabled:
            logger.warning("AUTH - login refused, %s is disabled", user.username)
            raise _disabled()
        return _session(user)

    # Everyone else must exist in our DB (added by an admin) AND in AD.
    username = ldap_service.normalize_username(payload.username)
    user = find_user(db, username) if username else None
    if user is None:
        logger.warning("AUTH - login refused, %s is not registered in the application", username)
        raise _invalid()
    if is_local(user):
        # e.g. "DEV\administrator": a local account must never be unlocked by an AD password.
        logger.warning("AUTH - %s is a local account; AD-style login refused", user.username)
        raise _invalid()
    try:
        ad_user = ldap_service.authenticate(username, payload.password)
    except ldap_service.LdapError as exc:
        logger.error("AUTH - AD unavailable during login of %s: %s", username, exc)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Active Directory is unavailable. Try again later or contact the administrator.",
        ) from exc
    if ad_user is None:
        logger.warning("AUTH - AD rejected login for %s (wrong password, disabled or removed)", username)
        raise _invalid()
    if not user.enabled:
        logger.warning("AUTH - login refused, %s is disabled in the application", user.username)
        raise _disabled()
    if ad_user.display_name and ad_user.display_name != user.display_name:
        user.display_name = ad_user.display_name
        db.commit()
    return _session(user)


@router.get("/setup")
def setup_status(db: Session = Depends(get_db)) -> dict:
    return {"setup_required": setup_required(db)}


@router.post("/setup", status_code=201)
def create_first_admin(payload: SetupRequest, db: Session = Depends(get_db)) -> dict:
    """First-run setup: create the first (local) administrator. Only allowed while no users exist."""
    username = payload.username.strip()
    if not USERNAME_RE.fullmatch(username):
        raise HTTPException(
            status_code=422,
            detail="User name must be 3-64 characters: letters, digits, dot, dash or underscore.",
        )
    if len(payload.password) < MIN_PASSWORD_LENGTH:
        raise HTTPException(
            status_code=422, detail=f"Password must be at least {MIN_PASSWORD_LENGTH} characters."
        )
    with _setup_lock:  # two simultaneous first-run requests must not both create an admin
        if not setup_required(db):
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Setup has already been completed.")
        user = User(
            username=username,
            hashed_password=hash_password(payload.password),
            is_admin=True,
            auth_source="local",
            display_name="Local administrator",
        )
        db.add(user)
        db.commit()
    logger.warning("ADMIN - first administrator %s created through first-run setup", username)
    return {"username": username, "is_admin": True}


def _session(user: User) -> dict:
    token = create_access_token(user.username, settings.JWT_EXPIRES_MINUTES)
    return {
        "access_token": token,
        "token_type": "bearer",
        "expires_in": settings.JWT_EXPIRES_MINUTES * 60,
        "username": user.username,
        "display_name": user.display_name,
        "is_admin": user.is_admin,
        "auth_required": settings.REQUIRE_AUTH or settings.REQUIRE_API_KEY,
    }


def _sso_refused(detail: str) -> JSONResponse:
    # Deliberately no WWW-Authenticate header: re-challenging after a failed
    # attempt makes browsers pop up a credentials dialog. The frontend falls
    # back to the login page instead.
    return JSONResponse(status_code=status.HTTP_401_UNAUTHORIZED, content={"detail": detail})


def _split_principal(principal: str) -> tuple[str, str]:
    r"""'jdoe@DEV.TEAM.AE' or 'DEV\jdoe' -> ('jdoe', 'DEV.TEAM.AE' / 'DEV')."""
    if "\\" in principal:
        domain, name = principal.split("\\", 1)
    elif "@" in principal:
        name, domain = principal.rsplit("@", 1)
    else:
        name, domain = principal, ""
    return name.strip(), domain.strip().upper()


@router.get("/sso")
def windows_sso(request: Request, db: Session = Depends(get_db)):
    """Windows integrated sign-in (Kerberos via SPNEGO "Negotiate").

    1st call (no ticket)  -> 401 + WWW-Authenticate: Negotiate (browser attaches the ticket and retries)
    2nd call (ticket)     -> validate ticket, require the user in our DB AND enabled in AD -> session
    Anything else         -> 401 without a challenge, so the frontend shows the login page.
    """
    if not (settings.SSO_ENABLED and settings.LDAP_ENABLED):
        return _sso_refused("Windows sign-in is disabled.")
    header = request.headers.get("Authorization", "")
    if not header.lower().startswith("negotiate "):
        return JSONResponse(
            status_code=status.HTTP_401_UNAUTHORIZED,
            content={"detail": "Windows credentials required."},
            headers={"WWW-Authenticate": "Negotiate"},
        )

    try:
        in_token = base64.b64decode(header.split(" ", 1)[1].strip(), validate=True)
        ctx = spnego.server(protocol="negotiate", service="HTTP")
        out_token = ctx.step(in_token)
    except (binascii.Error, SpnegoError) as exc:
        logger.warning("SSO - ticket rejected: %s", exc)
        return _sso_refused("Windows sign-in failed.")
    except Exception as exc:  # missing keytab / GSSAPI library, etc.
        logger.error("SSO - Kerberos acceptor unavailable: %s", exc)
        return _sso_refused("Windows sign-in is not available on this server.")
    if not ctx.complete:
        # NTLM fallback needs a connection-bound multi-leg exchange — only Kerberos is supported.
        logger.warning("SSO - incomplete handshake (browser offered NTLM instead of Kerberos?)")
        return _sso_refused("Windows sign-in failed (Kerberos ticket required).")

    username, domain = _split_principal(ctx.client_principal or "")
    try:
        allowed = set(settings.sso_domain_list) or ldap_service.directory_domains()
        if not username or domain not in allowed:
            logger.warning("SSO - principal %s is outside the allowed domains %s", ctx.client_principal, allowed)
            return _sso_refused("Windows account is not from an allowed domain.")
        user = find_user(db, username)
        if user is None or is_local(user):
            logger.warning("SSO - %s is not registered in the application", username)
            return _sso_refused("Windows account is not registered in the application.")
        ad_user = ldap_service.find_user(username)
    except ldap_service.LdapError as exc:
        logger.error("SSO - AD unavailable during sign-in of %s: %s", username, exc)
        return _sso_refused("Active Directory is unavailable.")
    if ad_user is None:
        logger.warning("SSO - %s is disabled or missing in AD", username)
        return _sso_refused("Windows account is disabled or missing in Active Directory.")
    if not user.enabled:
        logger.warning("SSO - %s is disabled in the application", username)
        return _sso_refused("This account is disabled. Contact the administrator.")
    if ad_user.display_name and ad_user.display_name != user.display_name:
        user.display_name = ad_user.display_name
        db.commit()

    logger.info("SSO - %s signed in with Windows credentials", user.username)
    headers = {"WWW-Authenticate": "Negotiate " + base64.b64encode(out_token).decode()} if out_token else None
    return JSONResponse(content=_session(user), headers=headers)


@router.get("/me")
def me(request: Request, db: Session = Depends(get_db)) -> dict:
    """Identity probe for the frontend auth guard.

    - When a valid login JWT / API key is present -> authenticated.
    - When no credential is passed but auth is off -> anonymous (allowed).
    - When no/expired credential is passed and auth is on -> authenticated=false.
    """
    auth_required = settings.REQUIRE_AUTH or settings.REQUIRE_API_KEY
    identity = current_identity(request, db)
    if identity is not None:
        return {
            "authenticated": True,
            "kind": identity["kind"],
            "username": identity["username"],
            "is_admin": bool(identity["is_admin"]),
            "auth_required": auth_required,
            "setup_required": False,
        }
    return {
        "authenticated": False if auth_required else True,
        "kind": None if auth_required else "anonymous",
        "username": None,
        "is_admin": False,
        "auth_required": auth_required,
        "setup_required": setup_required(db),
    }
```

### 10.2 `backend/app/core/security.py`

Replace the whole file. Key parts: `_verify_credentials` rejects tokens of disabled users (`user.enabled`); new `require_admin` dependency at the end.

**`backend/app/core/security.py`** (complete file)

```python
import hashlib
import secrets
from datetime import datetime, timedelta, timezone
from typing import Optional

import bcrypt
from fastapi import Depends, HTTPException, Request, status
from jose import JWTError, jwt
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.database import get_db

ALGORITHM = "HS256"
API_KEY_PREFIX = "ocr_live_"


def generate_api_key() -> tuple[str, str]:
    """Return (plain_key, sha256_hash). The plain key is shown to the user once."""
    plain = API_KEY_PREFIX + secrets.token_urlsafe(32)
    return plain, hash_api_key(plain)


def hash_api_key(plain_key: str) -> str:
    return hashlib.sha256(plain_key.encode("utf-8")).hexdigest()


def hash_password(plain: str) -> str:
    """bcrypt hash for local user passwords (self-contained — fully offline)."""
    return bcrypt.hashpw(plain.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(plain: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))
    except (ValueError, TypeError):
        return False


def create_access_token(subject: str, expires_minutes: Optional[int] = None) -> str:
    minutes = expires_minutes if expires_minutes is not None else settings.JWT_EXPIRES_MINUTES
    expire = datetime.now(timezone.utc) + timedelta(minutes=minutes)
    payload = {"sub": subject, "exp": expire}
    return jwt.encode(payload, settings.JWT_SECRET, algorithm=ALGORITHM)


def decode_access_token(token: str) -> Optional[str]:
    try:
        payload = jwt.decode(token, settings.JWT_SECRET, algorithms=[ALGORITHM])
        return payload.get("sub")
    except JWTError:
        return None


def _extract_bearer(request: Request) -> Optional[str]:
    auth = request.headers.get("Authorization", "")
    if auth.lower().startswith("bearer "):
        return auth[7:].strip()
    # also allow ?api_key= for simple curl testing
    return request.query_params.get("api_key")


def _verify_credentials(key: str, db: Session) -> Optional[dict]:
    """Resolve a bearer token as either a login JWT (user) or an API key.

    Returns an identity dict or None when the credential is not valid.
    """
    # 1) Login JWTs issued by /api/v1/auth/login — sub carries the username.
    subject = decode_access_token(key)
    if subject is not None:
        from app.models.models import User

        user = db.query(User).filter(User.username == subject).first()
        if user is not None and user.enabled:
            return {"kind": "user", "username": user.username, "is_admin": user.is_admin}
        return None  # validly signed, but the user no longer exists or was disabled

    # 2) API keys created via POST /api-keys (hash stored, one-way).
    from app.models.models import APIKey

    record = db.query(APIKey).filter(APIKey.key_hash == hash_api_key(key), APIKey.revoked.is_(False)).first()
    if record is None:
        return None
    record.last_used_at = datetime.now(timezone.utc)
    db.commit()
    return {"kind": "api_key", "username": None, "is_admin": False}


def require_auth(request: Request, db: Session = Depends(get_db)) -> None:
    """Dependency guarding /api/v1 endpoints.

    Allowed when both REQUIRE_AUTH and REQUIRE_API_KEY are off (default local dev).
    When either is on, a valid login JWT OR a valid API key is required.
    """
    if not (settings.REQUIRE_AUTH or settings.REQUIRE_API_KEY):
        return

    key = _extract_bearer(request)
    if not key:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required. Pass 'Authorization: Bearer <token>'.",
        )
    if _verify_credentials(key, db) is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid, expired or revoked credential.")


def current_identity(request: Request, db: Session = Depends(get_db)) -> Optional[dict]:
    """Resolve the caller's identity (if any). Used by GET /api/v1/auth/me."""
    key = _extract_bearer(request)
    if not key:
        return None
    return _verify_credentials(key, db)


def require_admin(request: Request, db: Session = Depends(get_db)) -> dict:
    """Dependency for user management: always needs a logged-in administrator,
    even when REQUIRE_AUTH is off (API keys never qualify)."""
    identity = current_identity(request, db)
    if identity is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Sign in as an administrator.")
    if identity["kind"] != "user" or not identity["is_admin"]:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Administrator rights required.")
    return identity
```

### 10.3 `backend/app/core/config.py`

Replace the security section of `Settings` with:

```python
    # ---- Security ----
    JWT_SECRET: str = "CHANGE_ME"
    REQUIRE_API_KEY: bool = False
    REQUIRE_AUTH: bool = True  # true = /api/v1 needs a logged-in user OR an API key
    # Optional local administrator seed (local password, never AD). Only created
    # when ADMIN_PASSWORD is set; its password is then re-synced on every start.
    # Empty = no seed: while no users exist, the web app shows a first-run
    # "create administrator" screen instead.
    ADMIN_USERNAME: str = "administrator"
    ADMIN_PASSWORD: str = ""
    JWT_EXPIRES_MINUTES: int = 60 * 12
    RATE_LIMIT_PER_MINUTE: int = 120

    # ---- Active Directory (LDAP) ----
    # Users are searched in AD and added to the local DB by an admin. Login then
    # requires the account to exist in BOTH the DB and AD (password checked by AD).
    # Local accounts (first-run admin / ADMIN_PASSWORD seed) never go to AD.
    LDAP_ENABLED: bool = True
    LDAP_SERVER: str = "ldap://dev.team.ae"  # ldap://host[:389] or ldaps://host[:636]
    LDAP_USE_STARTTLS: bool = False
    LDAP_BASE_DN: str = ""  # empty = read defaultNamingContext from the server
    # Service account used to search the directory (UPN, DOMAIN\user or full DN).
    LDAP_BIND_USER: str = ""
    LDAP_BIND_PASSWORD: str = ""
    LDAP_TIMEOUT_S: int = 10

    # ---- Windows single sign-on (Kerberos / SPNEGO "Negotiate") ----
    # The browser sends the signed-in Windows user's Kerberos ticket; the user
    # must still be registered in the DB and enabled in AD. Linux needs a keytab
    # for HTTP/<api-host> (KRB5_KTNAME); a Windows host uses its own SSPI identity.
    SSO_ENABLED: bool = True
    # Accepted Kerberos realms / NetBIOS domains (comma separated).
    # Empty = derived from the AD base DN, e.g. DC=dev,DC=team,DC=ae -> DEV.TEAM.AE, DEV
    SSO_DOMAINS: str = ""
    CORS_ORIGINS: str = "http://localhost:3000"
```

And add this property next to `cors_origin_list`:

```python
    @property
    def sso_domain_list(self) -> list[str]:
        return [d.strip().upper() for d in self.SSO_DOMAINS.split(",") if d.strip()]
```

### 10.4 `backend/app/core/network_guard.py`

Add after `_ip_allowed()` (the offline guard blocks public IPs; the AD server is allow-listed right before each connection):

```python
def allow_host(host: str) -> None:
    """Trust the current IPs of one explicitly configured host (e.g. the AD domain controller).

    Resolved on every call so DNS changes are picked up; unresolvable hosts are ignored
    (the subsequent connect fails with a normal DNS error).
    """
    try:
        infos = socket.getaddrinfo(host, None)
    except socket.gaierror:
        return
    for info in infos:
        ip = ipaddress.ip_address(info[4][0].split("%")[0])
        if not _ip_allowed(ip):
            _ALLOWED_NETWORKS.append(ipaddress.ip_network(ip))
```

### 10.5 `backend/app/models/models.py`

The complete `User` class:

```python
class User(Base):
    __tablename__ = "users"

    id = sa.Column(sa.String(36), primary_key=True, default=_uuid)
    # username is the login identifier; email is optional metadata (kept nullable
    # because the table predates login and may have been created without it).
    username = sa.Column(sa.String(128), unique=True, nullable=True, index=True)
    email = sa.Column(sa.String(255), unique=True, nullable=True, index=True)
    hashed_password = sa.Column(sa.String(255), nullable=False)
    is_admin = sa.Column(sa.Boolean, nullable=False, default=False)
    # "local" = password checked here (first-run admin / local users); "ldap" = checked by AD.
    auth_source = sa.Column(sa.String(16), nullable=True, default="ldap")
    display_name = sa.Column(sa.String(255), nullable=True)
    # False = disabled by an admin: cannot sign in, existing sessions stop working.
    # Users are never deleted, only disabled (and can be enabled again).
    is_active = sa.Column(sa.Boolean, nullable=True, default=True)
    created_at = sa.Column(sa.DateTime(timezone=True), default=_utcnow)

    @property
    def enabled(self) -> bool:
        # NULL = row created before the column existed -> active.
        return self.is_active is not False
```

### 10.6 `backend/app/schemas/schemas.py`

Add before the engines section (`Any`, `Optional`, `Field`, `field_validator` are already imported in this file):

```python
# ---------- Users / Active Directory ----------


class UserOut(BaseModel):
    id: str
    username: Optional[str] = None
    display_name: Optional[str] = None
    email: Optional[str] = None
    is_admin: bool
    auth_source: Optional[str] = None
    is_active: bool = True
    created_at: Optional[datetime] = None

    model_config = {"from_attributes": True}

    @field_validator("is_active", mode="before")
    @classmethod
    def _null_is_active(cls, v: Any) -> Any:
        return True if v is None else v  # rows created before the column existed


class DirectoryUserOut(BaseModel):
    username: str
    display_name: Optional[str] = None
    email: Optional[str] = None
    upn: Optional[str] = None
    department: Optional[str] = None
    title: Optional[str] = None
    registered: bool  # already added to the application


class UserCreate(BaseModel):
    username: str = Field(min_length=1, max_length=128)  # AD login name (sAMAccountName)
    is_admin: bool = False


class UserUpdate(BaseModel):
    """Change role and/or status. Users are never deleted: is_active=false disables them."""

    is_admin: Optional[bool] = None
    is_active: Optional[bool] = None
```

### 10.7 `backend/app/main.py`

Imports:

```python
import os
from app.api.v1 import apikeys, auth, benchmark, corrections, engines, languages, ocr, stats, system, users
from app.core.sso_cors import SSOCorsMiddleware
```

Middleware (after `app.add_middleware(RateLimitMiddleware)`; it must be added **last** so it is the outermost):

```python
# Added last = outermost: fixes CORS on the credentialed Windows sign-in call.
app.add_middleware(SSOCorsMiddleware, paths={"/api/v1/auth/sso"}, trusted_origins=settings.cors_origin_list)
```

Startup handler (`ensure_admin_once()` creates/repairs the seeded admin and back-fills `is_active`):

```python
@app.on_event("startup")
def on_startup() -> None:
    ensure_schema()
    auth.ensure_admin_once()
    # Inline mode runs OCR in this process: cap its thread budget too. In celery
    # mode the API does no OCR, so skip (avoids importing torch into the API).
    threads = None
    if settings.WORKER_MODE != "celery":
        from app.services.resources import apply_thread_budget

        threads = apply_thread_budget()
    logger.info(
        "API ready | env=%s offline=%s network_access=%s guard=%s models=%s storage=%s threads=%s",
        settings.APP_ENV,
        settings.OFFLINE_MODE,
        settings.NETWORK_ACCESS,
        network_guard.is_installed(),
        settings.models_path,
        settings.STORAGE_PATH,
        threads,
    )
    # Security posture, logged explicitly at startup (also in the worker).
    logger.info("SEC - QARI model source: %s", settings.MODEL_SOURCE.upper())
    logger.info("SEC - Network inference: %s", "DISABLED" if not settings.NETWORK_ACCESS else "ENABLED")
    logger.info("SEC - Automatic downloads: %s", "DISABLED" if not settings.AUTO_DOWNLOAD_MODELS else "ENABLED")
    logger.info(
        "SEC - Auth require_login=%s require_api_key=%s admin_seed=%s",
        settings.REQUIRE_AUTH,
        settings.REQUIRE_API_KEY,
        (settings.ADMIN_USERNAME or "administrator") if settings.ADMIN_PASSWORD else "off (first-run setup)",
    )
    logger.info(
        "SEC - Active Directory enabled=%s server=%s service_account=%s windows_sso=%s keytab=%s",
        settings.LDAP_ENABLED,
        settings.LDAP_SERVER,
        "configured" if settings.LDAP_BIND_USER else "MISSING",
        settings.SSO_ENABLED,
        os.environ.get("KRB5_KTNAME") or "default",
    )
```

Router registration:

```python
app.include_router(auth.router, prefix="/api/v1")
app.include_router(users.router, prefix="/api/v1")
```

### 10.8 `backend/requirements/base.txt`

```text
# --- Security ---
python-jose[cryptography]==3.3.0
passlib[bcrypt]==1.7.4
# Active Directory login / user search (pure Python, no system libs)
ldap3==2.9.1
# Windows SSO (Kerberos/SPNEGO). Windows uses SSPI; Linux pulls gssapi + krb5
# (built against libkrb5-dev, see Dockerfile) and reads the keytab in KRB5_KTNAME.
pyspnego[kerberos]==0.11.2
```

---

## 11. Frontend: new files

**`frontend/app/(app)/users/page.tsx`** (complete file)

```tsx
"use client";

import { useCallback, useEffect, useState } from "react";
import { Plus, Search, ShieldCheck, ShieldOff, Trash2, UserCheck, UserPlus, Users } from "lucide-react";
import { toast } from "sonner";

import { addUser, getAuthMe, listUsers, searchDirectory, setUserActive, setUserAdmin } from "@/lib/api";
import { useI18n } from "@/lib/i18n";
import type { AppUser, DirectoryUser } from "@/lib/types";
import { formatDate } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";

export default function UsersPage() {
  const { t, lang } = useI18n();
  const [users, setUsers] = useState<AppUser[] | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  const [me, setMe] = useState<string | null>(null);
  const [toDisable, setToDisable] = useState<AppUser | null>(null);
  const [busy, setBusy] = useState(false);

  // The signed-in admin cannot disable or demote their own account.
  useEffect(() => {
    getAuthMe()
      .then((m) => setMe(m.username))
      .catch(() => setMe(null));
  }, []);

  const load = useCallback(async () => {
    try {
      setUsers(await listUsers());
      setLoadError(null);
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : t("users.load_failed"));
      setUsers([]);
    }
  }, [t]);

  useEffect(() => {
    load();
  }, [load]);

  const handleRole = async (u: AppUser) => {
    try {
      await setUserAdmin(u.id, !u.is_admin);
      toast.success(t("users.role_updated"));
      load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("users.action_failed"));
    }
  };

  const setActive = async (u: AppUser, active: boolean) => {
    setBusy(true);
    try {
      await setUserActive(u.id, active);
      toast.success(active ? t("users.enabled_ok") : t("users.disabled_ok"));
      setToDisable(null);
      load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("users.action_failed"));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">{t("users.title")}</h1>
          <p className="text-sm text-muted-foreground">{t("users.subtitle")}</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="me-1 h-4 w-4" /> {t("users.add")}
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DirectorySearch
              onAdded={() => {
                load();
              }}
            />
          </DialogContent>
        </Dialog>
      </div>

      {loadError && (
        <p className="rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive">
          {loadError}
        </p>
      )}

      <Card>
        <CardContent className="overflow-x-auto p-0">
          {users === null ? (
            <div className="space-y-2 p-6">
              {Array.from({ length: 3 }).map((_, i) => (
                <Skeleton key={i} className="h-10 w-full" />
              ))}
            </div>
          ) : users.length === 0 ? (
            <div className="flex flex-col items-center py-14 text-center">
              <Users className="h-8 w-8 text-muted-foreground" />
              <p className="mt-2 text-sm text-muted-foreground">{t("users.empty")}</p>
            </div>
          ) : (
            <table className="w-full text-sm">
              <thead className="border-b bg-muted/50 text-xs uppercase text-muted-foreground">
                <tr>
                  <th className="px-4 py-3 text-start">{t("common.name")}</th>
                  <th className="px-4 py-3 text-start">{t("users.login")}</th>
                  <th className="px-4 py-3 text-start">{t("users.email")}</th>
                  <th className="px-4 py-3 text-start">{t("users.source")}</th>
                  <th className="px-4 py-3 text-start">{t("users.role")}</th>
                  <th className="px-4 py-3 text-start">{t("common.status")}</th>
                  <th className="px-4 py-3 text-start">{t("common.created")}</th>
                  <th className="px-4 py-3 text-end">{t("common.actions")}</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {users.map((u) => {
                  const local = u.auth_source === "local";
                  const self = me !== null && u.username === me;
                  return (
                    <tr key={u.id} className={u.is_active ? undefined : "bg-muted/40 text-muted-foreground"}>
                      <td className="px-4 py-3 font-medium">{u.display_name || "—"}</td>
                      <td className="px-4 py-3">
                        <code className="text-xs" dir="ltr">
                          {u.username}
                        </code>
                      </td>
                      <td className="px-4 py-3 text-muted-foreground" dir="ltr">
                        {u.email || "—"}
                      </td>
                      <td className="px-4 py-3">
                        {local ? (
                          <Badge variant="warning">{t("users.source.local")}</Badge>
                        ) : (
                          <Badge variant="info">{t("users.source.ldap")}</Badge>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        {u.is_admin ? (
                          <Badge variant="success">{t("auth.admin")}</Badge>
                        ) : (
                          <Badge variant="secondary">{t("auth.user")}</Badge>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        {u.is_active ? (
                          <Badge variant="success">{t("users.active")}</Badge>
                        ) : (
                          <Badge variant="danger">{t("users.disabled")}</Badge>
                        )}
                      </td>
                      <td className="px-4 py-3 text-muted-foreground">{formatDate(u.created_at, lang)}</td>
                      <td className="whitespace-nowrap px-4 py-3 text-end">
                        <Button
                          variant="ghost"
                          size="icon"
                          disabled={self || !u.is_active}
                          onClick={() => handleRole(u)}
                          title={self ? t("users.self_note") : u.is_admin ? t("users.make_user") : t("users.make_admin")}
                        >
                          {u.is_admin ? <ShieldOff className="h-4 w-4" /> : <ShieldCheck className="h-4 w-4" />}
                        </Button>
                        {u.is_active ? (
                          <Button
                            variant="ghost"
                            size="icon"
                            disabled={self || busy}
                            onClick={() => setToDisable(u)}
                            title={self ? t("users.self_note") : t("users.disable")}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        ) : (
                          <Button
                            variant="ghost"
                            size="icon"
                            disabled={busy}
                            onClick={() => setActive(u, true)}
                            title={t("users.enable")}
                          >
                            <UserCheck className="h-4 w-4 text-emerald-600" />
                          </Button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </CardContent>
      </Card>

      <Dialog open={toDisable !== null} onOpenChange={(o) => !o && setToDisable(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>{t("users.disable_title")}</DialogTitle>
            <DialogDescription>{t("users.disable_confirm")}</DialogDescription>
          </DialogHeader>
          {toDisable && (
            <p className="rounded-md bg-muted px-3 py-2 text-sm">
              <span className="font-medium">{toDisable.display_name || toDisable.username}</span>{" "}
              <code className="text-xs text-muted-foreground" dir="ltr">
                ({toDisable.username})
              </code>
            </p>
          )}
          <p className="text-xs text-muted-foreground">{t("users.disable_note")}</p>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => setToDisable(null)} disabled={busy}>
              {t("users.no")}
            </Button>
            <Button variant="destructive" onClick={() => toDisable && setActive(toDisable, false)} disabled={busy}>
              {t("users.yes")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function DirectorySearch({ onAdded }: { onAdded: () => void }) {
  const { t } = useI18n();
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<DirectoryUser[] | null>(null);
  const [searching, setSearching] = useState(false);
  const [asAdmin, setAsAdmin] = useState(false);
  const [adding, setAdding] = useState<string | null>(null);

  const runSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    const q = query.trim();
    if (q.length < 2 || searching) return;
    setSearching(true);
    try {
      setResults(await searchDirectory(q));
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("users.search_failed"));
      setResults(null);
    } finally {
      setSearching(false);
    }
  };

  const handleAdd = async (u: DirectoryUser) => {
    setAdding(u.username);
    try {
      await addUser(u.username, asAdmin);
      toast.success(`${t("users.added")} — ${u.display_name || u.username}`);
      setResults((rs) => rs?.map((r) => (r.username === u.username ? { ...r, registered: true } : r)) ?? null);
      onAdded();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("users.add_failed"));
    } finally {
      setAdding(null);
    }
  };

  return (
    <>
      <DialogHeader>
        <DialogTitle>{t("users.dialog.title")}</DialogTitle>
        <DialogDescription>{t("users.dialog.desc")}</DialogDescription>
      </DialogHeader>
      <form onSubmit={runSearch} className="flex gap-2">
        <Input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={t("users.dialog.placeholder")}
          autoFocus
          dir="ltr"
        />
        <Button type="submit" disabled={searching || query.trim().length < 2}>
          <Search className="me-1 h-4 w-4" /> {t("common.search")}
        </Button>
      </form>
      <div className="flex items-center gap-2">
        <Checkbox id="as-admin" checked={asAdmin} onCheckedChange={(v) => setAsAdmin(v === true)} />
        <Label htmlFor="as-admin" className="text-sm font-normal">
          {t("users.dialog.as_admin")}
        </Label>
      </div>
      <div className="max-h-80 overflow-y-auto rounded-md border">
        {searching ? (
          <div className="space-y-2 p-4">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-10 w-full" />
            ))}
          </div>
        ) : results === null ? null : results.length === 0 ? (
          <p className="py-8 text-center text-sm text-muted-foreground">{t("users.dialog.no_results")}</p>
        ) : (
          <ul className="divide-y">
            {results.map((u) => (
              <li key={u.username} className="flex items-center justify-between gap-3 px-3 py-2">
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium">{u.display_name || u.username}</p>
                  <p className="truncate text-xs text-muted-foreground" dir="ltr">
                    {[u.username, u.email, u.department, u.title].filter(Boolean).join(" · ")}
                  </p>
                </div>
                {u.registered ? (
                  <Badge variant="secondary">{t("users.registered")}</Badge>
                ) : (
                  <Button size="sm" variant="outline" disabled={adding !== null} onClick={() => handleAdd(u)}>
                    <UserPlus className="me-1 h-4 w-4" /> {t("users.add")}
                  </Button>
                )}
              </li>
            ))}
          </ul>
        )}
      </div>
    </>
  );
}
```

**`frontend/app/setup/page.tsx`** (complete file)

```tsx
"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Eye, EyeOff, Info, Loader2, Lock, ShieldPlus, User } from "lucide-react";
import { toast } from "sonner";

import { createFirstAdmin, getSetupStatus, login, setStoredToken } from "@/lib/api";
import { useI18n } from "@/lib/i18n";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { LanguageSwitcher } from "@/components/language-switcher";
import { LoginBackdrop, LoginMark } from "@/components/login-showcase";
import { ThemeToggle } from "@/components/theme-toggle";

const USERNAME_RE = /^[A-Za-z0-9._-]{3,64}$/;
const MIN_PASSWORD_LENGTH = 6;

/** First-run screen: shown only while no users exist; creates the first local administrator. */
export default function SetupPage() {
  const { t } = useI18n();
  const router = useRouter();
  const [ready, setReady] = useState(false);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Setup already done (users exist) -> this screen is not available.
  useEffect(() => {
    let cancelled = false;
    getSetupStatus()
      .then((s) => {
        if (cancelled) return;
        if (!s.setup_required) router.replace("/login");
        else setReady(true);
      })
      .catch(() => {
        if (!cancelled) setReady(true); // backend unreachable: let the submit report the error
      });
    return () => {
      cancelled = true;
    };
  }, [router]);

  function validate(): string | null {
    if (!USERNAME_RE.test(username.trim())) return t("setup.invalid_username");
    if (password.length < MIN_PASSWORD_LENGTH) return t("setup.too_short");
    if (password !== confirm) return t("setup.mismatch");
    return null;
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (busy) return;
    const problem = validate();
    setError(problem);
    if (problem) return;

    setBusy(true);
    try {
      const name = username.trim();
      await createFirstAdmin(name, password);
      // Sign in with the new account straight away (proves the credentials work).
      const session = await login(name, password);
      setStoredToken(session.access_token);
      toast.success(`${t("setup.success")} — ${session.username}`);
      router.replace("/");
      router.refresh();
    } catch (err) {
      const message = err instanceof Error ? err.message : t("setup.failed");
      setError(message);
      toast.error(t("setup.failed"));
      // Someone else completed setup meanwhile -> go to the normal login.
      if (message.includes("already been completed")) router.replace("/login");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="relative flex min-h-screen flex-col">
      <LoginBackdrop />

      <div className="relative z-10 flex justify-end p-4">
        <div className="flex items-center gap-1 rounded-xl bg-card/90 p-1 shadow-lg backdrop-blur">
          <LanguageSwitcher compact />
          <ThemeToggle />
        </div>
      </div>

      <main className="relative z-10 flex flex-1 items-center justify-center px-4 pb-16">
        <div className="w-full max-w-sm rounded-2xl border bg-card p-8 shadow-2xl shadow-black/40 animate-in fade-in zoom-in-95 slide-in-from-bottom-4 duration-700 motion-reduce:animate-none">
          <div className="mb-6 flex flex-col items-center text-center">
            <div className="mb-4">
              <LoginMark />
            </div>
            <h1 className="text-2xl font-bold tracking-tight">{t("setup.title")}</h1>
            <p className="mt-1 text-sm text-muted-foreground">{t("setup.subtitle")}</p>
          </div>

          {!ready ? (
            <div className="flex justify-center py-10">
              <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
            </div>
          ) : (
            <form onSubmit={onSubmit} className="space-y-4" noValidate>
              <div className="space-y-2">
                <Label htmlFor="setup-username">{t("setup.username")}</Label>
                <div className="relative">
                  <User className="pointer-events-none absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    id="setup-username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    autoComplete="username"
                    autoFocus
                    required
                    dir="ltr"
                    className="h-11 ps-9"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="setup-password">{t("setup.password")}</Label>
                <div className="relative">
                  <Lock className="pointer-events-none absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    id="setup-password"
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    autoComplete="new-password"
                    required
                    dir="ltr"
                    className="h-11 pe-10 ps-9"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((v) => !v)}
                    className="absolute end-1 top-1/2 flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-md text-muted-foreground transition-colors hover:text-foreground"
                    aria-label={showPassword ? t("auth.hide_password") : t("auth.show_password")}
                    title={showPassword ? t("auth.hide_password") : t("auth.show_password")}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="setup-confirm">{t("setup.confirm")}</Label>
                <div className="relative">
                  <Lock className="pointer-events-none absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    id="setup-confirm"
                    type={showPassword ? "text" : "password"}
                    value={confirm}
                    onChange={(e) => setConfirm(e.target.value)}
                    autoComplete="new-password"
                    required
                    dir="ltr"
                    className="h-11 ps-9"
                    aria-invalid={confirm.length > 0 && confirm !== password}
                  />
                </div>
              </div>

              {error && (
                <p role="alert" className="rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">
                  {error}
                </p>
              )}

              <Button type="submit" className="h-11 w-full shadow-lg shadow-primary/20" disabled={busy}>
                {busy ? <Loader2 className="me-2 h-4 w-4 animate-spin" /> : <ShieldPlus className="me-2 h-4 w-4" />}
                <span>{busy ? t("setup.submitting") : t("setup.submit")}</span>
              </Button>

              <p className="flex gap-2 text-xs text-muted-foreground">
                <Info className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                {t("setup.note")}
              </p>
            </form>
          )}
        </div>
      </main>
    </div>
  );
}
```

**`frontend/components/login-showcase.tsx`** (complete file)

```tsx
"use client";

import Image from "next/image";
import { Braces, FileText, Languages, ScanText, Table2, WifiOff } from "lucide-react";

import uaeEmblem from "@/assets/uae-emblem.png";

import { useI18n, type TranslationKey } from "@/lib/i18n";
import { cn } from "@/lib/utils";

/**
 * Full-screen decorative login backdrop: a sample Arabic government
 * certificate (clearly watermarked as a SAMPLE) is scanned and its fields
 * stream across the screen — behind the centered login card — into a
 * structured result. Delays are seconds within the 7s cycle in globals.css;
 * each matches the moment the scan beam crosses that line of the document.
 */
const FIELDS: { label: TranslationKey; docLabel: string; value: string; conf: number; top: string; delay: number }[] = [
  { label: "login.demo.reference", docLabel: "رقم المرجع", value: "2026/4172", conf: 99, top: "33%", delay: 1.1 },
  { label: "login.demo.name", docLabel: "الاسم", value: "محمد أحمد عبدالله", conf: 97, top: "41%", delay: 1.4 },
  { label: "login.demo.emirate", docLabel: "الإمارة", value: "دبي", conf: 98, top: "49%", delay: 1.7 },
  { label: "login.demo.issue_date", docLabel: "تاريخ الإصدار", value: "15/10/2026", conf: 99, top: "57%", delay: 2.0 },
];

const FILE_BADGES = [
  { text: "PDF", className: "start-[6%] top-[16%] bg-red-500/80", r: "-8deg", delay: "0s" },
  { text: "JPG", className: "end-[9%] top-[13%] bg-amber-500/80", r: "6deg", delay: "1.5s" },
  { text: "PNG", className: "start-[30%] bottom-[10%] bg-emerald-500/80", r: "4deg", delay: "3s" },
  { text: "TIFF", className: "end-[26%] bottom-[14%] bg-sky-500/80", r: "-5deg", delay: "4.5s" },
  { text: "DOCX", className: "start-[36%] top-[9%] bg-indigo-500/80", r: "3deg", delay: "6s" },
];

const FEATURES = [
  { icon: Languages, key: "login.hero.f1" },
  { icon: WifiOff, key: "login.hero.f2" },
  { icon: Table2, key: "login.hero.f3" },
  { icon: FileText, key: "login.hero.f4" },
] as const;

export function LoginBackdrop() {
  const { t } = useI18n();

  return (
    <div
      aria-hidden
      className="fixed inset-0 overflow-hidden bg-gradient-to-br from-slate-900 via-blue-950 to-indigo-950 text-white"
    >
      {/* Grid + glows */}
      <div
        className="absolute inset-0 opacity-60"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,255,255,0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.05) 1px, transparent 1px)",
          backgroundSize: "32px 32px",
        }}
      />
      <div className="login-glow absolute -start-24 top-10 h-96 w-96 rounded-full bg-blue-500/30 blur-3xl" />
      <div
        className="login-glow absolute -end-16 bottom-10 h-[28rem] w-[28rem] rounded-full bg-indigo-500/30 blur-3xl"
        style={{ animationDelay: "4s" }}
      />

      {/* Brand */}
      <div className="absolute start-8 top-7 flex items-center gap-2">
        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-white/10 ring-1 ring-white/20">
          <ScanText className="h-5 w-5" />
        </div>
        <div>
          <p className="text-sm font-bold leading-none">{t("app.name")}</p>
          <p className="text-xs text-white/60">{t("app.tagline_full")}</p>
        </div>
      </div>

      {FILE_BADGES.map((b) => (
        <span
          key={b.text}
          className={cn(
            "login-float absolute rounded-md px-2 py-1 text-[10px] font-bold tracking-wider shadow-lg",
            b.className
          )}
          style={{ animationDelay: b.delay, ["--r" as string]: b.r }}
        >
          {b.text}
        </span>
      ))}

      {/* Stage (wide screens): document → data stream behind the card → result */}
      <div className="absolute start-[7%] top-1/2 hidden -translate-y-1/2 xl:block">
        <SampleCertificate />
      </div>

      <div className="absolute end-[7%] top-1/2 hidden -translate-y-1/2 xl:block">
        <ResultCard />
      </div>

      <div className="absolute end-[calc(7%+16rem)] start-[calc(7%+16.5rem)] top-1/2 hidden h-6 -translate-y-1/2 xl:block rtl:-scale-x-100">
        <div className="absolute inset-x-0 top-1/2 h-px -translate-y-1/2 bg-gradient-to-r from-sky-400/0 via-sky-400/40 to-sky-400/0" />
        {[0, 0.5, 1, 1.5, 2, 2.5].map((d) => (
          <div key={d} className="login-stream absolute inset-0" style={{ animationDelay: `${d}s` }}>
            <span className="absolute start-0 top-1/2 h-1.5 w-1.5 -translate-y-1/2 rounded-full bg-sky-300 shadow-[0_0_10px_3px_rgba(125,211,252,0.7)]" />
          </div>
        ))}
      </div>

      {/* Pitch */}
      <div className="absolute bottom-8 start-8 hidden max-w-sm space-y-3 xl:block [@media(max-height:820px)]:hidden">
        <h2 className="text-2xl font-bold leading-tight tracking-tight">{t("login.hero.title")}</h2>
        <p className="text-sm text-white/65">{t("login.hero.subtitle")}</p>
        <div className="flex flex-wrap gap-2">
          {FEATURES.map(({ icon: Icon, key }) => (
            <span
              key={key}
              className="flex items-center gap-1.5 rounded-full bg-white/10 px-3 py-1 text-xs text-white/85 ring-1 ring-white/15"
            >
              <Icon className="h-3.5 w-3.5" />
              {t(key)}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

/** Sample Arabic government certificate (UAE emblem), watermarked as a sample. */
function SampleCertificate() {
  return (
    <div
      dir="rtl"
      lang="ar"
      translate="no"
      className="notranslate relative h-[22rem] w-64 -rotate-3 overflow-hidden rounded-xl bg-white text-slate-800 shadow-2xl shadow-black/40"
    >
      {/* Flag-colour band (red bar at the hoist side, as on the flag) */}
      <div dir="ltr" className="flex h-1.5">
        <div className="w-1/4 bg-red-600" />
        <div className="flex flex-1 flex-col">
          <div className="flex-1 bg-green-700" />
          <div className="flex-1 bg-slate-100" />
          <div className="flex-1 bg-black" />
        </div>
      </div>

      <div className="px-5 pt-4">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-[13px] font-bold text-slate-900">الإمارات العربية المتحدة</p>
            <p className="text-[9px] text-slate-500">وثيقة حكومية نموذجية</p>
          </div>
          <Image src={uaeEmblem} alt="" width={40} height={45} className="h-11 w-auto" unoptimized priority />
        </div>
        <p className="mt-3 border-b border-slate-200 pb-1.5 text-center text-sm font-extrabold text-slate-900">
          شهادة تسجيل
        </p>
      </div>

      {FIELDS.map((f) => (
        <div key={f.label} className="absolute inset-x-5 flex items-center gap-2 text-[11px]" style={{ top: f.top }}>
          <span className="text-slate-500">{f.docLabel}:</span>
          <span className="relative px-1 font-semibold text-slate-900">
            {f.value}
            <span
              className="login-box absolute -inset-1 rounded border-2 border-blue-500 bg-blue-500/10"
              style={{ animationDelay: `${f.delay}s` }}
            />
          </span>
        </div>
      ))}

      {/* Body text (filler) */}
      <div className="absolute inset-x-5 top-[66%] space-y-1.5">
        {[1, 0.85, 0.92, 0.6].map((w, i) => (
          <div key={i} className="h-1.5 rounded bg-slate-200" style={{ width: `${w * 100}%` }} />
        ))}
      </div>

      {/* Signature + stamp */}
      <div className="absolute inset-x-5 bottom-4 flex items-end justify-between">
        <svg viewBox="0 0 80 24" className="h-6 w-20 text-slate-600" fill="none" stroke="currentColor" strokeWidth="1.5">
          <path d="M2 18c8-14 12 4 18-6s6 10 12 2 8-8 12 0 10-6 14-2 8 4 18-4" strokeLinecap="round" />
        </svg>
        <div className="flex h-11 w-11 -rotate-12 items-center justify-center rounded-full border-2 border-red-500/60 text-[9px] font-bold text-red-500/70">
          نموذج
        </div>
      </div>

      {/* Sample watermark */}
      <p className="pointer-events-none absolute inset-0 flex -rotate-[30deg] items-center justify-center whitespace-nowrap text-3xl font-black tracking-widest text-slate-900/[0.06]">
        نموذج · SAMPLE
      </p>

      {/* Scan beam (full-height track: translateY % = % of the page) */}
      <div className="login-scan pointer-events-none absolute inset-0">
        <div className="absolute inset-x-0 top-0 h-0.5 bg-blue-500 shadow-[0_0_18px_6px_rgba(59,130,246,0.55)]">
          <div className="absolute inset-x-0 bottom-0 h-10 bg-gradient-to-t from-blue-500/25 to-transparent" />
        </div>
      </div>
    </div>
  );
}

function ResultCard() {
  const { t } = useI18n();
  return (
    <div className="w-64 rounded-xl border border-white/15 bg-white/10 p-4 shadow-2xl shadow-black/30 backdrop-blur-md">
      <div className="mb-3 flex items-center justify-between">
        <p className="flex items-center gap-1.5 text-xs font-semibold">
          <Braces className="h-3.5 w-3.5 text-sky-300" />
          {t("login.demo.extracted")}
        </p>
        <span className="rounded bg-white/10 px-1.5 py-0.5 font-mono text-[9px] text-white/70">JSON</span>
      </div>
      <div className="space-y-2">
        {FIELDS.map((f) => (
          <div
            key={f.label}
            className="login-field flex items-center justify-between gap-2 rounded-lg bg-white/5 px-2.5 py-1.5 ring-1 ring-white/10"
            style={{ animationDelay: `${f.delay + 0.6}s` }}
          >
            <div className="min-w-0">
              <p className="text-[10px] text-white/55">{t(f.label)}</p>
              <p className="truncate text-xs font-medium">
                <bdi translate="no" className="notranslate">
                  {f.value}
                </bdi>
              </p>
            </div>
            <span className="shrink-0 rounded-full bg-emerald-400/15 px-1.5 py-0.5 text-[10px] font-semibold text-emerald-300">
              {f.conf}%
            </span>
          </div>
        ))}
      </div>
      <div className="mt-3 h-1 overflow-hidden rounded-full bg-white/10">
        <div className="login-progress h-full w-full origin-left rounded-full bg-gradient-to-r from-sky-400 to-emerald-400 rtl:origin-right" />
      </div>
    </div>
  );
}

/** Compact animated mark shown at the top of the login card. */
export function LoginMark() {
  return (
    <div className="relative flex h-14 w-14 items-center justify-center overflow-hidden rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-700 text-white shadow-lg shadow-blue-500/30">
      <ScanText className="h-7 w-7" />
      <span className="login-scan-mini absolute inset-x-1 h-0.5 rounded bg-sky-300 shadow-[0_0_8px_2px_rgba(125,211,252,0.8)]" />
    </div>
  );
}
```

**`frontend/assets/uae-emblem.png`** (binary, 171×192 transparent PNG, ~55 KB)

Copy the file from this project. It is imported by `login-showcase.tsx` as a static image (`import uaeEmblem from "@/assets/uae-emblem.png"`), which keeps it working with `BASE_PATH`.

> The emblem is the official UAE Armed Forces emblem; use of official emblems is regulated. If you cannot use it, replace the `<Image … />` line in `SampleCertificate` with a generic icon (for example lucide's `Landmark`) and remove the import.

---

## 12. Frontend: modified files

### 12.1 `frontend/app/login/page.tsx`

Replace the whole file.

**`frontend/app/login/page.tsx`** (complete file)

```tsx
"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Eye, EyeOff, Loader2, Lock, LogIn, MonitorSmartphone, ShieldCheck, User } from "lucide-react";
import { toast } from "sonner";

import { getAuthMe, getStoredToken, login, setStoredToken, windowsLogin } from "@/lib/api";
import { useI18n } from "@/lib/i18n";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { LanguageSwitcher } from "@/components/language-switcher";
import { LoginBackdrop, LoginMark } from "@/components/login-showcase";
import { ThemeToggle } from "@/components/theme-toggle";

export default function LoginPage() {
  const { t } = useI18n();
  const router = useRouter();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [authDisabled, setAuthDisabled] = useState(false);

  // Already signed in -> go to dashboard. Otherwise show the auth mode note.
  useEffect(() => {
    let cancelled = false;
    getAuthMe()
      .then((me) => {
        if (cancelled) return;
        if (me.setup_required) {
          router.replace("/setup");
          return;
        }
        if (me.authenticated && me.kind === "user") router.replace("/");
        setAuthDisabled(!me.auth_required);
      })
      .catch(() => setAuthDisabled(false));
    return () => {
      cancelled = true;
    };
  }, [router]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (busy) return;
    setBusy(true);
    try {
      const res = await login(username.trim(), password);
      setStoredToken(res.access_token);
      toast.success(`${t("auth.success")} — ${res.username}`);
      router.replace("/");
      router.refresh();
    } catch (err) {
      const message = err instanceof Error ? err.message : "";
      if (message.includes("disabled")) toast.error(t("auth.disabled"));
      else if (message.includes("Active Directory")) toast.error(t("auth.unavailable"));
      else toast.error(t("auth.error"));
    } finally {
      setBusy(false);
    }
  }

  async function onWindows() {
    if (busy) return;
    setBusy(true);
    try {
      const res = await windowsLogin();
      if (!res) {
        toast.error(t("auth.windows_failed"));
        return;
      }
      setStoredToken(res.access_token);
      toast.success(`${t("auth.success")} — ${res.display_name || res.username}`);
      router.replace("/");
      router.refresh();
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="relative flex min-h-screen flex-col">
      <LoginBackdrop />

      <div className="relative z-10 flex justify-end p-4">
        <div className="flex items-center gap-1 rounded-xl bg-card/90 p-1 shadow-lg backdrop-blur">
          <LanguageSwitcher compact />
          <ThemeToggle />
        </div>
      </div>

      <main className="relative z-10 flex flex-1 items-center justify-center px-4 pb-16">
        <div className="w-full max-w-sm rounded-2xl border bg-card p-8 shadow-2xl shadow-black/40 animate-in fade-in zoom-in-95 slide-in-from-bottom-4 duration-700 motion-reduce:animate-none">
          <div className="mb-7 flex flex-col items-center text-center">
            <div className="mb-4">
              <LoginMark />
            </div>
            <h1 className="text-2xl font-bold tracking-tight">{t("auth.welcome")}</h1>
            <p className="mt-1 text-sm text-muted-foreground">{t("auth.subtitle")}</p>
          </div>

          {getStoredToken() === null && authDisabled && (
            <p className="mb-4 rounded-md bg-muted px-3 py-2 text-center text-xs text-muted-foreground">
              {t("auth.no_auth_note")}
            </p>
          )}

          <form onSubmit={onSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username">{t("auth.username")}</Label>
              <div className="relative">
                <User className="pointer-events-none absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  autoComplete="username"
                  autoFocus
                  required
                  dir="ltr"
                  className="h-11 ps-9"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">{t("auth.password")}</Label>
              <div className="relative">
                <Lock className="pointer-events-none absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  autoComplete="current-password"
                  required
                  dir="ltr"
                  className="h-11 pe-10 ps-9"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  className="absolute end-1 top-1/2 flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-md text-muted-foreground transition-colors hover:text-foreground"
                  aria-label={showPassword ? t("auth.hide_password") : t("auth.show_password")}
                  title={showPassword ? t("auth.hide_password") : t("auth.show_password")}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>
            <Button type="submit" className="h-11 w-full shadow-lg shadow-primary/20" disabled={busy}>
              {busy ? <Loader2 className="me-2 h-4 w-4 animate-spin" /> : <LogIn className="me-2 h-4 w-4" />}
              <span>{busy ? t("auth.submitting") : t("auth.submit")}</span>
            </Button>
          </form>

          <div className="my-5 flex items-center gap-3 text-xs text-muted-foreground">
            <div className="h-px flex-1 bg-border" />
            {t("auth.or")}
            <div className="h-px flex-1 bg-border" />
          </div>
          <Button type="button" variant="outline" className="h-11 w-full" disabled={busy} onClick={onWindows}>
            <MonitorSmartphone className="me-2 h-4 w-4" />
            {t("auth.windows")}
          </Button>

          <p className="mt-7 flex items-center justify-center gap-1.5 text-xs text-muted-foreground">
            <ShieldCheck className="h-3.5 w-3.5" />
            {t("auth.footer")}
          </p>
        </div>
      </main>
    </div>
  );
}
```

### 12.2 `frontend/components/auth-guard.tsx`

Replace the whole file. Order: first-run setup → signed in? → Windows SSO (skipped after sign-out or a failed attempt in this browser session) → login page.

**`frontend/components/auth-guard.tsx`** (complete file)

```tsx
"use client";

import { useEffect, useState } from "react";
import { usePathname, useRouter } from "next/navigation";

import { getAuthMe, isWindowsSsoSkipped, setStoredToken, skipWindowsSso, windowsLogin } from "@/lib/api";
import { useI18n } from "@/lib/i18n";

export function AuthGuard({ children }: { children: React.ReactNode }) {
  const { t } = useI18n();
  const pathname = usePathname();
  const router = useRouter();
  const [ready, setReady] = useState(false);
  const [trying, setTrying] = useState(false);

  useEffect(() => {
    if (pathname === "/login") {
      setReady(true);
      return;
    }
    let cancelled = false;

    async function check() {
      let me;
      try {
        me = await getAuthMe();
      } catch {
        // Backend unreachable: don't lock the user out — pages will show errors.
        if (!cancelled) setReady(true);
        return;
      }
      if (cancelled) return;
      if (me.setup_required) {
        router.replace("/setup"); // no users yet: create the first administrator
        return;
      }
      if (me.authenticated && me.kind !== "anonymous") {
        setReady(true);
        return;
      }

      // Not signed in: try the Windows account first (user must be registered + in AD).
      if (!isWindowsSsoSkipped()) {
        setTrying(true);
        const session = await windowsLogin();
        if (cancelled) return;
        setTrying(false);
        if (session) {
          setStoredToken(session.access_token);
          setReady(true);
          return;
        }
        skipWindowsSso(); // don't retry on every navigation in this browser session
      }

      if (me.auth_required) {
        router.replace("/login");
        return;
      }
      setReady(true); // auth is off: continue anonymously
    }

    check();
    return () => {
      cancelled = true;
    };
  }, [pathname, router]);

  if (!ready) {
    return (
      <div className="py-24 text-center text-sm text-muted-foreground">
        {trying ? t("auth.windows_trying") : t("common.loading")}
      </div>
    );
  }
  return <>{children}</>;
}
```

### 12.3 `frontend/app/layout.tsx`

Replace the whole file. `translate="no"` + `notranslate` stop browser auto-translate from rewriting React-managed text (it caused the crash "Failed to execute 'insertBefore' on 'Node'").

**`frontend/app/layout.tsx`** (complete file)

```tsx
import type { Metadata } from "next";
import { Toaster } from "sonner";

import { ThemeProvider } from "@/components/theme-provider";
import { LanguageProvider } from "@/lib/i18n";
import "./globals.css";

export const metadata: Metadata = {
  title: "IOCR — Intelligence OCR",
  description: "Offline Arabic & English OCR with confidence scores, bounding boxes, structured extraction and OCR Lab benchmarking.",
  // The UI has its own English/Arabic switch. Browser auto-translate rewrites
  // React-managed text nodes and crashes re-renders ("insertBefore … not a child").
  other: { google: "notranslate" },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" translate="no" className="notranslate" suppressHydrationWarning>
      <body className="min-h-screen antialiased">
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange>
          <LanguageProvider>
            {children}
            <Toaster richColors position="top-right" />
          </LanguageProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
```

### 12.4 `frontend/lib/api.ts`

Replace everything from `const TOKEN_KEY` up to the `// ---------- OCR jobs ----------` comment with:

```ts
const TOKEN_KEY = "iocr.access_token";
// Set after sign-out or a failed Windows sign-in: don't auto-login again in this browser session.
const SSO_SKIP_KEY = "iocr.sso_skip";
export const AUTH_CHANGED_EVENT = "iocr:auth-changed";

export function getStoredToken(): string | null {
  if (typeof window === "undefined") return null;
  return window.localStorage.getItem(TOKEN_KEY);
}

export function setStoredToken(token: string): void {
  window.localStorage.setItem(TOKEN_KEY, token);
  window.sessionStorage.removeItem(SSO_SKIP_KEY);
  window.dispatchEvent(new Event(AUTH_CHANGED_EVENT));
}

export function clearStoredToken(): void {
  window.localStorage.removeItem(TOKEN_KEY);
  window.sessionStorage.setItem(SSO_SKIP_KEY, "1");
  window.dispatchEvent(new Event(AUTH_CHANGED_EVENT));
}

/**
 * Append the session token for URLs the browser loads directly (downloads,
 * <img>, PDF viewer) — those can't send an Authorization header. The backend
 * accepts the same token as ?api_key=.
 */
export function authUrl(url: string): string {
  const token = getStoredToken();
  if (!token) return url;
  return `${url}${url.includes("?") ? "&" : "?"}api_key=${encodeURIComponent(token)}`;
}

export function isWindowsSsoSkipped(): boolean {
  return window.sessionStorage.getItem(SSO_SKIP_KEY) === "1";
}

export function skipWindowsSso(): void {
  window.sessionStorage.setItem(SSO_SKIP_KEY, "1");
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const headers = new Headers(init?.headers);
  const token = getStoredToken();
  if (token) headers.set("Authorization", `Bearer ${token}`);
  const res = await fetch(`${V1}${path}`, { ...init, headers });
  if (!res.ok) {
    let detail = `Request failed (${res.status})`;
    try {
      const body = await res.json();
      if (body?.detail) detail = typeof body.detail === "string" ? body.detail : JSON.stringify(body.detail);
    } catch {
      // keep default message
    }
    throw new Error(detail);
  }
  if (res.status === 204) return undefined as T;
  return res.json() as Promise<T>;
}

// ---------- Auth ----------

export function login(username: string, password: string): Promise<LoginResponse> {
  return request("/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, password }),
  });
}

export function getAuthMe(): Promise<AuthMe> {
  return request("/auth/me");
}

// ---------- First-run setup ----------

export function getSetupStatus(): Promise<{ setup_required: boolean }> {
  return request("/auth/setup");
}

/** Create the first (local) administrator. Only accepted while no users exist. */
export function createFirstAdmin(username: string, password: string): Promise<{ username: string; is_admin: boolean }> {
  return request("/auth/setup", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, password }),
  });
}

/**
 * Windows integrated sign-in (Kerberos). The browser answers the server's
 * "Negotiate" challenge with the signed-in Windows user's ticket — this only
 * works on domain machines where the API host is trusted for Windows auth.
 * Resolves to null on any failure (not registered, not in AD, no ticket, …).
 */
export async function windowsLogin(timeoutMs = 15000): Promise<LoginResponse | null> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(`${V1}/auth/sso`, { credentials: "include", signal: controller.signal });
    if (!res.ok) return null;
    return (await res.json()) as LoginResponse;
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

// ---------- Users (Active Directory) ----------

export function listUsers(): Promise<AppUser[]> {
  return request("/users");
}

export function searchDirectory(q: string): Promise<DirectoryUser[]> {
  return request(`/users/directory?q=${encodeURIComponent(q)}`);
}

export function addUser(username: string, isAdmin: boolean): Promise<AppUser> {
  return request("/users", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, is_admin: isAdmin }),
  });
}

export function setUserAdmin(id: string, isAdmin: boolean): Promise<AppUser> {
  return request(`/users/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ is_admin: isAdmin }),
  });
}

/** Disable (active=false) or re-enable a user. Users are never deleted. */
export function setUserActive(id: string, active: boolean): Promise<AppUser> {
  return request(`/users/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ is_active: active }),
  });
}
```

Add `AppUser` and `DirectoryUser` to the `import type { … } from "@/lib/types"` list. Then wrap the direct-URL helpers with `authUrl()` (they are loaded by the browser without an `Authorization` header):

```ts
export function exportJobUrl(jobId: string, format: "txt" | "json" | "csv"): string {
  return authUrl(`${V1}/ocr/${jobId}/export?format=${format}`);
}

export function originalFileUrl(jobId: string): string {
  return authUrl(`${V1}/ocr/${jobId}/file`);
}

export function exportCorrectionsUrl(format: "json" | "csv" | "jsonl"): string {
  return authUrl(`${V1}/corrections/export?format=${format}`);
}

export function benchmarkFileUrl(benchmarkId: string): string {
  return authUrl(`${V1}/benchmark/${benchmarkId}/file`);
}
```

### 12.5 `frontend/lib/types.ts`

Replace the Auth section and add the Users section:

```ts
// ---------- Auth ----------

export interface LoginResponse {
  access_token: string;
  token_type: string;
  expires_in: number;
  username: string;
  display_name: string | null;
  is_admin: boolean;
  auth_required: boolean;
}

export interface AuthMe {
  authenticated: boolean;
  kind: "user" | "api_key" | "anonymous" | null;
  username: string | null;
  is_admin: boolean;
  auth_required: boolean;
  /** True while no users exist: the UI must show the first-run "create administrator" screen. */
  setup_required?: boolean;
}
// ---------- Users (Active Directory) ----------

export interface AppUser {
  id: string;
  username: string | null;
  display_name: string | null;
  email: string | null;
  is_admin: boolean;
  auth_source: "local" | "ldap" | null;
  /** false = disabled by an admin (cannot sign in); users are never deleted. */
  is_active: boolean;
  created_at: string | null;
}

export interface DirectoryUser {
  username: string;
  display_name: string | null;
  email: string | null;
  upn: string | null;
  department: string | null;
  title: string | null;
  registered: boolean;
}
```

### 12.6 `frontend/components/sidebar.tsx`

Add `Users` to the `lucide-react` icon import, and import `AUTH_CHANGED_EVENT`:

```tsx
import { AUTH_CHANGED_EVENT, clearStoredToken, getAuthMe } from "@/lib/api";
```

Administration menu group:

```tsx
    labelKey: "nav.group.administration",
    items: [
      { href: "/users", labelKey: "nav.users", icon: Users },
      { href: "/settings", labelKey: "nav.settings", icon: Settings },
    ],
  },
```

`AccountRow`: re-read the identity when the session changes (auto-login, sign-in, sign-out):

```tsx
function AccountRow() {
  const { t } = useI18n();
  const router = useRouter();
  const [me, setMe] = useState<AuthMe | null>(null);

  useEffect(() => {
    let cancelled = false;
    const refresh = () =>
      getAuthMe()
        .then((m) => {
          if (cancelled) return;
          setMe(m);
        })
        .catch(() => {
          if (!cancelled) setMe(null);
        });
    refresh();
    // Re-read the identity after Windows auto-login / sign-in / sign-out.
    window.addEventListener(AUTH_CHANGED_EVENT, refresh);
    return () => {
      cancelled = true;
      window.removeEventListener(AUTH_CHANGED_EVENT, refresh);
    };
  }, []);
```

### 12.7 `frontend/components/document-viewer.tsx`

```tsx
import { authUrl, originalFileUrl } from "@/lib/api";
          src={page.image_url ? authUrl(page.image_url) : ""}
```

### 12.8 `frontend/lib/i18n.tsx`

All translation keys used by login, setup and user management. Keys that already exist in your copy (e.g. `auth.title`) are unchanged; add the missing ones. Note: the old `users.remove`, `users.remove_confirm` and `users.removed` keys are no longer used.

English (`const en`):

```ts

  "auth.title": "Sign in",
  "auth.subtitle": "Access the intelligence OCR console",
  "auth.username": "Username",
  "auth.password": "Password",
  "auth.submit": "Sign in",
  "auth.submitting": "Signing in…",
  "auth.success": "Signed in",
  "auth.error": "Sign in failed — check your credentials.",
  "auth.no_auth_note": "Security is off (authentication not required). You can still sign in to lock this browser session.",
  "auth.logout": "Sign out",
  "auth.user": "User",
  "auth.admin": "Administrator",
  "nav.users": "Users",
  "users.title": "Users",
  "users.subtitle": "Only users added here can sign in, using their Active Directory password.",
  "users.add": "Add user",
  "users.dialog.title": "Add user from Active Directory",
  "users.dialog.desc": "Search by login name, display name or e-mail (at least 2 characters).",
  "users.dialog.placeholder": "Name",
  "users.dialog.no_results": "No matching enabled accounts in Active Directory.",
  "users.dialog.as_admin": "Grant administrator rights",
  "users.registered": "Already added",
  "users.added": "User added",
  "users.add_failed": "Could not add user",
  "users.search_failed": "Directory search failed",
  "users.load_failed": "Failed to load users",
  "users.empty": "No users yet.",
  "users.login": "Login name",
  "users.email": "E-mail",
  "users.source": "Source",
  "users.source.ldap": "Active Directory",
  "users.source.local": "Local",
  "users.role": "Role",
  "users.make_admin": "Make administrator",
  "users.make_user": "Make standard user",
  "users.role_updated": "Role updated",
  "users.active": "Active",
  "users.disabled": "Disabled",
  "users.disable": "Disable user",
  "users.enable": "Enable user",
  "users.disable_title": "Disable user",
  "users.disable_confirm": "Do you want to disable the user?",
  "users.disable_note": "The user is signed out and cannot sign in until an administrator enables them again. Nothing is deleted.",
  "users.yes": "Yes",
  "users.no": "No",
  "users.disabled_ok": "User disabled",
  "users.enabled_ok": "User enabled",
  "users.self_note": "You cannot change your own account",
  "users.action_failed": "Action failed",
  "auth.unavailable": "Active Directory is unavailable — try again later.",
  "auth.disabled": "Your account is disabled. Contact the administrator.",
  "auth.windows": "Sign in with Windows account",
  "auth.windows_trying": "Signing in with your Windows account…",
  "auth.windows_failed": "Windows sign-in failed — your account may not be registered. Use your username and password.",
  "auth.or": "or",
  "auth.welcome": "Welcome back",
  "setup.title": "Create administrator",
  "setup.subtitle": "No users exist yet. Create the first administrator account to start using IOCR.",
  "setup.username": "User name",
  "setup.password": "Password",
  "setup.confirm": "Re-enter password",
  "setup.submit": "Create administrator",
  "setup.submitting": "Creating…",
  "setup.mismatch": "Passwords do not match.",
  "setup.too_short": "Password must be at least 6 characters.",
  "setup.invalid_username": "User name must be 3-64 characters: letters, digits, dot, dash or underscore.",
  "setup.success": "Administrator created",
  "setup.failed": "Could not create the administrator",
  "setup.note": "This is a local account (not Active Directory). Use it to add Active Directory users afterwards.",
  "auth.show_password": "Show password",
  "auth.hide_password": "Hide password",
  "auth.footer": "Secured with Active Directory · runs fully offline",
  "login.hero.title": "Turn documents into data",
  "login.hero.subtitle": "Scan PDFs and images in Arabic and English — text, fields and tables are extracted on-premises, with a confidence score for every value.",
  "login.hero.f1": "Arabic & English",
  "login.hero.f2": "100% offline",
  "login.hero.f3": "Tables & fields",
  "login.hero.f4": "PDF & images",
  "login.demo.extracted": "Extracted fields",
  "login.demo.reference": "Reference No.",
  "login.demo.name": "Full name",
  "login.demo.emirate": "Emirate",
  "login.demo.issue_date": "Issue date",
```

Arabic (`const ar`):

```ts

  "auth.title": "تسجيل الدخول",
  "auth.subtitle": "الوصول إلى لوحة الذكاء في التعرف الضوئي",
  "auth.username": "اسم المستخدم",
  "auth.password": "كلمة المرور",
  "auth.submit": "تسجيل الدخول",
  "auth.submitting": "جارٍ تسجيل الدخول…",
  "auth.success": "تم تسجيل الدخول",
  "auth.error": "فشل تسجيل الدخول — تحقق من بيانات الدخول.",
  "auth.no_auth_note": "الأمان معطّل (الدخول غير مطلوب). يمكنك مع ذلك تسجيل الدخول لقفل هذه الجلسة.",
  "auth.logout": "تسجيل الخروج",
  "auth.user": "مستخدم",
  "auth.admin": "مسؤول",
  "nav.users": "المستخدمون",
  "users.title": "المستخدمون",
  "users.subtitle": "يمكن فقط للمستخدمين المضافين هنا تسجيل الدخول بكلمة مرور Active Directory الخاصة بهم.",
  "users.add": "إضافة مستخدم",
  "users.dialog.title": "إضافة مستخدم من Active Directory",
  "users.dialog.desc": "ابحث باسم الدخول أو الاسم المعروض أو البريد الإلكتروني (حرفان على الأقل).",
  "users.dialog.placeholder": "الاسم",
  "users.dialog.no_results": "لا توجد حسابات مفعّلة مطابقة في Active Directory.",
  "users.dialog.as_admin": "منح صلاحيات المسؤول",
  "users.registered": "مضاف مسبقًا",
  "users.added": "تمت إضافة المستخدم",
  "users.add_failed": "تعذّرت إضافة المستخدم",
  "users.search_failed": "فشل البحث في الدليل",
  "users.load_failed": "تعذّر تحميل المستخدمين",
  "users.empty": "لا يوجد مستخدمون بعد.",
  "users.login": "اسم الدخول",
  "users.email": "البريد الإلكتروني",
  "users.source": "المصدر",
  "users.source.ldap": "Active Directory",
  "users.source.local": "محلي",
  "users.role": "الدور",
  "users.make_admin": "تعيين كمسؤول",
  "users.make_user": "تعيين كمستخدم عادي",
  "users.role_updated": "تم تحديث الدور",
  "users.active": "نشط",
  "users.disabled": "معطّل",
  "users.disable": "تعطيل المستخدم",
  "users.enable": "تفعيل المستخدم",
  "users.disable_title": "تعطيل المستخدم",
  "users.disable_confirm": "هل تريد تعطيل المستخدم؟",
  "users.disable_note": "سيتم تسجيل خروج المستخدم ولن يتمكن من تسجيل الدخول حتى يعيد المسؤول تفعيله. لن يتم حذف أي شيء.",
  "users.yes": "نعم",
  "users.no": "لا",
  "users.disabled_ok": "تم تعطيل المستخدم",
  "users.enabled_ok": "تم تفعيل المستخدم",
  "users.self_note": "لا يمكنك تعديل حسابك",
  "users.action_failed": "فشل الإجراء",
  "auth.unavailable": "خدمة Active Directory غير متاحة — حاول لاحقًا.",
  "auth.disabled": "حسابك معطّل. تواصل مع المسؤول.",
  "auth.windows": "تسجيل الدخول بحساب Windows",
  "auth.windows_trying": "جارٍ تسجيل الدخول بحساب Windows…",
  "auth.windows_failed": "فشل تسجيل الدخول عبر Windows — قد لا يكون حسابك مسجلًا. استخدم اسم المستخدم وكلمة المرور.",
  "auth.or": "أو",
  "auth.welcome": "مرحبًا بعودتك",
  "setup.title": "إنشاء حساب المسؤول",
  "setup.subtitle": "لا يوجد مستخدمون بعد. أنشئ حساب المسؤول الأول لبدء استخدام IOCR.",
  "setup.username": "اسم المستخدم",
  "setup.password": "كلمة المرور",
  "setup.confirm": "أعد إدخال كلمة المرور",
  "setup.submit": "إنشاء المسؤول",
  "setup.submitting": "جارٍ الإنشاء…",
  "setup.mismatch": "كلمتا المرور غير متطابقتين.",
  "setup.too_short": "يجب ألا تقل كلمة المرور عن 6 أحرف.",
  "setup.invalid_username": "يجب أن يتكون اسم المستخدم من 3 إلى 64 حرفًا: أحرف أو أرقام أو نقطة أو شرطة أو شرطة سفلية.",
  "setup.success": "تم إنشاء المسؤول",
  "setup.failed": "تعذّر إنشاء المسؤول",
  "setup.note": "هذا حساب محلي (ليس من Active Directory). استخدمه لاحقًا لإضافة مستخدمي Active Directory.",
  "auth.show_password": "إظهار كلمة المرور",
  "auth.hide_password": "إخفاء كلمة المرور",
  "auth.footer": "محمي عبر Active Directory · يعمل دون اتصال بالكامل",
  "login.hero.title": "حوّل المستندات إلى بيانات",
  "login.hero.subtitle": "امسح ملفات PDF والصور باللغتين العربية والإنجليزية — تُستخرج النصوص والحقول والجداول محليًا، مع درجة ثقة لكل قيمة.",
  "login.hero.f1": "العربية والإنجليزية",
  "login.hero.f2": "دون اتصال 100%",
  "login.hero.f3": "الجداول والحقول",
  "login.hero.f4": "PDF والصور",
  "login.demo.extracted": "الحقول المستخرجة",
  "login.demo.reference": "رقم المرجع",
  "login.demo.name": "الاسم الكامل",
  "login.demo.emirate": "الإمارة",
  "login.demo.issue_date": "تاريخ الإصدار",
```

### 12.9 `frontend/app/globals.css`

Append the login animation styles (used by `login-showcase.tsx`):

```css
/* ---------- Login: "data extracted from documents" animation ----------
   One 7s cycle: the scan beam sweeps the page (0–3.5s); each field's bbox
   lights up as the beam crosses it and its extracted row slides into the
   results card ~0.3s later (delays are set inline per element). */
/* Animated on a full-height track so translateY(%) = % of the page height. */
@keyframes login-scan {
  0% { transform: translateY(4%); opacity: 0; }
  4% { opacity: 1; }
  50% { transform: translateY(96%); opacity: 1; }
  54%, 100% { transform: translateY(96%); opacity: 0; }
}
@keyframes login-box {
  0% { opacity: 0; transform: scale(0.96); }
  3% { opacity: 1; transform: scale(1); }
  45% { opacity: 1; }
  52%, 100% { opacity: 0; }
}
@keyframes login-field {
  0% { opacity: 0; transform: translateX(-12px); }
  5% { opacity: 1; transform: translateX(0); }
  50% { opacity: 1; transform: translateX(0); }
  58%, 100% { opacity: 0; transform: translateX(0); }
}
@keyframes login-progress {
  0% { transform: scaleX(0); }
  45%, 60% { transform: scaleX(1); opacity: 1; }
  70%, 100% { transform: scaleX(1); opacity: 0; }
}
/* Each particle rides a full-width track: translateX(100%) = the whole gap. */
@keyframes login-stream {
  0% { transform: translateX(0); opacity: 0; }
  10% { opacity: 1; }
  90% { opacity: 1; }
  100% { transform: translateX(100%); opacity: 0; }
}
@keyframes login-float {
  0%, 100% { transform: translateY(0) rotate(var(--r, 0deg)); }
  50% { transform: translateY(-14px) rotate(var(--r, 0deg)); }
}
@keyframes login-glow {
  0%, 100% { opacity: 0.35; transform: scale(1); }
  50% { opacity: 0.6; transform: scale(1.08); }
}
@keyframes login-scan-mini {
  0% { top: 10%; }
  50% { top: 82%; }
  100% { top: 10%; }
}

.login-scan { animation: login-scan 7s linear infinite both; }
.login-box { animation: login-box 7s ease-out infinite both; }
.login-field { animation: login-field 7s ease-out infinite both; }
.login-progress { animation: login-progress 7s ease-in-out infinite both; }
.login-stream { animation: login-stream 3s linear infinite both; }
.login-float { animation: login-float 9s ease-in-out infinite; }
.login-glow { animation: login-glow 8s ease-in-out infinite; }
.login-scan-mini { animation: login-scan-mini 2.4s ease-in-out infinite; }

/* Respect reduced-motion: show the finished extraction, no movement. */
@media (prefers-reduced-motion: reduce) {
  .login-box, .login-field, .login-progress, .login-stream, .login-float, .login-glow { animation: none; }
  .login-scan, .login-scan-mini, .login-stream { display: none; }
  .login-progress { transform: none; }
}
```

---

## 13. Deployment files

### 13.1 `backend/Dockerfile`

Add `gcc` and `libkrb5-dev` to the `apt-get install` list (needed to build `gssapi`/`krb5`). With prebuilt wheels (§4) only the runtime library `libgssapi-krb5-2` is needed instead.

```dockerfile
    gcc \
    libkrb5-dev \
```

### 13.2 `docker-compose.yml`

`backend` service (`environment:` and, for SSO, `volumes:`):

```yaml
      # Exact frontend origin(s); also the only origins allowed to use Windows SSO.
      CORS_ORIGINS: ${CORS_ORIGINS:-http://localhost:3000}
      REQUIRE_AUTH: ${REQUIRE_AUTH:-true}
      ADMIN_USERNAME: ${ADMIN_USERNAME:-administrator}
      ADMIN_PASSWORD: ${ADMIN_PASSWORD:-}
      JWT_EXPIRES_MINUTES: ${JWT_EXPIRES_MINUTES:-720}
      LDAP_ENABLED: ${LDAP_ENABLED:-true}
      LDAP_SERVER: ${LDAP_SERVER:-ldap://dev.team.ae}
      LDAP_USE_STARTTLS: ${LDAP_USE_STARTTLS:-false}
      LDAP_BASE_DN: ${LDAP_BASE_DN:-}
      LDAP_BIND_USER: ${LDAP_BIND_USER:-}
      LDAP_BIND_PASSWORD: ${LDAP_BIND_PASSWORD:-}
      SSO_ENABLED: ${SSO_ENABLED:-true}
      SSO_DOMAINS: ${SSO_DOMAINS:-}
      # Keytab for HTTP/<api-host> — mount it with the volume below.
      KRB5_KTNAME: ${KRB5_KTNAME:-/etc/krb5/http.keytab}
      # Windows SSO keytab (see .env.example):
      # - ./secrets/krb5:/etc/krb5:ro
```

`worker` service (`environment:`; no LDAP variables, the worker never authenticates users):

```yaml
      REQUIRE_AUTH: ${REQUIRE_AUTH:-true}
      ADMIN_USERNAME: ${ADMIN_USERNAME:-administrator}
      ADMIN_PASSWORD: ${ADMIN_PASSWORD:-}
      JWT_EXPIRES_MINUTES: ${JWT_EXPIRES_MINUTES:-720}
```

### 13.3 `.env.example`

```bash
# --- Security ---
# Strong random secret used to sign login JWTs (e.g. openssl rand -hex 32)
JWT_SECRET=CHANGE_ME
# Set to true to require "Authorization: Bearer <api_key>" on all /api/v1 endpoints
REQUIRE_API_KEY=false
# Set to true to require a logged-in user (username/password) OR an API key.
# The frontend redirects to /login until a valid session exists.
REQUIRE_AUTH=true
# Optional local administrator seed (signs in with a local password, never AD).
# Only created when ADMIN_PASSWORD is set; the password is then re-synced on
# every start. Leave empty to use the first-run screen instead: while no users
# exist, the web app asks for the first administrator's user name and password.
ADMIN_USERNAME=administrator
ADMIN_PASSWORD=
# Login session lifetime in minutes (12 hours by default)
JWT_EXPIRES_MINUTES=720
RATE_LIMIT_PER_MINUTE=120

# --- Active Directory (LDAP) ---
# Admins search AD and add users to the local DB (Users page). A user can sign
# in only when they exist in BOTH the DB and AD; the password is verified by
# AD. Local accounts (first-run administrator, ADMIN_PASSWORD seed) are the
# exception: they sign in with a local password.
LDAP_ENABLED=true
# ldap://host (389) or ldaps://host (636). The DC's IPs are allow-listed in the
# offline network guard automatically.
LDAP_SERVER=ldap://dev.team.ae
# Upgrade ldap:// to TLS (needed when the DC enforces LDAP signing).
LDAP_USE_STARTTLS=false
# Empty = read defaultNamingContext from the DC (e.g. DC=dev,DC=team,DC=ae)
LDAP_BASE_DN=
# Read-only service account used to search the directory and resolve user DNs.
# Any AD form works: svc_ocr@dev.team.ae, DEV\svc_ocr or a full DN.
LDAP_BIND_USER=
LDAP_BIND_PASSWORD=

# --- Windows single sign-on (Kerberos) ---
# Users who are not signed in are logged in automatically with their Windows
# account (still required: registered in the app AND enabled in AD). If that
# fails the login page is shown. Requirements:
#  1. Browse the app via a DNS name (not an IP/localhost), e.g. NEXT_PUBLIC_API_URL=http://ocr.dev.team.ae:8000
#  2. Register the SPN on the service account and export a keytab (on a DC):
#       setspn -S HTTP/ocr.dev.team.ae svc_ocr
#       ktpass /princ HTTP/ocr.dev.team.ae@DEV.TEAM.AE /mapuser DEV\svc_ocr /pass * /crypto AES256-SHA1 /ptype KRB5_NT_PRINCIPAL /out http.keytab
#     Put http.keytab in ./secrets/krb5/ and enable the volume in docker-compose.yml.
#  3. Browsers must trust the API host for Windows auth: add it to the Internet
#     Options "Local intranet" zone via GPO (Edge/Chrome), or
#     network.negotiate-auth.trusted-uris (Firefox).
#  4. Keep server clocks in sync with the DC (Kerberos allows ~5 min skew).
SSO_ENABLED=true
# Accepted realms / NetBIOS domains; empty = derived from the AD base DN (DEV.TEAM.AE, DEV)
SSO_DOMAINS=
KRB5_KTNAME=/etc/krb5/http.keytab
# Exact frontend origin(s), comma separated — the only sites allowed to call Windows SSO.
CORS_ORIGINS=http://localhost:3000
```

---

## 14. Test user

Local, standard (non-admin) test account used in development: **`test1`** / **`123456`**. Create it the same way in the offline environment (from `backend/`, after the backend has started once so the columns exist):

```bash
python -c "from app.core.database import SessionLocal; from app.models import models; from app.core.security import hash_password; from app.models.models import User; db=SessionLocal(); db.add(User(username='test1', hashed_password=hash_password('123456'), is_admin=False, auth_source='local', display_name='Test User 1', is_active=True)); db.commit()"
```

Do not create weak test accounts in production.

---

## 15. Verification checklist

**Backend**

- [ ] Startup log shows `admin_seed=…` and `service_account=configured`.
- [ ] Empty DB: `GET /api/v1/auth/setup` → `{"setup_required": true}`.
- [ ] `POST /api/v1/auth/setup` with a short password → `422`; valid → `201`; again → `409`.
- [ ] Local login (`test1` / `123456`) → `200`; wrong password → `401`.
- [ ] Disable `test1` (`PATCH /users/{id} {"is_active": false}`): login → `403`, old token → `/auth/me` not authenticated. Enable → login `200`.
- [ ] AD user added via `/users` → AD login `200`; wrong AD password → `401`.
- [ ] Admin cannot change own account → `400`. `DELETE /users/{id}` → `405`.

**Frontend**

- [ ] Empty DB → any page redirects to **Create administrator**; after saving you are on the dashboard as that user.
- [ ] Signed out → login page (centered card, animated backdrop, EN/AR switch).
- [ ] Users page: Status column; bin button → modal **"Do you want to disable the user?"** → Yes → Disabled badge; Enable button restores.
- [ ] Your own row: role and disable buttons greyed out.
- [ ] Disabled user sees "Your account is disabled. Contact the administrator."
- [ ] Exports / original file / page images load while signed in.

---

## 16. Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| Backend does not start: `database is locked` on `ALTER TABLE users ADD COLUMN …` | A SQLite tool (DB Browser) has `ocr.db` open | Close the database in the tool, restart the backend |
| "Active Directory is unavailable" on AD login / user search | `LDAP_BIND_USER`/`LDAP_BIND_PASSWORD` missing, DC unreachable, or LDAP signing required | Set the service account; try `ldaps://` or `LDAP_USE_STARTTLS=true` |
| Login page crash "Failed to execute 'insertBefore' on 'Node'" | Browser auto-translate rewrote the page | §12.3 (`translate="no"`); in the browser choose "Show original" once |
| Log: `SSO - incomplete handshake (browser offered NTLM …)` | PC not domain-joined, or app opened via `localhost`/IP | Expected; users get the login page. SSO needs a domain PC, DNS name, keytab and intranet-zone GPO |
| Setup screen never appears | Users already exist (setup only runs on an empty `users` table) | Sign in with an existing account, or start from an empty DB |
| Old `admin` row cannot log in | Rows with `auth_source = NULL` are treated as AD users | Disable it on the Users page, or set `auth_source='local'` and a bcrypt password |

---

## 17. Not included

These are not needed for login and user management:

- OCR, engines, analytics, storage changes.
- The `<span>` wrapping of the **System Health** and **OCR Lab** button labels (same auto-translate fix as the login button; optional, cosmetic robustness).
- Windows SSO infrastructure steps (SPN, keytab, browser GPO): see `AuthenticationChanges.md` §11.2.
