import { Badge } from "@/components/ui/badge";
import { confidenceLevel, formatPercent } from "@/lib/utils";

export function ConfidenceBadge({ value, className }: { value: number | null | undefined; className?: string }) {
  const level = confidenceLevel(value);
  if (level === "none") return <span className="text-muted-foreground">—</span>;
  const variant = level === "high" ? "success" : level === "medium" ? "warning" : "danger";
  return (
    <Badge variant={variant} className={className}>
      {formatPercent(value)}
    </Badge>
  );
}
