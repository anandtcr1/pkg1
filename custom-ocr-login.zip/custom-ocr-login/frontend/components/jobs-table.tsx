"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { Eye, RotateCcw, Trash2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { deleteJob, reprocessJob } from "@/lib/api";
import { useI18n } from "@/lib/i18n";
import type { JobSummary } from "@/lib/types";
import { documentTypeLabel, formatDate, formatSeconds, engineDisplayName } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { ConfidenceBadge } from "@/components/confidence-badge";
import { JobStatusBadge } from "@/components/job-status-badge";
import { Skeleton } from "@/components/ui/skeleton";

export function JobsTable({
  jobs,
  loading,
  onChanged,
}: {
  jobs: JobSummary[];
  loading?: boolean;
  onChanged?: () => void;
}) {
  const router = useRouter();
  const { t, lang } = useI18n();
  const [busyId, setBusyId] = useState<string | null>(null);

  const handleDelete = async (id: string) => {
    if (!confirm(t("jobs.confirm_delete"))) return;
    setBusyId(id);
    try {
      await deleteJob(id);
      toast.success(t("jobs.deleted"));
      onChanged?.();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("jobs.delete_failed"));
    } finally {
      setBusyId(null);
    }
  };

  const handleReprocess = async (id: string) => {
    setBusyId(id);
    try {
      await reprocessJob(id);
      toast.success(t("jobs.reprocess_started"));
      router.push(`/ocr/job?id=${id}`);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("jobs.reprocess_failed"));
      setBusyId(null);
    }
  };

  if (loading) {
    return (
      <div className="space-y-2">
        {Array.from({ length: 5 }).map((_, i) => (
          <Skeleton key={i} className="h-12 w-full" />
        ))}
      </div>
    );
  }

  if (jobs.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center rounded-xl border border-dashed py-14 text-center">
        <p className="font-medium">{t("jobs.empty.title")}</p>
        <p className="mt-1 text-sm text-muted-foreground">{t("jobs.empty.subtitle")}</p>
        <Button asChild className="mt-4">
          <Link href="/ocr">{t("nav.new_ocr")}</Link>
        </Button>
      </div>
    );
  }

  const headers = [
    t("jobs.file"),
    t("common.status"),
    t("jobs.type"),
    t("jobs.lang"),
    t("jobs.engine"),
    t("jobs.device"),
    t("jobs.pages"),
    t("jobs.confidence"),
    t("jobs.verified"),
    t("jobs.time"),
    t("common.created"),
  ];

  return (
    <div className="overflow-x-auto rounded-xl border">
      <table className="w-full text-sm">
        <thead className="bg-muted/50 text-start text-xs uppercase text-muted-foreground">
          <tr>
            {headers.map((h) => (
              <th key={h} className="px-4 py-3 text-start">
                {h}
              </th>
            ))}
            <th className="px-4 py-3 text-end">{t("common.actions")}</th>
          </tr>
        </thead>
        <tbody className="divide-y">
          {jobs.map((job) => (
            <tr key={job.id} className="hover:bg-muted/40">
              <td className="max-w-[220px] truncate px-4 py-3 font-medium" title={job.filename}>
                {job.filename}
              </td>
              <td className="px-4 py-3">
                <JobStatusBadge status={job.status} />
              </td>
              <td className="px-4 py-3 text-muted-foreground">{documentTypeLabel(job.document_type)}</td>
              <td className="px-4 py-3 uppercase text-muted-foreground">{job.language ?? "—"}</td>
              <td className="px-4 py-3 text-muted-foreground">
                {job.engine ? engineDisplayName(job.engine) : "—"}
                {job.engine_version ? <span className="ms-1 text-xs opacity-70">v{job.engine_version}</span> : null}
              </td>
              <td className="px-4 py-3 text-muted-foreground">{job.device ?? "—"}</td>
              <td className="px-4 py-3 text-muted-foreground">{job.page_count || "—"}</td>
              <td className="px-4 py-3">
                <ConfidenceBadge value={job.confidence} />
              </td>
              <td className="px-4 py-3">
                {job.verified_cer != null ? (
                  <ConfidenceBadge value={Math.max(0, 1 - job.verified_cer)} />
                ) : (
                  <span className="text-muted-foreground">{t("jobs.verified.empty")}</span>
                )}
              </td>
              <td className="px-4 py-3 text-muted-foreground">{formatSeconds(job.processing_time)}</td>
              <td className="px-4 py-3 text-muted-foreground">{formatDate(job.created_at, lang)}</td>
              <td className="px-4 py-3">
                <div className="flex justify-end gap-1">
                  <Button variant="ghost" size="icon" asChild title={t("jobs.open")}>
                    <Link href={`/ocr/job?id=${job.id}`}>
                      <Eye className="h-4 w-4" />
                    </Link>
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    title={t("jobs.rerun")}
                    disabled={busyId === job.id}
                    onClick={() => handleReprocess(job.id)}
                  >
                    <RotateCcw className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    title={t("common.delete")}
                    disabled={busyId === job.id}
                    onClick={() => handleDelete(job.id)}
                  >
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
