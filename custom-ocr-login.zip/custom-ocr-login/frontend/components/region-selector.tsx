"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ChevronDown, ChevronUp, Loader2, Trash2 } from "lucide-react";

import { useI18n } from "@/lib/i18n";
import type { RegionSpec } from "@/lib/types";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import type { PDFDocumentProxy } from "pdfjs-dist";

const MIN_SIZE = 0.02;

function clamp01(v: number): number {
  return Math.min(1, Math.max(0, v));
}

/**
 * Sorts by reading order and renumbers `order`/`label`, keeping every
 * normalized value inside [0,1] while ensuring x+width / y+height stay in page.
 */
function normalizeRegions(list: RegionSpec[]): RegionSpec[] {
  return [...list]
    .sort((a, b) => a.order - b.order)
    .map((r, i) => {
      const x = clamp01(r.x);
      const y = clamp01(r.y);
      const width = Math.max(MIN_SIZE, Math.min(1 - x, clamp01(r.width)));
      const height = Math.max(MIN_SIZE, Math.min(1 - y, clamp01(r.height)));
      return { ...r, x, y, width, height, order: i, label: String(i + 1) };
    });
}

interface RegionSelectorProps {
  file: File;
  regions: RegionSpec[];
  onChange: (regions: RegionSpec[]) => void;
}

/** Interactive per-page region drawing on top of an image or any PDF page. */
export default function RegionSelector({ file, regions, onChange }: RegionSelectorProps) {
  const { t } = useI18n();

  const isPdf = file.type === "application/pdf";
  const fileUrl = useMemo(() => URL.createObjectURL(file), [file]);

  const boxRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const pdfDocRef = useRef<PDFDocumentProxy | null>(null);
  const renderTokenRef = useRef(0);

  const [pageNumber, setPageNumber] = useState(1);
  const [pageCount, setPageCount] = useState(0);
  const [previewReady, setPreviewReady] = useState(false);
  const [previewLoading, setPreviewLoading] = useState(isPdf);
  const [pdfError, setPdfError] = useState<string | null>(null);
  const [selected, setSelected] = useState<number | null>(null);
  const [draft, setDraft] = useState<RegionSpec | null>(null);

  const drawRef = useRef<{ startX: number; startY: number; active: boolean } | null>(null);
  const moveRef = useRef<{
    localIndex: number;
    startX: number;
    startY: number;
    origX: number;
    origY: number;
  } | null>(null);
  const resizeRef = useRef<{
    localIndex: number;
    startX: number;
    startY: number;
    origX: number;
    origY: number;
    origW: number;
    origH: number;
  } | null>(null);

  const currentPage = isPdf ? pageNumber : 1;
  const currentRegions = useMemo(
    () => regions.filter((r) => r.page_number === currentPage),
    [regions, currentPage]
  );

  useEffect(() => {
    return () => URL.revokeObjectURL(fileUrl);
  }, [fileUrl]);

  const commit = useCallback(
    (next: RegionSpec[]) => onChange(normalizeRegions(next)),
    [onChange]
  );

  /** Apply `fn` to the localIndex-th region belonging to the current page. */
  const mapCurrent = useCallback(
    (localIndex: number, fn: (r: RegionSpec) => RegionSpec) => {
      let seen = -1;
      commit(
        regions.map((r) => {
          if (r.page_number === currentPage) seen += 1;
          if (seen === localIndex) return fn(r);
          return r;
        })
      );
    },
    [regions, currentPage, commit]
  );

  const addRegion = useCallback(
    (spec: { x: number; y: number; width: number; height: number }) => {
      commit([
        ...regions,
        {
          page_number: currentPage,
          label: "",
          x: spec.x,
          y: spec.y,
          width: spec.width,
          height: spec.height,
          order: regions.length,
        },
      ]);
      setSelected(regions.filter((r) => r.page_number === currentPage).length);
    },
    [regions, currentPage, commit]
  );

  const removeRegion = useCallback(
    (localIndex: number) => {
      let seen = -1;
      commit(
        regions.filter((r) => {
          if (r.page_number === currentPage) seen += 1;
          return !(seen === localIndex);
        })
      );
      setSelected(null);
    },
    [regions, currentPage, commit]
  );

  const moveRegion = useCallback(
    (localIndex: number, delta: number) => {
      const positions: number[] = [];
      regions.forEach((r, i) => {
        if (r.page_number === currentPage) positions.push(i);
      });
      const a = positions[localIndex];
      const b = positions[localIndex + delta];
      if (a === undefined || b === undefined) return;
      const next = [...regions];
      [next[a], next[b]] = [next[b], next[a]];
      commit(next);
      setSelected(localIndex + delta);
    },
    [regions, currentPage, commit]
  );

  const selectFullPage = useCallback(() => {
    const idx = currentRegions.findIndex(
      (r) => r.x <= 0.001 && r.y <= 0.001 && r.width >= 0.999 && r.height >= 0.999
    );
    if (idx !== -1) {
      setSelected(idx);
      return;
    }
    addRegion({ x: 0, y: 0, width: 1, height: 1 });
  }, [currentRegions, addRegion]);

  const clearPage = useCallback(() => {
    commit(regions.filter((r) => r.page_number !== currentPage));
    setSelected(null);
  }, [regions, currentPage, commit]);

  /** Convert client pointer coords into normalized coords inside the rendered image box. */
  const toNorm = useCallback(
    (clientX: number, clientY: number): { x: number; y: number } | null => {
      const el = boxRef.current;
      if (!el) return null;
      const rect = el.getBoundingClientRect();
      if (rect.width <= 0 || rect.height <= 0) return null;
      return {
        x: clamp01((clientX - rect.left) / rect.width),
        y: clamp01((clientY - rect.top) / rect.height),
      };
    },
    []
  );

  // ---- drawing (click-drag on the empty preview) ----

  const handleBoxPointerDown = useCallback(
    (e: React.PointerEvent<HTMLDivElement>) => {
      const p = toNorm(e.clientX, e.clientY);
      if (!p) return;
      setSelected(null);
      try {
        e.currentTarget.setPointerCapture(e.pointerId);
      } catch {
        // pointer capture is best-effort
      }
      drawRef.current = { startX: p.x, startY: p.y, active: true };
      setDraft({
        page_number: currentPage,
        label: "",
        x: p.x,
        y: p.y,
        width: 0,
        height: 0,
        order: 0,
      });
    },
    [toNorm, currentPage]
  );

  const handleBoxPointerMove = useCallback(
    (e: React.PointerEvent<HTMLDivElement>) => {
      const draw = drawRef.current;
      if (!draw?.active) return;
      const p = toNorm(e.clientX, e.clientY);
      if (!p) return;
      setDraft((prev) => {
        if (!prev) return prev;
        const x = Math.min(draw.startX, p.x);
        const y = Math.min(draw.startY, p.y);
        return {
          ...prev,
          x,
          y,
          width: Math.min(Math.abs(p.x - draw.startX), 1 - x),
          height: Math.min(Math.abs(p.y - draw.startY), 1 - y),
        };
      });
    },
    [toNorm]
  );

  const handleBoxPointerUp = useCallback(
    (e: React.PointerEvent<HTMLDivElement>) => {
      const draw = drawRef.current;
      if (!draw?.active) return;
      drawRef.current = null;
      setDraft(null);
      const p = toNorm(e.clientX, e.clientY);
      if (!p) return;
      const x = Math.min(draw.startX, p.x);
      const y = Math.min(draw.startY, p.y);
      const width = Math.abs(p.x - draw.startX);
      const height = Math.abs(p.y - draw.startY);
      if (width >= MIN_SIZE && height >= MIN_SIZE) {
        addRegion({ x, y, width, height });
      }
    },
    [toNorm, addRegion]
  );

  // ---- moving a region ----

  const handleRegionPointerDown = useCallback(
    (e: React.PointerEvent<HTMLDivElement>, region: RegionSpec, localIndex: number) => {
      e.stopPropagation();
      const p = toNorm(e.clientX, e.clientY);
      if (!p) return;
      setSelected(localIndex);
      try {
        e.currentTarget.setPointerCapture(e.pointerId);
      } catch {
        // pointer capture is best-effort
      }
      moveRef.current = {
        localIndex,
        startX: p.x,
        startY: p.y,
        origX: region.x,
        origY: region.y,
      };
    },
    [toNorm]
  );

  const handleRegionPointerMove = useCallback(
    (e: React.PointerEvent<HTMLDivElement>) => {
      const m = moveRef.current;
      if (!m) return;
      const p = toNorm(e.clientX, e.clientY);
      if (!p) return;
      const x = clamp01(m.origX + (p.x - m.startX));
      const y = clamp01(m.origY + (p.y - m.startY));
      mapCurrent(m.localIndex, (r) => ({ ...r, x, y }));
    },
    [toNorm, mapCurrent]
  );

  const handleRegionPointerUp = useCallback(() => {
    moveRef.current = null;
  }, []);

  // ---- resizing a region (bottom-right handle) ----

  const handleResizePointerDown = useCallback(
    (e: React.PointerEvent<HTMLElement>, region: RegionSpec, localIndex: number) => {
      e.stopPropagation();
      const p = toNorm(e.clientX, e.clientY);
      if (!p) return;
      try {
        e.currentTarget.setPointerCapture(e.pointerId);
      } catch {
        // pointer capture is best-effort
      }
      resizeRef.current = {
        localIndex,
        startX: p.x,
        startY: p.y,
        origX: region.x,
        origY: region.y,
        origW: region.width,
        origH: region.height,
      };
    },
    [toNorm]
  );

  const handleResizePointerMove = useCallback(
    (e: React.PointerEvent<HTMLElement>) => {
      const rz = resizeRef.current;
      if (!rz) return;
      const p = toNorm(e.clientX, e.clientY);
      if (!p) return;
      mapCurrent(rz.localIndex, (r) => ({
        ...r,
        width: Math.max(MIN_SIZE, Math.min(rz.origW + (p.x - rz.startX), 1 - r.x)),
        height: Math.max(MIN_SIZE, Math.min(rz.origH + (p.y - rz.startY), 1 - r.y)),
      }));
    },
    [toNorm, mapCurrent]
  );

  const handleResizePointerUp = useCallback(() => {
    resizeRef.current = null;
  }, []);

  // ---- PDF rendering (pdfjs-dist, worker configured like document-viewer.tsx) ----

  const renderPdfPage = useCallback(async (n: number, token: number) => {
    const doc = pdfDocRef.current;
    if (!doc) return;
    setPreviewLoading(true);
    setPreviewReady(false);
    try {
      const pdfjs = await import("pdfjs-dist");
      const pg = await doc.getPage(n);
      const base = pg.getViewport({ scale: 1 });
      const scale = Math.min(2, 1000 / Math.max(base.width, 1));
      const viewport = pg.getViewport({ scale });
      const canvas = canvasRef.current;
      if (!canvas || token !== renderTokenRef.current) return;
      canvas.width = Math.max(1, Math.round(viewport.width));
      canvas.height = Math.max(1, Math.round(viewport.height));
      const ctx = canvas.getContext("2d");
      if (!ctx || token !== renderTokenRef.current) return;
      await pg.render({ canvasContext: ctx, viewport }).promise;
      if (token !== renderTokenRef.current) return;
      setPreviewReady(true);
    } catch (err) {
      if (token === renderTokenRef.current) {
        setPdfError(err instanceof Error ? err.message : "PDF render failed");
      }
    } finally {
      if (token === renderTokenRef.current) setPreviewLoading(false);
    }
  }, []);

  useEffect(() => {
    const token = ++renderTokenRef.current;
    let cancelled = false;
    setSelected(null);
    setDraft(null);
    drawRef.current = null;
    moveRef.current = null;
    resizeRef.current = null;
    pdfDocRef.current = null;
    setPdfError(null);
    setPreviewReady(false);

    if (!isPdf) {
      setPageCount(0);
      setPageNumber(1);
      setPreviewLoading(false);
      return;
    }

    setPreviewLoading(true);
    (async () => {
      try {
        const pdfjs = await import("pdfjs-dist");
        pdfjs.GlobalWorkerOptions.workerSrc = new URL(
          "pdfjs-dist/build/pdf.worker.min.mjs",
          import.meta.url
        ).toString();
        const doc = await pdfjs.getDocument(fileUrl).promise;
        if (cancelled || token !== renderTokenRef.current) return;
        pdfDocRef.current = doc;
        setPageCount(doc.numPages);
        setPageNumber(1);
        await renderPdfPage(1, token);
      } catch (err) {
        if (!cancelled && token === renderTokenRef.current) {
          setPdfError(err instanceof Error ? err.message : "PDF render failed");
          setPreviewLoading(false);
        }
      }
    })();

    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fileUrl, isPdf]);

  const handleSwitchPage = useCallback(
    (n: number) => {
      if (n === pageNumber) return;
      setSelected(null);
      setDraft(null);
      drawRef.current = null;
      moveRef.current = null;
      resizeRef.current = null;
      setPageNumber(n);
      const token = ++renderTokenRef.current;
      void renderPdfPage(n, token);
    },
    [pageNumber, renderPdfPage]
  );

  const overlay = (
    <div className="pointer-events-none absolute inset-0">
      {currentRegions.map((region, i) => {
        const active = selected === i;
        return (
          <div
            key={`${region.page_number}-${i}-${region.order}`}
            onPointerDown={(e) => handleRegionPointerDown(e, region, i)}
            onPointerMove={handleRegionPointerMove}
            onPointerUp={handleRegionPointerUp}
            onPointerCancel={handleRegionPointerUp}
            className={cn(
              "group pointer-events-auto absolute cursor-move border-2",
              active
                ? "z-20 border-primary bg-primary/20 ring-2 ring-primary/60"
                : "z-10 border-sky-500/80 bg-sky-500/15 hover:ring-2 hover:ring-sky-500/50"
            )}
            style={{
              left: `${region.x * 100}%`,
              top: `${region.y * 100}%`,
              width: `${region.width * 100}%`,
              height: `${region.height * 100}%`,
            }}
          >
            <span
              className="pointer-events-none absolute left-1 top-1 flex h-5 min-w-5 items-center justify-center rounded bg-primary px-1 text-[10px] font-bold leading-none text-primary-foreground"
            >
              {region.order + 1}
            </span>

            {active && (
              <div
                className="absolute -top-9 left-0 z-30 flex items-center gap-0.5 rounded-md border bg-background p-0.5 shadow-sm"
                onPointerDown={(e) => e.stopPropagation()}
              >
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6"
                  title={t("ocr.region.delete")}
                  onClick={(e) => {
                    e.stopPropagation();
                    removeRegion(i);
                  }}
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6"
                  disabled={i === 0}
                  title={t("ocr.region.up")}
                  onClick={(e) => {
                    e.stopPropagation();
                    moveRegion(i, -1);
                  }}
                >
                  <ChevronUp className="h-3.5 w-3.5" />
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6"
                  disabled={i >= currentRegions.length - 1}
                  title={t("ocr.region.down")}
                  onClick={(e) => {
                    e.stopPropagation();
                    moveRegion(i, 1);
                  }}
                >
                  <ChevronDown className="h-3.5 w-3.5" />
                </Button>
              </div>
            )}

            <span
              onPointerDown={(e) => handleResizePointerDown(e, region, i)}
              onPointerMove={handleResizePointerMove}
              onPointerUp={handleResizePointerUp}
              onPointerCancel={handleResizePointerUp}
              className="pointer-events-auto absolute -bottom-1.5 -right-1.5 z-30 block h-4 w-4 cursor-nwse-resize rounded-sm bg-primary shadow-sm ring-1 ring-primary-foreground/40"
            />
          </div>
        );
      })}

      {draft && (
        <div
          className="pointer-events-none absolute z-30 rounded-sm border-2 border-dashed border-primary bg-primary/10"
          style={{
            left: `${draft.x * 100}%`,
            top: `${draft.y * 100}%`,
            width: `${draft.width * 100}%`,
            height: `${draft.height * 100}%`,
          }}
        />
      )}
    </div>
  );

  return (
    <div className="space-y-4">
      <div className="relative flex h-[520px] w-full items-center justify-center overflow-hidden rounded-lg border bg-muted/30">
        <div
          ref={boxRef}
          className="relative max-w-full select-none"
          onPointerDown={handleBoxPointerDown}
          onPointerMove={handleBoxPointerMove}
          onPointerUp={handleBoxPointerUp}
          onPointerCancel={handleBoxPointerUp}
          style={{ cursor: "crosshair", touchAction: "none" }}
        >
          {isPdf ? (
            <canvas
              ref={canvasRef}
              className={cn("block max-h-[500px] max-w-full", !previewReady && "invisible")}
            />
          ) : (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={fileUrl}
              alt=""
              draggable={false}
              className="pointer-events-none block h-auto max-h-[500px] w-auto max-w-full"
              onLoad={() => setPreviewLoading(false)}
            />
          )}

          {overlay}
        </div>

        {(previewLoading || (isPdf && !previewReady)) && (
          <div className="pointer-events-none absolute inset-0 flex items-center justify-center bg-muted/40">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            {isPdf && <span className="sr-only">{t("ocr.region.pdf.thumb_loading")}</span>}
          </div>
        )}

        {isPdf && !previewLoading && !previewReady && pdfError && (
          <p className="max-w-[80%] text-center text-sm text-destructive">{pdfError}</p>
        )}
      </div>

      {isPdf && pageCount > 1 && (
        <div className="flex items-center gap-2">
          <span className="shrink-0 text-xs font-medium text-muted-foreground">{t("ocr.region.pdf.pages")}</span>
          <div className="flex max-w-full gap-1 overflow-x-auto pb-0.5">
            {Array.from({ length: pageCount }, (_, i) => i + 1).map((n) => (
              <Button
                key={n}
                type="button"
                size="sm"
                variant={n === pageNumber ? "default" : "outline"}
                className="h-7 shrink-0 px-2.5 text-xs"
                onClick={() => handleSwitchPage(n)}
              >
                {t("ocr.region.pdf.page", { n })}
              </Button>
            ))}
          </div>
        </div>
      )}

      <div className="flex flex-wrap items-center gap-2">
        <Button type="button" variant="outline" size="sm" onClick={selectFullPage}>
          {t("ocr.region.full")}
        </Button>
        <Button type="button" variant="outline" size="sm" onClick={clearPage}>
          {t("ocr.region.clear")}
        </Button>
      </div>
    </div>
  );
}