"use client";

import { Badge } from "@/components/ui/badge";
import { useI18n, type TranslationKey } from "@/lib/i18n";

const STATUS_VARIANT: Record<string, "success" | "warning" | "danger" | "info" | "secondary"> = {
  completed: "success",
  processing: "info",
  pending: "warning",
  failed: "danger",
};

export function JobStatusBadge({ status }: { status: string }) {
  const { t } = useI18n();
  const variant = STATUS_VARIANT[status] ?? "secondary";
  const key = `status.${status}` as TranslationKey;
  return <Badge variant={variant}>{t(key)}</Badge>;
}
