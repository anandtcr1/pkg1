"use client";

import { useI18n, type TranslationKey } from "@/lib/i18n";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import type { EngineInfo, EngineName, LanguageInfo } from "@/lib/types";
import { engineDisplayName } from "@/lib/utils";

export interface OCROptionsState {
  engine: "auto";
  engine_select: EngineName;
  language: string;
  quality_mode: "fast" | "balanced" | "high";
  device_preference: "auto" | "cpu" | "cuda";
  deskew: boolean;
  denoise: boolean;
  auto_rotate: boolean;
  enhance_contrast: boolean;
  detect_tables: boolean;
  structured_extraction: boolean;
  preserve_layout: boolean;
  preserve_diacritics: boolean;
  preserve_punctuation: boolean;
  handwriting_detection: boolean;
  qari_mode: "auto" | "printed" | "handwritten";
}

type ToggleKey =
  | "deskew"
  | "denoise"
  | "auto_rotate"
  | "enhance_contrast"
  | "detect_tables"
  | "structured_extraction"
  | "preserve_layout"
  | "preserve_diacritics"
  | "preserve_punctuation"
  | "handwriting_detection";

export const DEFAULT_OPTIONS: OCROptionsState = {
  engine: "auto",
  engine_select: "auto",
  language: "auto",
  quality_mode: "balanced",
  device_preference: "auto",
  deskew: true,
  denoise: true,
  auto_rotate: true,
  enhance_contrast: true,
  detect_tables: false,
  structured_extraction: true,
  preserve_layout: true,
  preserve_diacritics: true,
  preserve_punctuation: true,
  handwriting_detection: false,
  qari_mode: "auto",
};

export const QUALITY_MODES: { value: "fast" | "balanced" | "high"; labelKey: TranslationKey }[] = [
  { value: "fast", labelKey: "ocr.quality.fast" },
  { value: "balanced", labelKey: "ocr.quality.balanced" },
  { value: "high", labelKey: "ocr.quality.high" },
];

export const DEVICES: { value: "auto" | "cpu" | "cuda"; labelKey: TranslationKey }[] = [
  { value: "auto", labelKey: "ocr.device.auto" },
  { value: "cpu", labelKey: "ocr.device.cpu" },
  { value: "cuda", labelKey: "ocr.device.cuda" },
];

const TOGGLES: { key: ToggleKey; labelKey: TranslationKey; hintKey: TranslationKey }[] = [
  { key: "deskew", labelKey: "ocr.opt.deskew", hintKey: "ocr.opt.deskew.hint" },
  { key: "denoise", labelKey: "ocr.opt.denoise", hintKey: "ocr.opt.denoise.hint" },
  { key: "auto_rotate", labelKey: "ocr.opt.auto_rotate", hintKey: "ocr.opt.auto_rotate.hint" },
  { key: "enhance_contrast", labelKey: "ocr.opt.enhance_contrast", hintKey: "ocr.opt.enhance_contrast.hint" },
  { key: "detect_tables", labelKey: "ocr.opt.detect_tables", hintKey: "ocr.opt.detect_tables.hint" },
  { key: "structured_extraction", labelKey: "ocr.opt.structured_extraction", hintKey: "ocr.opt.structured_extraction.hint" },
  { key: "preserve_layout", labelKey: "ocr.opt.preserve_layout", hintKey: "ocr.opt.preserve_layout.hint" },
  { key: "preserve_diacritics", labelKey: "ocr.opt.preserve_diacritics", hintKey: "ocr.opt.preserve_diacritics.hint" },
  { key: "preserve_punctuation", labelKey: "ocr.opt.preserve_punctuation", hintKey: "ocr.opt.preserve_punctuation.hint" },
  { key: "handwriting_detection", labelKey: "ocr.opt.handwriting", hintKey: "ocr.opt.handwriting.hint" },
];

export function OCROptionsPanel({
  options,
  onChange,
  engines,
  languages = [],
}: {
  options: OCROptionsState;
  onChange: (next: OCROptionsState) => void;
  engines: EngineInfo[];
  languages?: LanguageInfo[];
}) {
  const { t, lang } = useI18n();

  return (
    <div className="space-y-5">
      <div className="space-y-2">
        <Label>{t("ocr.engine")}</Label>
        <Select
          value={options.engine_select}
          onValueChange={(v) => onChange({ ...options, engine: "auto", engine_select: v as EngineName })}
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="auto">{t("ocr.engine.auto")}</SelectItem>
            {engines.map((e) => (
              <SelectItem key={e.name} value={e.name}>
                {engineDisplayName(e.name)}
                {e.status !== "READY" ? ` ${t("ocr.engine.not_installed")}` : ""}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {options.engine_select !== "auto" &&
          engines.find((e) => e.name === options.engine_select)?.status !== "READY" && (
            <p className="text-xs text-amber-600 dark:text-amber-400">{t("ocr.engine.fallback_note")}</p>
          )}
      </div>

      <div className="space-y-2">
        <Label>{t("ocr.language")}</Label>
        <Select
          value={options.language}
          onValueChange={(v) => onChange({ ...options, language: v as OCROptionsState["language"] })}
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="auto">{t("ocr.lang.auto")}</SelectItem>
            {languages.map((l) => (
              <SelectItem key={l.code} value={l.code}>
                {lang === "ar" ? l.name_ar : l.name_en}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {options.engine_select === "qari" && (
        <div className="space-y-2">
          <Label>{t("ocr.qari.mode")}</Label>
          <Select
            value={options.qari_mode}
            onValueChange={(v) => onChange({ ...options, qari_mode: v as OCROptionsState["qari_mode"] })}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="auto">{t("ocr.qari.mode.auto")}</SelectItem>
              <SelectItem value="printed">{t("ocr.qari.mode.printed")}</SelectItem>
              <SelectItem value="handwritten">{t("ocr.qari.mode.handwritten")}</SelectItem>
            </SelectContent>
          </Select>
          <p className="text-xs text-muted-foreground">{t("ocr.qari.mode.hint")}</p>
        </div>
      )}

      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-2">
          <Label>{t("ocr.quality")}</Label>
          <Select
            value={options.quality_mode}
            onValueChange={(v) => onChange({ ...options, quality_mode: v as OCROptionsState["quality_mode"] })}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {QUALITY_MODES.map((m) => (
                <SelectItem key={m.value} value={m.value}>
                  {t(m.labelKey)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label>{t("ocr.device")}</Label>
          <Select
            value={options.device_preference}
            onValueChange={(v) => onChange({ ...options, device_preference: v as OCROptionsState["device_preference"] })}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {DEVICES.map((d) => (
                <SelectItem key={d.value} value={d.value}>
                  {t(d.labelKey)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-3">
        {TOGGLES.map((toggle) => (
          <div key={toggle.key} className="flex items-center justify-between gap-4">
            <div>
              <Label htmlFor={`opt-${toggle.key}`} className="cursor-pointer">
                {t(toggle.labelKey)}
              </Label>
              <p className="text-xs text-muted-foreground">{t(toggle.hintKey)}</p>
            </div>
            <Switch
              id={`opt-${toggle.key}`}
              checked={Boolean(options[toggle.key])}
              onCheckedChange={(checked) => onChange({ ...options, [toggle.key]: checked })}
            />
          </div>
        ))}
      </div>
    </div>
  );
}