"use client";

import type { OCRBlock } from "@/lib/types";
import { cn, confidenceLevel } from "@/lib/utils";

/**
 * Absolutely-positioned bounding boxes rendered over a page image/canvas.
 * `renderWidth/renderHeight` = on-screen size; `imageWidth/imageHeight` = the
 * pixel space the OCR engine produced the bbox coordinates in.
 */
export function BBoxOverlay({
  blocks,
  imageWidth,
  imageHeight,
  renderWidth,
  renderHeight,
  hoveredId,
  onHover,
}: {
  blocks: OCRBlock[];
  imageWidth: number;
  imageHeight: number;
  renderWidth: number;
  renderHeight: number;
  hoveredId: string | null;
  onHover: (id: string | null) => void;
}) {
  if (!imageWidth || !imageHeight) return null;
  const sx = renderWidth / imageWidth;
  const sy = renderHeight / imageHeight;

  return (
    <div className="pointer-events-none absolute inset-0">
      {blocks.map((block) => {
        if (!block.bbox) return null;
        const [x1, y1, x2, y2] = block.bbox;
        const level = confidenceLevel(block.confidence);
        const active = hoveredId === block.id;
        return (
          <div
            key={block.id}
            onMouseEnter={() => onHover(block.id)}
            onMouseLeave={() => onHover(null)}
            title={`${block.text} (${Math.round((block.confidence ?? 0) * 100)}%)`}
            className={cn(
              "pointer-events-auto absolute rounded-sm border transition-all",
              level === "high" && "border-emerald-500/60",
              level === "medium" && "border-amber-500/60",
              level === "low" && "border-red-500/70",
              level === "none" && "border-sky-500/60",
              active
                ? "z-10 bg-primary/25 ring-2 ring-primary"
                : "bg-transparent hover:bg-primary/15"
            )}
            style={{
              left: x1 * sx,
              top: y1 * sy,
              width: Math.max((x2 - x1) * sx, 2),
              height: Math.max((y2 - y1) * sy, 2),
            }}
          />
        );
      })}
    </div>
  );
}
