"use client";

import { Languages } from "lucide-react";

import { useI18n } from "@/lib/i18n";
import { cn } from "@/lib/utils";

export function LanguageSwitcher({ compact = false }: { compact?: boolean }) {
  const { lang, setLang } = useI18n();

  return (
    <div className="flex items-center gap-1 rounded-lg border bg-background p-0.5">
      {!compact && <Languages className="mx-1 h-3.5 w-3.5 text-muted-foreground" />}
      <button
        type="button"
        onClick={() => setLang("ar")}
        className={cn(
          "rounded-md px-2 py-1 text-xs font-medium transition-colors",
          lang === "ar" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
        )}
      >
        عربي
      </button>
      <button
        type="button"
        onClick={() => setLang("en")}
        className={cn(
          "rounded-md px-2 py-1 text-xs font-medium transition-colors",
          lang === "en" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
        )}
      >
        EN
      </button>
    </div>
  );
}
