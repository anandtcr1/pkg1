"use client";

import { useEffect, useState } from "react";
import { usePathname, useRouter } from "next/navigation";

import { getAuthMe, isWindowsSsoSkipped, setStoredToken, skipWindowsSso, windowsLogin } from "@/lib/api";
import { useI18n } from "@/lib/i18n";

export function AuthGuard({ children }: { children: React.ReactNode }) {
  const { t } = useI18n();
  const pathname = usePathname();
  const router = useRouter();
  const [ready, setReady] = useState(false);
  const [trying, setTrying] = useState(false);

  useEffect(() => {
    if (pathname === "/login") {
      setReady(true);
      return;
    }
    let cancelled = false;

    async function check() {
      let me;
      try {
        me = await getAuthMe();
      } catch {
        // Backend unreachable: don't lock the user out — pages will show errors.
        if (!cancelled) setReady(true);
        return;
      }
      if (cancelled) return;
      if (me.setup_required) {
        router.replace("/setup"); // no users yet: create the first administrator
        return;
      }
      if (me.authenticated && me.kind !== "anonymous") {
        setReady(true);
        return;
      }

      // Not signed in: try the Windows account first (user must be registered + in AD).
      if (!isWindowsSsoSkipped()) {
        setTrying(true);
        const session = await windowsLogin();
        if (cancelled) return;
        setTrying(false);
        if (session) {
          setStoredToken(session.access_token);
          setReady(true);
          return;
        }
        skipWindowsSso(); // don't retry on every navigation in this browser session
      }

      if (me.auth_required) {
        router.replace("/login");
        return;
      }
      setReady(true); // auth is off: continue anonymously
    }

    check();
    return () => {
      cancelled = true;
    };
  }, [pathname, router]);

  if (!ready) {
    return (
      <div className="py-24 text-center text-sm text-muted-foreground">
        {trying ? t("auth.windows_trying") : t("common.loading")}
      </div>
    );
  }
  return <>{children}</>;
}
