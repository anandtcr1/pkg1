"use client";

import { useMemo, useState } from "react";
import { Check, Pencil, SkipForward } from "lucide-react";
import { toast } from "sonner";

import { createCorrection } from "@/lib/api";
import { useI18n } from "@/lib/i18n";
import type { JobDetail, OCRBlock } from "@/lib/types";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn, isRtl } from "@/lib/utils";

interface ReviewItem {
  block: OCRBlock;
  pageNumber: number;
}

/**
 * Low-confidence review mode: every block under 0.80 confidence is listed for
 * manual correction. Accepted/edited values are stored in ocr_corrections and
 * can be exported as a fine-tuning dataset.
 */
export function ReviewPanel({
  job,
  threshold = 0.8,
  onHoverBlock,
  onSaved,
}: {
  job: JobDetail;
  threshold?: number;
  onHoverBlock: (id: string | null) => void;
  onSaved: () => void;
}) {
  const { t } = useI18n();
  const items = useMemo<ReviewItem[]>(() => {
    const out: ReviewItem[] = [];
    for (const page of job.pages) {
      for (const block of page.blocks) {
        if ((block.confidence ?? 1) < threshold) out.push({ block, pageNumber: page.page_number });
      }
    }
    return out;
  }, [job, threshold]);

  const [edits, setEdits] = useState<Record<string, string>>({});
  const [resolved, setResolved] = useState<Record<string, "accepted" | "ignored">>({});
  const [editingId, setEditingId] = useState<string | null>(null);
  const [savingId, setSavingId] = useState<string | null>(null);

  const pending = items.filter((i) => !resolved[i.block.id]);
  const pctThreshold = Math.round(threshold * 100);

  const save = async (item: ReviewItem) => {
    const corrected = (edits[item.block.id] ?? item.block.text).trim();
    if (!corrected || corrected === item.block.text.trim()) {
      setResolved((r) => ({ ...r, [item.block.id]: "ignored" }));
      return;
    }
    setSavingId(item.block.id);
    try {
      await createCorrection({
        job_id: job.id,
        page_number: item.pageNumber,
        original_text: item.block.text,
        corrected_text: corrected,
        confidence: item.block.confidence,
        language: item.block.language,
        bbox: item.block.bbox,
      });
      setResolved((r) => ({ ...r, [item.block.id]: "accepted" }));
      toast.success(t("review.saved"));
      onSaved();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("review.save_failed"));
    } finally {
      setSavingId(null);
    }
  };

  if (items.length === 0) {
    const total = job.pages.reduce((n, p) => n + p.blocks.length, 0);
    return (
      <div className="flex flex-col items-center justify-center rounded-xl border border-dashed py-14 text-center">
        <Check className="h-8 w-8 text-emerald-500" />
        <p className="mt-2 font-medium">{t("review.empty.title")}</p>
        <p className="text-sm text-muted-foreground">
          {t("review.empty.subtitle", { total, pct: pctThreshold })}
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="text-sm text-muted-foreground">
          {t("review.pending", {
            count: pending.length,
            items: t(pending.length === 1 ? "review.items.one" : "review.items.many"),
            total: items.length,
            pct: pctThreshold,
          })}
        </p>
        <Button
          variant="outline"
          size="sm"
          onClick={() => {
            const rest = Object.fromEntries(pending.map((i) => [i.block.id, "ignored" as const]));
            setResolved((r) => ({ ...r, ...rest }));
          }}
          disabled={pending.length === 0}
        >
          <SkipForward className="me-1 h-3.5 w-3.5 rtl:-scale-x-100" /> {t("review.ignore_all")}
        </Button>
      </div>

      <div className="space-y-2">
        {items.map((item) => {
          const state = resolved[item.block.id];
          const isEditing = editingId === item.block.id;
          const pct = Math.round((item.block.confidence ?? 0) * 100);
          return (
            <div
              key={item.block.id}
              onMouseEnter={() => onHoverBlock(item.block.id)}
              onMouseLeave={() => onHoverBlock(null)}
              className={cn(
                "rounded-lg border p-3 transition-colors",
                state === "accepted" && "border-emerald-500/40 bg-emerald-500/5",
                state === "ignored" && "opacity-50"
              )}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                    <span>{t("review.detected", { page: item.pageNumber, pct })}</span>
                    {item.block.region_label && (
                      <Badge
                        variant="outline"
                        dir="ltr"
                        className="border-cyan-400/40 px-1.5 text-[10px] font-medium leading-3 text-cyan-600 dark:text-cyan-400"
                      >
                        {t("ocr.region.block_source", { label: item.block.region_label })}
                      </Badge>
                    )}
                  </div>
                  <p
                    className={cn("mt-0.5 break-words font-medium", isRtl(item.block.language) && "rtl-text")}
                    dir={isRtl(item.block.language) ? "rtl" : "ltr"}
                  >
                    {item.block.text}
                  </p>
                </div>
                {!state && (
                  <div className="flex shrink-0 flex-wrap gap-1">
                    <Button
                      size="sm"
                      variant="outline"
                      disabled={savingId === item.block.id}
                      onClick={() => save(item)}
                    >
                      <Check className="me-1 h-3.5 w-3.5" /> {t("review.accept")}
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setEditingId(isEditing ? null : item.block.id);
                        setEdits((e) => ({ ...e, [item.block.id]: e[item.block.id] ?? item.block.text }));
                      }}
                    >
                      <Pencil className="me-1 h-3.5 w-3.5" /> {t("review.edit")}
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => setResolved((r) => ({ ...r, [item.block.id]: "ignored" }))}
                    >
                      {t("review.ignore")}
                    </Button>
                  </div>
                )}
                {state === "accepted" && (
                  <span className="text-xs font-medium text-emerald-600 dark:text-emerald-400">
                    {t("review.corrected")}
                  </span>
                )}
                {state === "ignored" && (
                  <span className="text-xs text-muted-foreground">{t("review.ignored")}</span>
                )}
              </div>

              {isEditing && !state && (
                <div className="mt-2 flex gap-2">
                  <Input
                    value={edits[item.block.id] ?? ""}
                    onChange={(e) => setEdits((prev) => ({ ...prev, [item.block.id]: e.target.value }))}
                    dir={isRtl(item.block.language) ? "rtl" : "ltr"}
                    placeholder={t("review.placeholder")}
                    onKeyDown={(e) => e.key === "Enter" && save(item)}
                  />
                  <Button size="sm" disabled={savingId === item.block.id} onClick={() => save(item)}>
                    {t("common.save")}
                  </Button>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
