"use client";

import type { RegionOut } from "@/lib/types";

/**
 * Absolutely-positioned Selective-OCR region rectangles rendered over a page
 * image/canvas. Regions are normalized (0–1); multiplying by the on-screen
 * `renderWidth/renderHeight` gives pixel position — the same scale mapping
 * BBoxOverlay applies to OCR pixel bboxes (imageWidth=1 in normalized space).
 */
export function RegionOverlay({
  regions,
  renderWidth,
  renderHeight,
}: {
  regions: RegionOut[];
  renderWidth: number;
  renderHeight: number;
}) {
  if (!renderWidth || !renderHeight) return null;

  return (
    <div className="pointer-events-none absolute inset-0">
      {regions.map((r) => (
        <div
          key={`${r.page_number}:${r.label}`}
          className="pointer-events-none absolute border-2 border-dashed border-cyan-400 bg-cyan-400/10"
          style={{
            left: r.x * renderWidth,
            top: r.y * renderHeight,
            width: Math.max(r.width * renderWidth, 2),
            height: Math.max(r.height * renderHeight, 2),
          }}
        >
          <span className="absolute left-0 top-0 -translate-y-full rounded-sm bg-cyan-400 px-1 text-[10px] font-bold leading-4 text-cyan-950">
            {r.label}
          </span>
        </div>
      ))}
    </div>
  );
}