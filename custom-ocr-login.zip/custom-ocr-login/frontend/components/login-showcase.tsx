"use client";

import Image from "next/image";
import { Braces, FileText, Languages, ScanText, Table2, WifiOff } from "lucide-react";

import uaeEmblem from "@/assets/uae-emblem.png";

import { useI18n, type TranslationKey } from "@/lib/i18n";
import { cn } from "@/lib/utils";

/**
 * Full-screen decorative login backdrop: a sample Arabic government
 * certificate (clearly watermarked as a SAMPLE) is scanned and its fields
 * stream across the screen — behind the centered login card — into a
 * structured result. Delays are seconds within the 7s cycle in globals.css;
 * each matches the moment the scan beam crosses that line of the document.
 */
const FIELDS: { label: TranslationKey; docLabel: string; value: string; conf: number; top: string; delay: number }[] = [
  { label: "login.demo.reference", docLabel: "رقم المرجع", value: "2026/4172", conf: 99, top: "33%", delay: 1.1 },
  { label: "login.demo.name", docLabel: "الاسم", value: "محمد أحمد عبدالله", conf: 97, top: "41%", delay: 1.4 },
  { label: "login.demo.emirate", docLabel: "الإمارة", value: "دبي", conf: 98, top: "49%", delay: 1.7 },
  { label: "login.demo.issue_date", docLabel: "تاريخ الإصدار", value: "15/10/2026", conf: 99, top: "57%", delay: 2.0 },
];

const FILE_BADGES = [
  { text: "PDF", className: "start-[6%] top-[16%] bg-red-500/80", r: "-8deg", delay: "0s" },
  { text: "JPG", className: "end-[9%] top-[13%] bg-amber-500/80", r: "6deg", delay: "1.5s" },
  { text: "PNG", className: "start-[30%] bottom-[10%] bg-emerald-500/80", r: "4deg", delay: "3s" },
  { text: "TIFF", className: "end-[26%] bottom-[14%] bg-sky-500/80", r: "-5deg", delay: "4.5s" },
  { text: "DOCX", className: "start-[36%] top-[9%] bg-indigo-500/80", r: "3deg", delay: "6s" },
];

const FEATURES = [
  { icon: Languages, key: "login.hero.f1" },
  { icon: WifiOff, key: "login.hero.f2" },
  { icon: Table2, key: "login.hero.f3" },
  { icon: FileText, key: "login.hero.f4" },
] as const;

export function LoginBackdrop() {
  const { t } = useI18n();

  return (
    <div
      aria-hidden
      className="fixed inset-0 overflow-hidden bg-gradient-to-br from-slate-900 via-blue-950 to-indigo-950 text-white"
    >
      {/* Grid + glows */}
      <div
        className="absolute inset-0 opacity-60"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,255,255,0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.05) 1px, transparent 1px)",
          backgroundSize: "32px 32px",
        }}
      />
      <div className="login-glow absolute -start-24 top-10 h-96 w-96 rounded-full bg-blue-500/30 blur-3xl" />
      <div
        className="login-glow absolute -end-16 bottom-10 h-[28rem] w-[28rem] rounded-full bg-indigo-500/30 blur-3xl"
        style={{ animationDelay: "4s" }}
      />

      {/* Brand */}
      <div className="absolute start-8 top-7 flex items-center gap-2">
        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-white/10 ring-1 ring-white/20">
          <ScanText className="h-5 w-5" />
        </div>
        <div>
          <p className="text-sm font-bold leading-none">{t("app.name")}</p>
          <p className="text-xs text-white/60">{t("app.tagline_full")}</p>
        </div>
      </div>

      {FILE_BADGES.map((b) => (
        <span
          key={b.text}
          className={cn(
            "login-float absolute rounded-md px-2 py-1 text-[10px] font-bold tracking-wider shadow-lg",
            b.className
          )}
          style={{ animationDelay: b.delay, ["--r" as string]: b.r }}
        >
          {b.text}
        </span>
      ))}

      {/* Stage (wide screens): document → data stream behind the card → result */}
      <div className="absolute start-[7%] top-1/2 hidden -translate-y-1/2 xl:block">
        <SampleCertificate />
      </div>

      <div className="absolute end-[7%] top-1/2 hidden -translate-y-1/2 xl:block">
        <ResultCard />
      </div>

      <div className="absolute end-[calc(7%+16rem)] start-[calc(7%+16.5rem)] top-1/2 hidden h-6 -translate-y-1/2 xl:block rtl:-scale-x-100">
        <div className="absolute inset-x-0 top-1/2 h-px -translate-y-1/2 bg-gradient-to-r from-sky-400/0 via-sky-400/40 to-sky-400/0" />
        {[0, 0.5, 1, 1.5, 2, 2.5].map((d) => (
          <div key={d} className="login-stream absolute inset-0" style={{ animationDelay: `${d}s` }}>
            <span className="absolute start-0 top-1/2 h-1.5 w-1.5 -translate-y-1/2 rounded-full bg-sky-300 shadow-[0_0_10px_3px_rgba(125,211,252,0.7)]" />
          </div>
        ))}
      </div>

      {/* Pitch */}
      <div className="absolute bottom-8 start-8 hidden max-w-sm space-y-3 xl:block [@media(max-height:820px)]:hidden">
        <h2 className="text-2xl font-bold leading-tight tracking-tight">{t("login.hero.title")}</h2>
        <p className="text-sm text-white/65">{t("login.hero.subtitle")}</p>
        <div className="flex flex-wrap gap-2">
          {FEATURES.map(({ icon: Icon, key }) => (
            <span
              key={key}
              className="flex items-center gap-1.5 rounded-full bg-white/10 px-3 py-1 text-xs text-white/85 ring-1 ring-white/15"
            >
              <Icon className="h-3.5 w-3.5" />
              {t(key)}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

/** Sample Arabic government certificate (UAE emblem), watermarked as a sample. */
function SampleCertificate() {
  return (
    <div
      dir="rtl"
      lang="ar"
      translate="no"
      className="notranslate relative h-[22rem] w-64 -rotate-3 overflow-hidden rounded-xl bg-white text-slate-800 shadow-2xl shadow-black/40"
    >
      {/* Flag-colour band (red bar at the hoist side, as on the flag) */}
      <div dir="ltr" className="flex h-1.5">
        <div className="w-1/4 bg-red-600" />
        <div className="flex flex-1 flex-col">
          <div className="flex-1 bg-green-700" />
          <div className="flex-1 bg-slate-100" />
          <div className="flex-1 bg-black" />
        </div>
      </div>

      <div className="px-5 pt-4">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-[13px] font-bold text-slate-900">الإمارات العربية المتحدة</p>
            <p className="text-[9px] text-slate-500">وثيقة حكومية نموذجية</p>
          </div>
          <Image src={uaeEmblem} alt="" width={40} height={45} className="h-11 w-auto" unoptimized priority />
        </div>
        <p className="mt-3 border-b border-slate-200 pb-1.5 text-center text-sm font-extrabold text-slate-900">
          شهادة تسجيل
        </p>
      </div>

      {FIELDS.map((f) => (
        <div key={f.label} className="absolute inset-x-5 flex items-center gap-2 text-[11px]" style={{ top: f.top }}>
          <span className="text-slate-500">{f.docLabel}:</span>
          <span className="relative px-1 font-semibold text-slate-900">
            {f.value}
            <span
              className="login-box absolute -inset-1 rounded border-2 border-blue-500 bg-blue-500/10"
              style={{ animationDelay: `${f.delay}s` }}
            />
          </span>
        </div>
      ))}

      {/* Body text (filler) */}
      <div className="absolute inset-x-5 top-[66%] space-y-1.5">
        {[1, 0.85, 0.92, 0.6].map((w, i) => (
          <div key={i} className="h-1.5 rounded bg-slate-200" style={{ width: `${w * 100}%` }} />
        ))}
      </div>

      {/* Signature + stamp */}
      <div className="absolute inset-x-5 bottom-4 flex items-end justify-between">
        <svg viewBox="0 0 80 24" className="h-6 w-20 text-slate-600" fill="none" stroke="currentColor" strokeWidth="1.5">
          <path d="M2 18c8-14 12 4 18-6s6 10 12 2 8-8 12 0 10-6 14-2 8 4 18-4" strokeLinecap="round" />
        </svg>
        <div className="flex h-11 w-11 -rotate-12 items-center justify-center rounded-full border-2 border-red-500/60 text-[9px] font-bold text-red-500/70">
          نموذج
        </div>
      </div>

      {/* Sample watermark */}
      <p className="pointer-events-none absolute inset-0 flex -rotate-[30deg] items-center justify-center whitespace-nowrap text-3xl font-black tracking-widest text-slate-900/[0.06]">
        نموذج · SAMPLE
      </p>

      {/* Scan beam (full-height track: translateY % = % of the page) */}
      <div className="login-scan pointer-events-none absolute inset-0">
        <div className="absolute inset-x-0 top-0 h-0.5 bg-blue-500 shadow-[0_0_18px_6px_rgba(59,130,246,0.55)]">
          <div className="absolute inset-x-0 bottom-0 h-10 bg-gradient-to-t from-blue-500/25 to-transparent" />
        </div>
      </div>
    </div>
  );
}

function ResultCard() {
  const { t } = useI18n();
  return (
    <div className="w-64 rounded-xl border border-white/15 bg-white/10 p-4 shadow-2xl shadow-black/30 backdrop-blur-md">
      <div className="mb-3 flex items-center justify-between">
        <p className="flex items-center gap-1.5 text-xs font-semibold">
          <Braces className="h-3.5 w-3.5 text-sky-300" />
          {t("login.demo.extracted")}
        </p>
        <span className="rounded bg-white/10 px-1.5 py-0.5 font-mono text-[9px] text-white/70">JSON</span>
      </div>
      <div className="space-y-2">
        {FIELDS.map((f) => (
          <div
            key={f.label}
            className="login-field flex items-center justify-between gap-2 rounded-lg bg-white/5 px-2.5 py-1.5 ring-1 ring-white/10"
            style={{ animationDelay: `${f.delay + 0.6}s` }}
          >
            <div className="min-w-0">
              <p className="text-[10px] text-white/55">{t(f.label)}</p>
              <p className="truncate text-xs font-medium">
                <bdi translate="no" className="notranslate">
                  {f.value}
                </bdi>
              </p>
            </div>
            <span className="shrink-0 rounded-full bg-emerald-400/15 px-1.5 py-0.5 text-[10px] font-semibold text-emerald-300">
              {f.conf}%
            </span>
          </div>
        ))}
      </div>
      <div className="mt-3 h-1 overflow-hidden rounded-full bg-white/10">
        <div className="login-progress h-full w-full origin-left rounded-full bg-gradient-to-r from-sky-400 to-emerald-400 rtl:origin-right" />
      </div>
    </div>
  );
}

/** Compact animated mark shown at the top of the login card. */
export function LoginMark() {
  return (
    <div className="relative flex h-14 w-14 items-center justify-center overflow-hidden rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-700 text-white shadow-lg shadow-blue-500/30">
      <ScanText className="h-7 w-7" />
      <span className="login-scan-mini absolute inset-x-1 h-0.5 rounded bg-sky-300 shadow-[0_0_8px_2px_rgba(125,211,252,0.8)]" />
    </div>
  );
}
