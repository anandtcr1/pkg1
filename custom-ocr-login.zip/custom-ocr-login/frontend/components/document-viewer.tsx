"use client";

import { useEffect, useRef, useState } from "react";
import { ChevronLeft, ChevronRight, ZoomIn, ZoomOut } from "lucide-react";

import { authUrl, originalFileUrl } from "@/lib/api";
import { useI18n } from "@/lib/i18n";
import type { JobDetail, OCRPage, RegionOut } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { BBoxOverlay } from "@/components/bbox-overlay";
import { RegionOverlay } from "@/components/region-overlay";

/**
 * Document preview with synced bounding-box overlay.
 * PDFs render via PDF.js (canvas); plain images use the processed page PNG
 * served by the backend (same pixel space as the OCR bboxes).
 * `regionOverlays` shows Selective-OCR regions (normalized 0–1) per page when
 * `showRegionOverlays` is enabled — both optional, so jobs without regions or
 * callers that don't pass them render exactly as before.
 */
export function DocumentViewer({
  job,
  hoveredBlockId,
  onHoverBlock,
  regionOverlays,
  showRegionOverlays = true,
}: {
  job: JobDetail;
  hoveredBlockId: string | null;
  onHoverBlock: (id: string | null) => void;
  regionOverlays?: RegionOut[];
  showRegionOverlays?: boolean;
}) {
  const { t } = useI18n();
  const [pageIndex, setPageIndex] = useState(0);
  const [zoom, setZoom] = useState(1);
  const pages = job.pages;
  const page: OCRPage | undefined = pages[pageIndex];

  const isPdf = job.mime_type === "application/pdf";

  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center justify-between gap-2 border-b px-3 py-2">
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            disabled={pageIndex === 0}
            onClick={() => setPageIndex((i) => Math.max(0, i - 1))}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <span className="text-sm text-muted-foreground">
            {t("result.page_of", { current: pageIndex + 1, total: Math.max(pages.length, 1) })}
          </span>
          <Button
            variant="ghost"
            size="icon"
            disabled={pageIndex >= pages.length - 1}
            onClick={() => setPageIndex((i) => Math.min(pages.length - 1, i + 1))}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon" onClick={() => setZoom((z) => Math.max(0.5, z - 0.25))}>
            <ZoomOut className="h-4 w-4" />
          </Button>
          <span className="w-12 text-center text-xs text-muted-foreground">{Math.round(zoom * 100)}%</span>
          <Button variant="ghost" size="icon" onClick={() => setZoom((z) => Math.min(3, z + 0.25))}>
            <ZoomIn className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="scrollbar-thin flex-1 overflow-auto bg-muted/30 p-4">
        {page ? (
          isPdf ? (
            <PdfPage
              key={job.id}
              pdfUrl={originalFileUrl(job.id)}
              page={page}
              zoom={zoom}
              hoveredBlockId={hoveredBlockId}
              onHoverBlock={onHoverBlock}
              regionOverlays={regionOverlays}
              showRegionOverlays={showRegionOverlays}
            />
          ) : (
            <ImagePage
              page={page}
              zoom={zoom}
              hoveredBlockId={hoveredBlockId}
              onHoverBlock={onHoverBlock}
              regionOverlays={regionOverlays}
              showRegionOverlays={showRegionOverlays}
            />
          )
        ) : (
          <Skeleton className="mx-auto h-[600px] w-full max-w-[500px]" />
        )}
      </div>
    </div>
  );
}

function ImagePage({
  page,
  zoom,
  hoveredBlockId,
  onHoverBlock,
  regionOverlays,
  showRegionOverlays,
}: {
  page: OCRPage;
  zoom: number;
  hoveredBlockId: string | null;
  onHoverBlock: (id: string | null) => void;
  regionOverlays?: RegionOut[];
  showRegionOverlays: boolean;
}) {
  const [size, setSize] = useState<{ w: number; h: number } | null>(null);
  const baseWidth = page.width ?? 800;
  const renderWidth = baseWidth * zoom * 0.6;

  return (
    <div className="mx-auto w-fit">
      <div className="relative inline-block rounded-md bg-white shadow-md">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={page.image_url ? authUrl(page.image_url) : ""}
          alt={`Page ${page.page_number}`}
          className="block rounded-md"
          style={{ width: renderWidth }}
          onLoad={(e) => {
            const el = e.currentTarget;
            setSize({ w: el.clientWidth, h: el.clientHeight });
          }}
        />
        {size && (
          <BBoxOverlay
            blocks={page.blocks}
            imageWidth={page.width ?? size.w}
            imageHeight={page.height ?? size.h}
            renderWidth={size.w}
            renderHeight={size.h}
            hoveredId={hoveredBlockId}
            onHover={onHoverBlock}
          />
        )}
        {showRegionOverlays && size && (
          <RegionOverlay
            regions={regionOverlays?.filter((r) => r.page_number === page.page_number) ?? []}
            renderWidth={size.w}
            renderHeight={size.h}
          />
        )}
      </div>
    </div>
  );
}

function PdfPage({
  pdfUrl,
  page,
  zoom,
  hoveredBlockId,
  onHoverBlock,
  regionOverlays,
  showRegionOverlays,
}: {
  pdfUrl: string;
  page: OCRPage;
  zoom: number;
  hoveredBlockId: string | null;
  onHoverBlock: (id: string | null) => void;
  regionOverlays?: RegionOut[];
  showRegionOverlays: boolean;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [size, setSize] = useState<{ w: number; h: number } | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    (async () => {
      try {
        const pdfjs = await import("pdfjs-dist");
        pdfjs.GlobalWorkerOptions.workerSrc = new URL(
          "pdfjs-dist/build/pdf.worker.min.mjs",
          import.meta.url
        ).toString();

        const doc = await pdfjs.getDocument(pdfUrl).promise;
        const pdfPage = await doc.getPage(page.page_number);
        // Render so the canvas width matches the OCR image width → 1:1 bbox space.
        const targetWidth = (page.width ?? 1200) * zoom * 0.6;
        const baseViewport = pdfPage.getViewport({ scale: 1 });
        const scale = targetWidth / baseViewport.width;
        const viewport = pdfPage.getViewport({ scale });

        const canvas = canvasRef.current;
        if (!canvas || cancelled) return;
        canvas.width = viewport.width;
        canvas.height = viewport.height;
        const ctx = canvas.getContext("2d");
        if (!ctx) return;
        await pdfPage.render({ canvasContext: ctx, viewport }).promise;
        if (!cancelled) setSize({ w: viewport.width, h: viewport.height });
      } catch (err) {
        if (!cancelled) setError(err instanceof Error ? err.message : "PDF render failed");
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [pdfUrl, page.page_number, page.width, zoom]);

  if (error) {
    // Graceful fallback: the processed page image still shows bboxes correctly.
    return (
      <ImagePage
        page={page}
        zoom={zoom}
        hoveredBlockId={hoveredBlockId}
        onHoverBlock={onHoverBlock}
        regionOverlays={regionOverlays}
        showRegionOverlays={showRegionOverlays}
      />
    );
  }

  const scaleX = size && page.width ? size.w / page.width : 1;
  const scaleY = size && page.height ? size.h / page.height : 1;

  return (
    <div className="mx-auto w-fit">
      <div className="relative inline-block rounded-md bg-white shadow-md">
        <canvas ref={canvasRef} className="block rounded-md" />
        {size && (
          <BBoxOverlay
            blocks={page.blocks}
            imageWidth={page.width ?? size.w}
            imageHeight={page.height ?? size.h}
            renderWidth={(page.width ?? size.w) * scaleX}
            renderHeight={(page.height ?? size.h) * scaleY}
            hoveredId={hoveredBlockId}
            onHover={onHoverBlock}
          />
        )}
        {showRegionOverlays && size && (
          <RegionOverlay
            regions={regionOverlays?.filter((r) => r.page_number === page.page_number) ?? []}
            renderWidth={size.w}
            renderHeight={size.h}
          />
        )}
      </div>
    </div>
  );
}
