"use client";

import { useEffect, useRef, useState } from "react";

/** Poll an async fn until `stop(result)` returns true (or unmount). */
export function usePoll<T>(
  fetcher: () => Promise<T>,
  stop: (value: T) => boolean,
  intervalMs = 2000,
  deps: unknown[] = []
) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    let cancelled = false;

    const tick = async () => {
      try {
        const value = await fetcher();
        if (cancelled) return;
        setData(value);
        setError(null);
        if (stop(value) && timer.current) {
          clearInterval(timer.current);
          timer.current = null;
        }
      } catch (err) {
        if (!cancelled) setError(err instanceof Error ? err.message : "Request failed");
      }
    };

    tick();
    timer.current = setInterval(tick, intervalMs);
    return () => {
      cancelled = true;
      if (timer.current) clearInterval(timer.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [intervalMs, ...deps]);

  return { data, error };
}
