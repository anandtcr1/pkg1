# Deploying the Frontend on Windows IIS

The frontend (Next.js 15) is built as a **static site**. `npm run build` writes plain
HTML/JS/CSS to `frontend\out\`, and IIS serves those files directly. Node.js is only
needed on the machine that runs the build, not on the IIS server. No ARR, URL Rewrite or
NSSM is required.

---

## 1. Prerequisites

**Build machine**
- Node.js 20 LTS
- Run `npm ci` once inside `frontend\` to install dependencies

**IIS server**
- IIS with the **Static Content** feature
  (Windows Features → Internet Information Services → World Wide Web Services →
  Common HTTP Features → Static Content)
- The backend API reachable from users' browsers (e.g. `http://<server>:8000`)

---

## 2. Build

Run in **PowerShell or cmd, not Git Bash**. Git Bash rewrites `/ocr` into
`C:/Program Files/Git/ocr`, and the build fails.

```powershell
cd D:\work\ai\OCR\custom-ocr\frontend

# URL the *browser* uses to reach the backend (not localhost, unless users browse on the server)
$env:NEXT_PUBLIC_API_URL = "http://<your-server>:8000"

# Only if the app is an IIS Application under a sub-path, e.g. http://server/ocr/
# Must match the IIS application alias. Leave unset if the app is the root of its own site.
$env:BASE_PATH = "/ocr"

$env:NEXT_TELEMETRY_DISABLED = "1"
npm run build
```

The output is `frontend\out\`.

> Both `NEXT_PUBLIC_API_URL` and `BASE_PATH` are fixed into the files at build time.
> If either one changes, rebuild and redeploy.

---

## 3. Deploy to IIS

1. Copy **everything inside** `out\` to the IIS folder, e.g. `C:\inetpub\ocr-frontend`.
   Use robocopy or Explorer. Some zip and copy tools skip the `_next` folder because its
   name starts with an underscore.
   ```powershell
   robocopy D:\work\ai\OCR\custom-ocr\frontend\out C:\inetpub\ocr-frontend /MIR
   ```
2. In IIS Manager, do **one** of the following:
   - **Own site** (`http://server/`): Sites → **Add Website** → physical path
     `C:\inetpub\ocr-frontend`. Build *without* `BASE_PATH`.
   - **Sub-path** (`http://server/ocr/`): Default Web Site → **Add Application** →
     alias `ocr`, physical path `C:\inetpub\ocr-frontend`. Build *with* `BASE_PATH=/ocr`.
3. Browse to the site.

`web.config` is included automatically, because it is copied from `public\web.config`. It:
- registers the `.mjs` MIME type, which the PDF viewer's pdf.js worker needs. IIS
  returns 404.3 for `.mjs` files without it.
- sets `index.html` as the default document.

---

## 4. Backend settings

Because the browser calls the backend directly:
- Set the backend's `CORS_ORIGINS` to the IIS site address (origin only, no path),
  e.g. `CORS_ORIGINS=http://<your-server>`. Separate multiple origins with commas.
- Open the backend port (e.g. 8000) in Windows Firewall.
- The backend must be running and reachable at the URL used for `NEXT_PUBLIC_API_URL`.

---

## 5. Updating

1. Pull the code changes.
2. Rebuild (step 2).
3. Re-copy with `robocopy ... /MIR`, which also removes stale files.
4. Hard-refresh the browser (Ctrl+F5).

---

## 6. Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| Console shows 404 for `/_next/static/...js` and `.css`, and the page is unstyled or blank | App is under a sub-path but was built without `BASE_PATH` | Rebuild with `$env:BASE_PATH="/<alias>"` |
| Same 404s, and the app is the root of its own site | `_next` folder not copied | Check that `C:\inetpub\ocr-frontend\_next\static\chunks\` exists and contains files |
| PDF preview doesn't render; 404.3 for `pdf.worker...mjs` | `.mjs` MIME type missing | Make sure `web.config` is in the site folder |
| "Failed to fetch" or CORS errors when calling the API | Wrong `NEXT_PUBLIC_API_URL`, or backend `CORS_ORIGINS` doesn't include the site | Fix the URL and rebuild, or update `CORS_ORIGINS` and restart the backend |
| `Specified basePath has to start with a /, found "C:/Program Files/Git/..."` | Build was run in Git Bash | Build in PowerShell or cmd |
| `contentscript.js` / `ObjectMultiplex` warnings | Browser extension (e.g. MetaMask) | Ignore |

---

## 7. Code changes made for static export

Next.js can't statically export a dynamic route such as `/ocr/[jobId]`, because job IDs
only exist once the app is running. These changes were made so the app builds as static
files:

| File | Change |
|---|---|
| `next.config.ts` | `output: "export"` (was `"standalone"`), `trailingSlash: true`, `images.unoptimized`, `basePath` read from the `BASE_PATH` env var |
| `app/(app)/ocr/[jobId]/page.tsx` → `app/(app)/ocr/job/page.tsx` | Job detail page moved; reads the ID from `?id=` with `useSearchParams()`, wrapped in `<Suspense>` |
| `app/(app)/documents/page.tsx` (line 118) | Link changed to `/ocr/job?id=...` |
| `app/(app)/ocr/page.tsx` (lines 201, 290) | Navigation changed to `/ocr/job?id=...` |
| `components/jobs-table.tsx` (lines 50, 138) | Navigation changed to `/ocr/job?id=...` |
| `public/web.config` (new) | IIS `.mjs` MIME type and default document |

**Effect:** job detail URLs changed from `/ocr/<id>` to `/ocr/job?id=<id>`, so old
bookmarks to job pages no longer work.

**Known gap:** `frontend/Dockerfile` still copies `.next/standalone`, which is no longer
produced, so the Docker / docker-compose frontend build is broken. To use Docker again,
serve `out/` from a static web server image (e.g. nginx).
