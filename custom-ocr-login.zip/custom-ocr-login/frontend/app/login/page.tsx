"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Eye, EyeOff, Loader2, Lock, LogIn, MonitorSmartphone, ShieldCheck, User } from "lucide-react";
import { toast } from "sonner";

import { getAuthMe, getStoredToken, login, setStoredToken, windowsLogin } from "@/lib/api";
import { useI18n } from "@/lib/i18n";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { LanguageSwitcher } from "@/components/language-switcher";
import { LoginBackdrop, LoginMark } from "@/components/login-showcase";
import { ThemeToggle } from "@/components/theme-toggle";

export default function LoginPage() {
  const { t } = useI18n();
  const router = useRouter();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [authDisabled, setAuthDisabled] = useState(false);

  // Already signed in -> go to dashboard. Otherwise show the auth mode note.
  useEffect(() => {
    let cancelled = false;
    getAuthMe()
      .then((me) => {
        if (cancelled) return;
        if (me.setup_required) {
          router.replace("/setup");
          return;
        }
        if (me.authenticated && me.kind === "user") router.replace("/");
        setAuthDisabled(!me.auth_required);
      })
      .catch(() => setAuthDisabled(false));
    return () => {
      cancelled = true;
    };
  }, [router]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (busy) return;
    setBusy(true);
    try {
      const res = await login(username.trim(), password);
      setStoredToken(res.access_token);
      toast.success(`${t("auth.success")} — ${res.username}`);
      router.replace("/");
      router.refresh();
    } catch (err) {
      const message = err instanceof Error ? err.message : "";
      if (message.includes("disabled")) toast.error(t("auth.disabled"));
      else if (message.includes("Active Directory")) toast.error(t("auth.unavailable"));
      else toast.error(t("auth.error"));
    } finally {
      setBusy(false);
    }
  }

  async function onWindows() {
    if (busy) return;
    setBusy(true);
    try {
      const res = await windowsLogin();
      if (!res) {
        toast.error(t("auth.windows_failed"));
        return;
      }
      setStoredToken(res.access_token);
      toast.success(`${t("auth.success")} — ${res.display_name || res.username}`);
      router.replace("/");
      router.refresh();
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="relative flex min-h-screen flex-col">
      <LoginBackdrop />

      <div className="relative z-10 flex justify-end p-4">
        <div className="flex items-center gap-1 rounded-xl bg-card/90 p-1 shadow-lg backdrop-blur">
          <LanguageSwitcher compact />
          <ThemeToggle />
        </div>
      </div>

      <main className="relative z-10 flex flex-1 items-center justify-center px-4 pb-16">
        <div className="w-full max-w-sm rounded-2xl border bg-card p-8 shadow-2xl shadow-black/40 animate-in fade-in zoom-in-95 slide-in-from-bottom-4 duration-700 motion-reduce:animate-none">
          <div className="mb-7 flex flex-col items-center text-center">
            <div className="mb-4">
              <LoginMark />
            </div>
            <h1 className="text-2xl font-bold tracking-tight">{t("auth.welcome")}</h1>
            <p className="mt-1 text-sm text-muted-foreground">{t("auth.subtitle")}</p>
          </div>

          {getStoredToken() === null && authDisabled && (
            <p className="mb-4 rounded-md bg-muted px-3 py-2 text-center text-xs text-muted-foreground">
              {t("auth.no_auth_note")}
            </p>
          )}

          <form onSubmit={onSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username">{t("auth.username")}</Label>
              <div className="relative">
                <User className="pointer-events-none absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  autoComplete="username"
                  autoFocus
                  required
                  dir="ltr"
                  className="h-11 ps-9"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">{t("auth.password")}</Label>
              <div className="relative">
                <Lock className="pointer-events-none absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  autoComplete="current-password"
                  required
                  dir="ltr"
                  className="h-11 pe-10 ps-9"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  className="absolute end-1 top-1/2 flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-md text-muted-foreground transition-colors hover:text-foreground"
                  aria-label={showPassword ? t("auth.hide_password") : t("auth.show_password")}
                  title={showPassword ? t("auth.hide_password") : t("auth.show_password")}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>
            <Button type="submit" className="h-11 w-full shadow-lg shadow-primary/20" disabled={busy}>
              {busy ? <Loader2 className="me-2 h-4 w-4 animate-spin" /> : <LogIn className="me-2 h-4 w-4" />}
              <span>{busy ? t("auth.submitting") : t("auth.submit")}</span>
            </Button>
          </form>

          <div className="my-5 flex items-center gap-3 text-xs text-muted-foreground">
            <div className="h-px flex-1 bg-border" />
            {t("auth.or")}
            <div className="h-px flex-1 bg-border" />
          </div>
          <Button type="button" variant="outline" className="h-11 w-full" disabled={busy} onClick={onWindows}>
            <MonitorSmartphone className="me-2 h-4 w-4" />
            {t("auth.windows")}
          </Button>

          <p className="mt-7 flex items-center justify-center gap-1.5 text-xs text-muted-foreground">
            <ShieldCheck className="h-3.5 w-3.5" />
            {t("auth.footer")}
          </p>
        </div>
      </main>
    </div>
  );
}
