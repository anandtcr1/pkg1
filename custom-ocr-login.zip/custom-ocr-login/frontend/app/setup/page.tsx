"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Eye, EyeOff, Info, Loader2, Lock, ShieldPlus, User } from "lucide-react";
import { toast } from "sonner";

import { createFirstAdmin, getSetupStatus, login, setStoredToken } from "@/lib/api";
import { useI18n } from "@/lib/i18n";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { LanguageSwitcher } from "@/components/language-switcher";
import { LoginBackdrop, LoginMark } from "@/components/login-showcase";
import { ThemeToggle } from "@/components/theme-toggle";

const USERNAME_RE = /^[A-Za-z0-9._-]{3,64}$/;
const MIN_PASSWORD_LENGTH = 6;

/** First-run screen: shown only while no users exist; creates the first local administrator. */
export default function SetupPage() {
  const { t } = useI18n();
  const router = useRouter();
  const [ready, setReady] = useState(false);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Setup already done (users exist) -> this screen is not available.
  useEffect(() => {
    let cancelled = false;
    getSetupStatus()
      .then((s) => {
        if (cancelled) return;
        if (!s.setup_required) router.replace("/login");
        else setReady(true);
      })
      .catch(() => {
        if (!cancelled) setReady(true); // backend unreachable: let the submit report the error
      });
    return () => {
      cancelled = true;
    };
  }, [router]);

  function validate(): string | null {
    if (!USERNAME_RE.test(username.trim())) return t("setup.invalid_username");
    if (password.length < MIN_PASSWORD_LENGTH) return t("setup.too_short");
    if (password !== confirm) return t("setup.mismatch");
    return null;
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (busy) return;
    const problem = validate();
    setError(problem);
    if (problem) return;

    setBusy(true);
    try {
      const name = username.trim();
      await createFirstAdmin(name, password);
      // Sign in with the new account straight away (proves the credentials work).
      const session = await login(name, password);
      setStoredToken(session.access_token);
      toast.success(`${t("setup.success")} — ${session.username}`);
      router.replace("/");
      router.refresh();
    } catch (err) {
      const message = err instanceof Error ? err.message : t("setup.failed");
      setError(message);
      toast.error(t("setup.failed"));
      // Someone else completed setup meanwhile -> go to the normal login.
      if (message.includes("already been completed")) router.replace("/login");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="relative flex min-h-screen flex-col">
      <LoginBackdrop />

      <div className="relative z-10 flex justify-end p-4">
        <div className="flex items-center gap-1 rounded-xl bg-card/90 p-1 shadow-lg backdrop-blur">
          <LanguageSwitcher compact />
          <ThemeToggle />
        </div>
      </div>

      <main className="relative z-10 flex flex-1 items-center justify-center px-4 pb-16">
        <div className="w-full max-w-sm rounded-2xl border bg-card p-8 shadow-2xl shadow-black/40 animate-in fade-in zoom-in-95 slide-in-from-bottom-4 duration-700 motion-reduce:animate-none">
          <div className="mb-6 flex flex-col items-center text-center">
            <div className="mb-4">
              <LoginMark />
            </div>
            <h1 className="text-2xl font-bold tracking-tight">{t("setup.title")}</h1>
            <p className="mt-1 text-sm text-muted-foreground">{t("setup.subtitle")}</p>
          </div>

          {!ready ? (
            <div className="flex justify-center py-10">
              <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
            </div>
          ) : (
            <form onSubmit={onSubmit} className="space-y-4" noValidate>
              <div className="space-y-2">
                <Label htmlFor="setup-username">{t("setup.username")}</Label>
                <div className="relative">
                  <User className="pointer-events-none absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    id="setup-username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    autoComplete="username"
                    autoFocus
                    required
                    dir="ltr"
                    className="h-11 ps-9"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="setup-password">{t("setup.password")}</Label>
                <div className="relative">
                  <Lock className="pointer-events-none absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    id="setup-password"
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    autoComplete="new-password"
                    required
                    dir="ltr"
                    className="h-11 pe-10 ps-9"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((v) => !v)}
                    className="absolute end-1 top-1/2 flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-md text-muted-foreground transition-colors hover:text-foreground"
                    aria-label={showPassword ? t("auth.hide_password") : t("auth.show_password")}
                    title={showPassword ? t("auth.hide_password") : t("auth.show_password")}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="setup-confirm">{t("setup.confirm")}</Label>
                <div className="relative">
                  <Lock className="pointer-events-none absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    id="setup-confirm"
                    type={showPassword ? "text" : "password"}
                    value={confirm}
                    onChange={(e) => setConfirm(e.target.value)}
                    autoComplete="new-password"
                    required
                    dir="ltr"
                    className="h-11 ps-9"
                    aria-invalid={confirm.length > 0 && confirm !== password}
                  />
                </div>
              </div>

              {error && (
                <p role="alert" className="rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">
                  {error}
                </p>
              )}

              <Button type="submit" className="h-11 w-full shadow-lg shadow-primary/20" disabled={busy}>
                {busy ? <Loader2 className="me-2 h-4 w-4 animate-spin" /> : <ShieldPlus className="me-2 h-4 w-4" />}
                <span>{busy ? t("setup.submitting") : t("setup.submit")}</span>
              </Button>

              <p className="flex gap-2 text-xs text-muted-foreground">
                <Info className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                {t("setup.note")}
              </p>
            </form>
          )}
        </div>
      </main>
    </div>
  );
}
