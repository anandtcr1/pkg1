"use client";

import { useEffect, useMemo, useState } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { FileText, Files, Gauge, PenLine, Timer } from "lucide-react";

import { getEnginePerformance, getStatsCharts, getStatsOverview, getSystemInfo, listEngines } from "@/lib/api";
import { useI18n } from "@/lib/i18n";
import type { EnginePerformance, EngineInfo, StatsCharts, StatsOverview, SystemInfo } from "@/lib/types";
import { formatPercent, formatSeconds, engineDisplayName } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

const PIE_COLORS = ["#3b82f6", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6", "#06b6d4"];

type Lang = "en" | "ar";

function dayLabel(value: string, lang: Lang): string {
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return value;
  return d.toLocaleDateString(lang === "ar" ? "ar" : "en-US", { day: "numeric", month: "short" });
}

function engineLabel(name: string): string {
  return engineDisplayName(name);
}

function TipContainer({ children }: { children: React.ReactNode }) {
  return <div className="rounded-lg border bg-background px-3 py-2 text-xs text-foreground shadow-md">{children}</div>;
}

interface TipProps {
  active?: boolean;
  label?: string | number;
  payload?: ReadonlyArray<{ name?: string; value?: number | string; payload?: Record<string, unknown> }>;
}

function RequestsTip({ active, payload, label }: TipProps) {
  const { t, lang } = useI18n();
  if (!active || !payload?.length) return null;
  return (
    <TipContainer>
      <p className="font-semibold">{dayLabel(String(label ?? ""), lang)}</p>
      <p>
        {t("analytics.tip.requests")}: <span className="font-semibold">{String(payload[0].value)}</span>
      </p>
    </TipContainer>
  );
}

function ConfidenceTip({ active, payload, label }: TipProps) {
  const { t, lang } = useI18n();
  if (!active || !payload?.length) return null;
  const datum = payload[0].payload ?? {};
  const confidence = datum.confidence as number | undefined;
  const documents = datum.documents as number | undefined;
  return (
    <TipContainer>
      <p className="font-semibold">{dayLabel(String(label ?? ""), lang)}</p>
      <p>
        {t("analytics.tip.avg_confidence")}: <span className="font-semibold">{formatPercent(confidence)}</span>
      </p>
      <p>
        {t("analytics.tip.documents")}: <span className="font-semibold">{documents ?? "—"}</span>
      </p>
    </TipContainer>
  );
}

function CategoryTip({ active, payload, total }: TipProps & { total: number }) {
  const { t } = useI18n();
  if (!active || !payload?.length) return null;
  const value = Number(payload[0].value) || 0;
  const pct = total > 0 ? ((value / total) * 100).toFixed(1) : "0.0";
  return (
    <TipContainer>
      <p className="font-semibold">{String(payload[0].name)}</p>
      <p>
        {t("analytics.docs_count", { count: value })} · <span className="font-semibold">{pct}%</span>
      </p>
    </TipContainer>
  );
}

function FileTypeTip({ active, payload, total }: TipProps & { total: number }) {
  const { t } = useI18n();
  if (!active || !payload?.length) return null;
  const value = Number(payload[0].value) || 0;
  const pct = total > 0 ? ((value / total) * 100).toFixed(1) : "0.0";
  return (
    <TipContainer>
      <p className="font-semibold">{String(payload[0].name)}</p>
      <p>
        {t("analytics.tip.doc_count")}: <span className="font-semibold">{value}</span>
      </p>
      <p>
        {t("analytics.tip.pct")}: <span className="font-semibold">{pct}%</span>
      </p>
    </TipContainer>
  );
}

function EngineTip({ active, payload }: TipProps) {
  const { t } = useI18n();
  if (!active || !payload?.length) return null;
  const datum = payload[0].payload ?? {};
  const time = datum.avg_processing_time as number | undefined;
  const jobs = datum.jobs as number | undefined;
  return (
    <TipContainer>
      <p className="font-semibold">{engineLabel(String(payload[0].name ?? datum.engine ?? ""))}</p>
      <p>
        {t("analytics.tip.avg_time")}: <span className="font-semibold">{formatSeconds(time)}</span>
      </p>
      <p>
        {t("analytics.tip.jobs")}: <span className="font-semibold">{jobs ?? "—"}</span>
      </p>
    </TipContainer>
  );
}

function EngineConfTip({ active, payload }: TipProps) {
  const { t } = useI18n();
  if (!active || !payload?.length) return null;
  const datum = payload[0].payload ?? {};
  const conf = datum.avg_confidence as number | undefined;
  const jobs = datum.jobs as number | undefined;
  return (
    <TipContainer>
      <p className="font-semibold">{engineLabel(String(datum.engine ?? payload[0].name ?? ""))}</p>
      <p>
        {t("analytics.tip.avg_confidence")}: <span className="font-semibold">{formatPercent(conf)}</span>
      </p>
      <p>
        {t("analytics.tip.jobs")}: <span className="font-semibold">{jobs ?? "—"}</span>
      </p>
    </TipContainer>
  );
}

export default function AnalyticsPage() {
  const { t, lang } = useI18n();
  const [charts, setCharts] = useState<StatsCharts | null>(null);
  const [overview, setOverview] = useState<StatsOverview | null>(null);
  const [enginePerf, setEnginePerf] = useState<EnginePerformance[] | null>(null);
  const [system, setSystem] = useState<SystemInfo | null>(null);
  const [engines, setEngines] = useState<EngineInfo[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    Promise.all([
      getStatsCharts(),
      getStatsOverview(),
      getEnginePerformance(),
      getSystemInfo(),
      listEngines().catch(() => [] as EngineInfo[]),
    ])
      .then(([ch, ov, perf, sys, eng]) => {
        setCharts(ch);
        setOverview(ov);
        setEnginePerf(perf);
        setSystem(sys);
        setEngines(eng);
      })
      .catch((err) => setError(err instanceof Error ? err.message : "Failed to load analytics"));
  }, []);

  const readyNames = useMemo(() => new Set(engines.filter((e) => e.status === "READY").map((e) => e.name)), [engines]);

  const langLabel = (value: string) =>
    value === "ar"
      ? t("analytics.lang.ar")
      : value === "en"
        ? t("analytics.lang.en")
        : value === "mixed"
          ? t("analytics.lang.mixed")
          : value;

  const confidenceData = useMemo(
    () => (charts ? charts.confidence_per_day.map((d) => ({ ...d, confidencePct: Math.round(d.confidence * 1000) / 10 })) : []),
    [charts]
  );

  const langData = useMemo(() => {
    if (!charts) return [];
    const total = charts.language_distribution.reduce((n, l) => n + l.count, 0);
    return charts.language_distribution
      .map((l) => ({
        name: langLabel(l.language),
        value: l.count,
      }))
      .filter((l) => l.value > 0)
      .sort((a, b) => b.value - a.value)
      .map((l) => ({ ...l, pct: total > 0 ? (l.value / total) * 100 : 0 }));
  }, [charts, t]);

  const fileTypeTotal = useMemo(
    () => (charts ? charts.file_types.reduce((n, f) => n + f.count, 0) : 0),
    [charts]
  );

  const usageData = useMemo(
    () => (charts ? charts.engine_usage.filter((u) => readyNames.has(u.engine)) : []),
    [charts, readyNames]
  );

  const perfEngines = useMemo(
    () =>
      enginePerf
        ? enginePerf.filter((p) => readyNames.has(p.engine)).sort((a, b) => b.avg_processing_time - a.avg_processing_time)
        : [],
    [enginePerf, readyNames]
  );
  const confEngines = useMemo(
    // QARI reports no native confidence — only show engines that actually measured it.
    () => perfEngines.filter((p) => p.jobs > 0 && p.avg_confidence != null).sort((a, b) => (b.avg_confidence ?? 0) - (a.avg_confidence ?? 0)),
    [perfEngines]
  );
  const confEngineData = useMemo(
    () => confEngines.map((p) => ({ ...p, avg_confidence_pct: Math.round((p.avg_confidence as number) * 1000) / 10 })),
    [confEngines]
  );

  if (error) {
    return <p className="text-sm text-destructive">{error}</p>;
  }

  if (!charts || !overview) {
    return (
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {Array.from({ length: 6 }).map((_, i) => (
          <Skeleton key={i} className="h-72" />
        ))}
      </div>
    );
  }

  const kpis = [
    { label: t("analytics.kpi.documents"), value: overview.documents_processed, icon: FileText },
    { label: t("analytics.kpi.pages"), value: overview.pages_processed, icon: Files },
    { label: t("analytics.kpi.confidence"), value: formatPercent(overview.average_confidence), icon: Gauge },
    { label: t("analytics.kpi.time"), value: formatSeconds(overview.average_processing_time), icon: Timer },
    { label: t("analytics.kpi.corrections"), value: overview.total_corrections, icon: PenLine },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">{t("analytics.title")}</h1>
        <p className="text-sm text-muted-foreground">{t("analytics.subtitle")}</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        {kpis.map((kpi) => (
          <Card key={kpi.label}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">{kpi.label}</CardTitle>
              <kpi.icon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{kpi.value}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-sm font-medium">{t("analytics.requests")}</CardTitle>
          </CardHeader>
          <CardContent className="h-64">
            {charts.requests_per_day.length ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={charts.requests_per_day} margin={{ top: 4, right: 8, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" vertical={false} />
                  <XAxis
                    dataKey="date"
                    tick={{ fontSize: 11 }}
                    tickFormatter={(v: string) => dayLabel(v, lang)}
                    minTickGap={24}
                  />
                  <YAxis
                    allowDecimals={false}
                    domain={[0, "auto"]}
                    tickFormatter={(v: number) => String(Math.round(v))}
                    tick={{ fontSize: 11 }}
                    width={32}
                  />
                  <Tooltip content={<RequestsTip />} cursor={{ fill: "hsl(var(--muted-foreground) / 0.08)" }} />
                  <Bar dataKey="count" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} maxBarSize={36} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <EmptyChart label={t("analytics.empty")} />
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium">{t("analytics.confidence")}</CardTitle>
          </CardHeader>
          <CardContent className="h-64">
            {confidenceData.length ? (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={confidenceData} margin={{ top: 4, right: 8, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" vertical={false} />
                  <XAxis
                    dataKey="date"
                    tick={{ fontSize: 11 }}
                    tickFormatter={(v: string) => dayLabel(v, lang)}
                    minTickGap={24}
                  />
                  <YAxis
                    domain={[0, 100]}
                    tickFormatter={(v: number) => `${Math.round(v)}%`}
                    tick={{ fontSize: 11 }}
                    width={40}
                  />
                  <Tooltip content={<ConfidenceTip />} />
                  <Line
                    type="monotone"
                    dataKey="confidencePct"
                    stroke="#10b981"
                    strokeWidth={2}
                    dot={{ r: 3, fill: "#10b981", strokeWidth: 0 }}
                    activeDot={{ r: 5 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <EmptyChart label={t("analytics.empty")} />
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium">{t("analytics.languages")}</CardTitle>
          </CardHeader>
          <CardContent className="h-64">
            {langData.length ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={langData}
                    dataKey="value"
                    nameKey="name"
                    innerRadius={55}
                    outerRadius={80}
                    paddingAngle={2}
                    strokeWidth={1}
                  >
                    {langData.map((_, i) => (
                      <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip content={<CategoryTip total={langData.reduce((n, l) => n + l.value, 0)} />} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <EmptyChart label={t("analytics.empty")} />
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium">{t("analytics.filetypes")}</CardTitle>
          </CardHeader>
          <CardContent className="h-64">
            {charts.file_types.length ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={charts.file_types} layout="vertical" margin={{ top: 4, right: 12, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" horizontal={false} />
                  <XAxis type="number" allowDecimals={false} tick={{ fontSize: 11 }} />
                  <YAxis
                    type="category"
                    dataKey="type"
                    tick={{ fontSize: 11 }}
                    width={64}
                  />
                  <Tooltip content={<FileTypeTip total={fileTypeTotal} />} cursor={{ fill: "hsl(var(--muted-foreground) / 0.08)" }} />
                  <Bar dataKey="count" fill="#8b5cf6" radius={[0, 4, 4, 0]} maxBarSize={28} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <EmptyChart label={t("analytics.empty")} />
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium">{t("analytics.engines")}</CardTitle>
          </CardHeader>
          <CardContent className="h-64">
            {usageData.length ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={usageData.map((u) => ({ name: engineLabel(u.engine), value: u.count }))}
                    dataKey="value"
                    nameKey="name"
                    innerRadius={55}
                    outerRadius={80}
                    paddingAngle={2}
                    strokeWidth={1}
                  >
                    {usageData.map((_, i) => (
                      <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip content={<CategoryTip total={usageData.reduce((n, u) => n + u.count, 0)} />} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <EmptyChart label={t("analytics.empty")} />
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium">{t("analytics.engine_perf")}</CardTitle>
          </CardHeader>
          <CardContent className="h-64">
            {perfEngines.length ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={perfEngines} layout="vertical" margin={{ top: 4, right: 12, left: 8, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" horizontal={false} />
                  <XAxis type="number" tick={{ fontSize: 11 }} tickFormatter={(v: number) => `${v}s`} />
                  <YAxis type="category" dataKey="engine" tick={{ fontSize: 11 }} tickFormatter={(v: string) => engineLabel(v)} width={80} />
                  <Tooltip content={<EngineTip />} cursor={{ fill: "hsl(var(--muted-foreground) / 0.08)" }} />
                  <Bar dataKey="avg_processing_time" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} maxBarSize={28} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <EmptyChart label={t("analytics.engine_perf.empty")} />
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium">{t("analytics.engine_conf")}</CardTitle>
          </CardHeader>
          <CardContent className="h-64">
            {confEngines.length ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={confEngineData} margin={{ top: 4, right: 8, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" vertical={false} />
                  <XAxis dataKey="engine" tick={{ fontSize: 11 }} tickFormatter={(v: string) => engineLabel(v)} />
                  <YAxis domain={[0, 100]} tickFormatter={(v: number) => `${Math.round(v)}%`} tick={{ fontSize: 11 }} width={40} />
                  <Tooltip content={<EngineConfTip />} cursor={{ fill: "hsl(var(--muted-foreground) / 0.08)" }} />
                  <Bar dataKey="avg_confidence_pct" fill="#06b6d4" radius={[4, 4, 0, 0]} maxBarSize={36} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <EmptyChart label={t("analytics.engine_perf.empty")} />
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium">{t("analytics.system")}</CardTitle>
          </CardHeader>
          <CardContent>
            {system ? (
              <dl className="grid grid-cols-2 gap-x-4 gap-y-3 text-sm">
                <div>
                  <dt className="text-muted-foreground">{t("analytics.cpu_cores")}</dt>
                  <dd className="font-semibold">{system.cpu_cores}</dd>
                </div>
                <div>
                  <dt className="text-muted-foreground">{t("analytics.gpu")}</dt>
                  <dd className="font-semibold">
                    {system.gpu_available ? system.gpu_name ?? t("analytics.gpu.available") : t("analytics.gpu.unavailable")}
                  </dd>
                </div>
                <div>
                  <dt className="text-muted-foreground">{t("analytics.python")}</dt>
                  <dd className="font-semibold" dir="ltr">
                    {system.python_version}
                  </dd>
                </div>
                <div>
                  <dt className="text-muted-foreground">{t("analytics.worker_mode")}</dt>
                  <dd className="font-semibold" dir="ltr">
                    {system.worker_mode}
                  </dd>
                </div>
                <div className="col-span-2">
                  <dt className="text-muted-foreground">{t("analytics.platform")}</dt>
                  <dd className="truncate font-mono text-xs" dir="ltr" title={system.platform}>
                    {system.platform}
                  </dd>
                </div>
              </dl>
            ) : (
              <Skeleton className="h-32 w-full" />
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function EmptyChart({ label }: { label: string }) {
  return (
    <div className="flex h-full items-center justify-center rounded-lg border border-dashed text-sm text-muted-foreground">
      {label}
    </div>
  );
}