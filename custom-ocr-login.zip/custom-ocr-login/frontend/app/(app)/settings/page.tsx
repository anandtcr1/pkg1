"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Download, FlaskConical, HeartPulse, KeyRound } from "lucide-react";

import { exportCorrectionsUrl, listEngines } from "@/lib/api";
import { useI18n } from "@/lib/i18n";
import type { EngineInfo } from "@/lib/types";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { LanguageSwitcher } from "@/components/language-switcher";
import { ThemeToggle } from "@/components/theme-toggle";
import { engineDisplayName } from "@/lib/utils";

function statusVariant(status: string): "success" | "warning" | "secondary" | "destructive" {
  if (status === "READY") return "success";
  if (status === "MODEL_NOT_INSTALLED") return "warning";
  if (status === "UNAVAILABLE") return "secondary";
  return "destructive";
}

export default function SettingsPage() {
  const { t } = useI18n();
  const [engines, setEngines] = useState<EngineInfo[]>([]);

  useEffect(() => {
    listEngines().then(setEngines).catch(() => setEngines([]));
  }, []);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">{t("settings.title")}</h1>
        <p className="text-sm text-muted-foreground">{t("settings.subtitle")}</p>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium">{t("settings.language")}</CardTitle>
            <CardDescription>{t("settings.language_note")}</CardDescription>
          </CardHeader>
          <CardContent className="flex items-center justify-between">
            <span className="text-sm">{t("settings.language")}</span>
            <LanguageSwitcher />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium">{t("settings.appearance")}</CardTitle>
            <CardDescription>{t("settings.appearance_note")}</CardDescription>
          </CardHeader>
          <CardContent className="flex items-center justify-between">
            <span className="text-sm">{t("settings.theme")}</span>
            <ThemeToggle />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium">{t("settings.engines")}</CardTitle>
            <CardDescription>{t("settings.engines_note")}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {engines.length === 0 && <span className="text-sm text-muted-foreground">{t("common.loading")}</span>}
            {engines.map((e) => (
              <div key={e.name} className="flex items-center justify-between gap-2 rounded-lg border px-3 py-2">
                <div className="flex min-w-0 items-center gap-2">
                  <span className="text-sm font-medium">{engineDisplayName(e.name)}</span>
                  {e.version && <span className="text-xs text-muted-foreground">v{e.version}</span>}
                  {e.device && <span className="text-xs text-muted-foreground">({e.device})</span>}
                </div>
                <Badge variant={statusVariant(e.status)}>
                  {e.status === "READY"
                    ? t("settings.engine.ready")
                    : e.status === "MODEL_NOT_INSTALLED"
                      ? t("settings.engine.not_installed")
                      : e.status}
                </Badge>
              </div>
            ))}
            <p className="pt-1 text-xs text-muted-foreground">{t("settings.engine.missing_note")}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-sm font-medium">
              <HeartPulse className="h-4 w-4" /> {t("settings.system_health")}
            </CardTitle>
            <CardDescription>{t("settings.system_health_note")}</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-wrap gap-2">
            <Button asChild variant="outline">
              <Link href="/system-health">{t("settings.system_health_open")}</Link>
            </Button>
            <Button asChild variant="outline">
              <Link href="/lab">
                <FlaskConical className="me-1 h-4 w-4" /> {t("settings.lab_open")}
              </Link>
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-sm font-medium">
              <KeyRound className="h-4 w-4" /> {t("settings.apikeys")}
            </CardTitle>
            <CardDescription>{t("settings.apikeys_note")}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            <Button asChild variant="outline">
              <Link href="/settings/api">{t("settings.apikeys_manage")}</Link>
            </Button>
            <p className="text-xs text-muted-foreground">{t("settings.api_access_note")}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-sm font-medium">
              <Download className="h-4 w-4" /> {t("settings.dataset")}
            </CardTitle>
            <CardDescription>{t("settings.dataset_note")}</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-wrap gap-2">
            <Button asChild variant="outline" size="sm">
              <a href={exportCorrectionsUrl("jsonl")} download>
                Export JSONL
              </a>
            </Button>
            <Button asChild variant="outline" size="sm">
              <a href={exportCorrectionsUrl("json")} download>
                Export JSON
              </a>
            </Button>
            <Button asChild variant="outline" size="sm">
              <a href={exportCorrectionsUrl("csv")} download>
                Export CSV
              </a>
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}