"use client";

import { useCallback, useEffect, useState } from "react";
import { Copy, KeyRound, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";

import { createApiKey, listApiKeys, revokeApiKey } from "@/lib/api";
import { useI18n } from "@/lib/i18n";
import type { APIKeyCreated, APIKeyOut } from "@/lib/types";
import { formatDate } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";

export default function ApiKeysPage() {
  const { t, lang } = useI18n();
  const [keys, setKeys] = useState<APIKeyOut[] | null>(null);
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [created, setCreated] = useState<APIKeyCreated | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    setName((current) => current || t("keys.default_name"));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const load = useCallback(async () => {
    try {
      setKeys(await listApiKeys());
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("keys.load_failed"));
      setKeys([]);
    }
  }, [t]);

  useEffect(() => {
    load();
  }, [load]);

  const handleCreate = async () => {
    setBusy(true);
    try {
      const key = await createApiKey(name.trim() || t("keys.default_name"));
      setCreated(key);
      setOpen(false);
      toast.success(t("keys.created"));
      load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("keys.create_failed"));
    } finally {
      setBusy(false);
    }
  };

  const handleRevoke = async (id: string) => {
    if (!confirm(t("keys.revoke_confirm"))) return;
    try {
      await revokeApiKey(id);
      toast.success(t("keys.revoke_ok"));
      load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("keys.revoke_failed"));
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">{t("keys.title")}</h1>
          <p className="text-sm text-muted-foreground" dir="ltr">
            Authorization: Bearer ocr_live_…
          </p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="me-1 h-4 w-4" /> {t("keys.new")}
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{t("keys.dialog.title")}</DialogTitle>
              <DialogDescription>{t("keys.dialog.desc")}</DialogDescription>
            </DialogHeader>
            <div className="space-y-2">
              <Label htmlFor="key-name">{t("keys.dialog.name")}</Label>
              <Input id="key-name" value={name} onChange={(e) => setName(e.target.value)} />
            </div>
            <DialogFooter>
              <Button onClick={handleCreate} disabled={busy}>
                {t("keys.dialog.create")}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {created && (
        <Card className="border-emerald-500/50">
          <CardHeader>
            <CardTitle className="text-sm font-medium">{t("keys.created_title")}</CardTitle>
            <CardDescription>{t("keys.created_note")}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <code className="flex-1 break-all rounded-lg bg-muted px-3 py-2 text-sm" dir="ltr">
                {created.key}
              </code>
              <Button
                variant="outline"
                size="icon"
                onClick={() => {
                  navigator.clipboard.writeText(created.key);
                  toast.success(t("keys.copied"));
                }}
              >
                <Copy className="h-4 w-4" />
              </Button>
            </div>
            <Button variant="ghost" size="sm" className="mt-2" onClick={() => setCreated(null)}>
              {t("keys.dismiss")}
            </Button>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardContent className="p-0">
          {keys === null ? (
            <div className="space-y-2 p-6">
              {Array.from({ length: 3 }).map((_, i) => (
                <Skeleton key={i} className="h-10 w-full" />
              ))}
            </div>
          ) : keys.length === 0 ? (
            <div className="flex flex-col items-center py-14 text-center">
              <KeyRound className="h-8 w-8 text-muted-foreground" />
              <p className="mt-2 text-sm text-muted-foreground">{t("keys.empty")}</p>
            </div>
          ) : (
            <table className="w-full text-sm">
              <thead className="border-b bg-muted/50 text-xs uppercase text-muted-foreground">
                <tr>
                  <th className="px-4 py-3 text-start">{t("common.name")}</th>
                  <th className="px-4 py-3 text-start">{t("keys.prefix")}</th>
                  <th className="px-4 py-3 text-start">{t("common.status")}</th>
                  <th className="px-4 py-3 text-start">{t("common.created")}</th>
                  <th className="px-4 py-3 text-start">{t("keys.last_used")}</th>
                  <th className="px-4 py-3 text-end">{t("common.actions")}</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {keys.map((k) => (
                  <tr key={k.id}>
                    <td className="px-4 py-3 font-medium">{k.name}</td>
                    <td className="px-4 py-3">
                      <code className="text-xs" dir="ltr">
                        {k.prefix}…
                      </code>
                    </td>
                    <td className="px-4 py-3">
                      {k.revoked ? (
                        <Badge variant="danger">{t("keys.revoked")}</Badge>
                      ) : (
                        <Badge variant="success">{t("keys.active")}</Badge>
                      )}
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">{formatDate(k.created_at, lang)}</td>
                    <td className="px-4 py-3 text-muted-foreground">
                      {k.last_used_at ? formatDate(k.last_used_at, lang) : t("common.never")}
                    </td>
                    <td className="px-4 py-3 text-end">
                      <Button
                        variant="ghost"
                        size="icon"
                        disabled={k.revoked}
                        onClick={() => handleRevoke(k.id)}
                        title={t("keys.revoke")}
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
