"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import {
  ArrowLeft,
  FileText,
  Files,
  Gauge,
  HeartPulse,
  ShieldCheck,
  Timer,
  XCircle,
} from "lucide-react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

import { API_BASE, getStatsCharts, getStatsOverview, getSystemHealth, listJobs } from "@/lib/api";
import { useI18n } from "@/lib/i18n";
import type { JobSummary, StatsCharts, StatsOverview, SystemHealth } from "@/lib/types";
import { formatPercent, formatSeconds } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { JobsTable } from "@/components/jobs-table";

export default function DashboardPage() {
  const { t } = useI18n();
  const [overview, setOverview] = useState<StatsOverview | null>(null);
  const [charts, setCharts] = useState<StatsCharts | null>(null);
  const [health, setHealth] = useState<SystemHealth | null>(null);
  const [recent, setRecent] = useState<JobSummary[]>([]);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const [ov, ch, h, jobs] = await Promise.all([
        getStatsOverview(),
        getStatsCharts(),
        getSystemHealth().catch(() => null),
        listJobs({ limit: 8 }),
      ]);
      setOverview(ov);
      setCharts(ch);
      setHealth(h);
      setRecent(jobs.items);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load dashboard");
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const readyEngines = health?.engines.filter((e) => e.status === "READY").length ?? 0;

  const cards = [
    {
      title: t("dashboard.card.documents"),
      value: overview?.documents_processed,
      icon: FileText,
    },
    {
      title: t("dashboard.card.pages"),
      value: overview?.pages_processed,
      icon: Files,
    },
    {
      title: t("dashboard.card.confidence"),
      value: overview ? formatPercent(overview.average_confidence) : undefined,
      icon: Gauge,
    },
    {
      title: t("dashboard.card.verified_accuracy"),
      value: overview?.verified_accuracy != null ? formatPercent(overview.verified_accuracy) : t("jobs.verified.empty"),
      icon: ShieldCheck,
    },
    {
      title: t("dashboard.card.time"),
      value: overview ? formatSeconds(overview.average_processing_time) : undefined,
      icon: Timer,
    },
    {
      title: t("dashboard.card.failed"),
      value: overview?.failed_jobs,
      icon: XCircle,
    },
  ];

  const statusBadges = health
    ? [
        health.offline.offline_mode
          ? { label: t("dashboard.status.offline"), variant: "warning" as const }
          : { label: t("dashboard.status.online"), variant: "success" as const },
        {
          label: t("dashboard.status.engines_ready", {
            ready: readyEngines,
            total: health.engines.length,
          }),
          variant: readyEngines > 0 ? ("success" as const) : ("destructive" as const),
        },
        health.database === "ok"
          ? { label: t("dashboard.status.db_ok"), variant: "success" as const }
          : { label: t("dashboard.status.db_error"), variant: "destructive" as const },
        health.queue === "ok"
          ? { label: t("dashboard.status.queue_ok"), variant: "success" as const }
          : { label: t("dashboard.status.queue_inline"), variant: "secondary" as const },
      ]
    : [];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">{t("dashboard.title")}</h1>
          <p className="text-sm text-muted-foreground">{t("dashboard.subtitle")}</p>
        </div>
        <Button asChild>
          <Link href="/ocr">
            {t("dashboard.new_ocr")}
            <ArrowLeft className="ms-1 h-4 w-4 rtl:rotate-0 ltr:rotate-180" />
          </Link>
        </Button>
      </div>

      {error && (
        <Card className="border-destructive/50">
          <CardContent className="py-4 text-sm text-destructive">
            {t("dashboard.backend_error", { error, url: API_BASE })}
          </CardContent>
        </Card>
      )}

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {cards.map((card) => (
          <Card key={card.title}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">{card.title}</CardTitle>
              <card.icon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              {overview ? (
                <div className="text-2xl font-bold">{card.value}</div>
              ) : (
                <Skeleton className="h-8 w-24" />
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-1">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="flex items-center gap-2 text-sm font-medium">
              <HeartPulse className="h-4 w-4 text-muted-foreground" /> {t("dashboard.status.title")}
            </CardTitle>
            {health?.offline.offline_mode && (
              <Badge variant="warning">{t("dashboard.status.badge.offline")}</Badge>
            )}
          </CardHeader>
          <CardContent className="space-y-2">
            {!health && <Skeleton className="h-10 w-full" />}
            {statusBadges.map((b) => (
              <Badge key={b.label} variant={b.variant} className="me-1.5">
                {b.label}
              </Badge>
            ))}
            {health && (
              <p className="pt-2 text-xs text-muted-foreground">
                {health.offline.models_dir_exists
                  ? t("dashboard.status.models_local")
                  : t("dashboard.status.models_missing")}
              </p>
            )}
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-sm font-medium">{t("dashboard.chart.requests")}</CardTitle>
          </CardHeader>
          <CardContent className="h-48">
            {charts ? (
              charts.requests_per_day.length ? (
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={charts.requests_per_day}>
                    <defs>
                      <linearGradient id="req" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity={0.4} />
                        <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                    <YAxis allowDecimals={false} tick={{ fontSize: 11 }} width={30} />
                    <Tooltip />
                    <Area type="monotone" dataKey="count" stroke="hsl(var(--primary))" fill="url(#req)" />
                  </AreaChart>
                </ResponsiveContainer>
              ) : (
                <EmptyChart label={t("dashboard.chart.empty_requests")} />
              )
            ) : (
              <Skeleton className="h-full w-full" />
            )}
          </CardContent>
        </Card>

        <Card className="lg:col-span-3">
          <CardHeader>
            <CardTitle className="text-sm font-medium">{t("dashboard.chart.confidence")}</CardTitle>
          </CardHeader>
          <CardContent className="h-64">
            {charts ? (
              charts.confidence_per_day.length ? (
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={charts.confidence_per_day}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                    <YAxis domain={[0, 1]} tickFormatter={(v: number) => `${Math.round(v * 100)}%`} tick={{ fontSize: 11 }} width={40} />
                    <Tooltip formatter={(v: number) => formatPercent(v)} />
                    <Line type="monotone" dataKey="confidence" stroke="hsl(var(--primary))" strokeWidth={2} dot />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <EmptyChart label={t("dashboard.chart.empty_confidence")} />
              )
            ) : (
              <Skeleton className="h-full w-full" />
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-sm font-medium">{t("dashboard.recent")}</CardTitle>
          <Button variant="ghost" size="sm" asChild>
            <Link href="/history">{t("dashboard.view_all")}</Link>
          </Button>
        </CardHeader>
        <CardContent>
          <JobsTable jobs={recent} loading={!overview && !error} onChanged={load} />
        </CardContent>
      </Card>
    </div>
  );
}

function EmptyChart({ label }: { label: string }) {
  return (
    <div className="flex h-full items-center justify-center rounded-lg border border-dashed text-sm text-muted-foreground">
      {label}
    </div>
  );
}