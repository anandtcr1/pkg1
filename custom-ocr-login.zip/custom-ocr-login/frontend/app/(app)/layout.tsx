import { AuthGuard } from "@/components/auth-guard";
import { MobileNav, Sidebar } from "@/components/sidebar";

export default function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Sidebar />
      <MobileNav />
      <main className="pb-20 md:pb-0 md:ps-60">
        <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
          <AuthGuard>{children}</AuthGuard>
        </div>
      </main>
    </>
  );
}