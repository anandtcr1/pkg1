"use client";

import { useCallback, useEffect, useState } from "react";

import { listJobs } from "@/lib/api";
import { useI18n, type TranslationKey } from "@/lib/i18n";
import type { JobSummary } from "@/lib/types";
import { JobsTable } from "@/components/jobs-table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const STATUS_FILTERS: { value: string; labelKey: TranslationKey }[] = [
  { value: "", labelKey: "status.all" },
  { value: "completed", labelKey: "status.completed" },
  { value: "processing", labelKey: "status.processing" },
  { value: "pending", labelKey: "status.pending" },
  { value: "failed", labelKey: "status.failed" },
];

const PAGE_SIZE = 15;

export default function HistoryPage() {
  const { t } = useI18n();
  const [jobs, setJobs] = useState<JobSummary[]>([]);
  const [total, setTotal] = useState(0);
  const [status, setStatus] = useState("");
  const [q, setQ] = useState("");
  const [page, setPage] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await listJobs({
        status: status || undefined,
        q: q || undefined,
        limit: PAGE_SIZE,
        offset: page * PAGE_SIZE,
      });
      setJobs(res.items);
      setTotal(res.total);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load history");
    } finally {
      setLoading(false);
    }
  }, [status, q, page]);

  useEffect(() => {
    const timer = setTimeout(load, 250);
    return () => clearTimeout(timer);
  }, [load]);

  const pages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">{t("history.title")}</h1>
        <p className="text-sm text-muted-foreground">{t("history.subtitle")}</p>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        {STATUS_FILTERS.map((f) => (
          <Button
            key={f.value}
            variant={status === f.value ? "default" : "outline"}
            size="sm"
            onClick={() => {
              setStatus(f.value);
              setPage(0);
            }}
          >
            {t(f.labelKey)}
          </Button>
        ))}
        <div className="ms-auto">
          <Input
            placeholder={t("history.search")}
            value={q}
            onChange={(e) => {
              setQ(e.target.value);
              setPage(0);
            }}
            className="w-56"
          />
        </div>
      </div>

      {error && <p className="text-sm text-destructive">{error}</p>}

      <JobsTable jobs={jobs} loading={loading} onChanged={load} />

      {pages > 1 && (
        <div className="flex items-center justify-center gap-2">
          <Button variant="outline" size="sm" disabled={page === 0} onClick={() => setPage((p) => p - 1)}>
            {t("history.previous")}
          </Button>
          <span className="text-sm text-muted-foreground">
            {t("history.page_of", { current: page + 1, total: pages })}
          </span>
          <Button
            variant="outline"
            size="sm"
            disabled={page >= pages - 1}
            onClick={() => setPage((p) => p + 1)}
          >
            {t("history.next")}
          </Button>
        </div>
      )}
    </div>
  );
}
