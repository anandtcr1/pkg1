"use client";

import { useRouter } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";
import { useDropzone } from "react-dropzone";
import {
  ArrowLeft,
  CheckCircle2,
  CloudUpload,
  FileText,
  Loader2,
  Map,
  Scan,
  Square,
  XCircle,
} from "lucide-react";
import { toast } from "sonner";

import { getJob, listEngines, listLanguages, uploadDocument } from "@/lib/api";
import { useI18n, type TranslationKey } from "@/lib/i18n";
import type { EngineInfo, LanguageInfo, OCRMode, RegionSpec } from "@/lib/types";
import { cn, formatBytes } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { DEFAULT_OPTIONS, OCROptionsPanel } from "@/components/ocr-options-panel";
import RegionSelector from "@/components/region-selector";

const MAX_BYTES = 50 * 1024 * 1024;
const ACCEPTED = {
  "image/jpeg": [".jpg", ".jpeg"],
  "image/png": [".png"],
  "image/webp": [".webp"],
  "image/tiff": [".tif", ".tiff"],
  "image/bmp": [".bmp"],
  "application/pdf": [".pdf"],
};

const MODES: { value: OCRMode; icon: typeof Scan }[] = [
  { value: "full", icon: Scan },
  { value: "area", icon: Square },
  { value: "multi", icon: Map },
];

type Stage = "uploading" | "processing" | "extracting" | "completed" | "failed";

interface QueueItem {
  id: string;
  file: File;
  jobId?: string;
  stage: Stage;
  error?: string;
}

const STAGE_PROGRESS: Record<Stage, number> = {
  uploading: 15,
  processing: 45,
  extracting: 75,
  completed: 100,
  failed: 100,
};

export default function NewOCRPage() {
  const router = useRouter();
  const { t } = useI18n();
  const [options, setOptions] = useState(DEFAULT_OPTIONS);
  const [engines, setEngines] = useState<EngineInfo[]>([]);
  const [languages, setLanguages] = useState<LanguageInfo[]>([]);
  const [mode, setMode] = useState<OCRMode>("full");
  const [regionFile, setRegionFile] = useState<File | null>(null);
  const [regions, setRegions] = useState<RegionSpec[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [queue, setQueue] = useState<QueueItem[]>([]);
  const timers = useRef<Record<string, ReturnType<typeof setInterval>>>({});

  useEffect(() => {
    listEngines()
      .then((list) => setEngines(list))
      .catch(() => setEngines([]));
    listLanguages()
      .then((list) => setLanguages(list))
      .catch(() => setLanguages([]));
    const active = timers.current;
    return () => Object.values(active).forEach(clearInterval);
  }, []);

  const pollJob = useCallback(
    (localId: string, jobId: string) => {
      let ticks = 0;
      timers.current[localId] = setInterval(async () => {
        ticks++;
        try {
          const job = await getJob(jobId);
          setQueue((q) =>
            q.map((item) => {
              if (item.id !== localId) return item;
              if (job.status === "completed") return { ...item, stage: "completed" };
              if (job.status === "failed") return { ...item, stage: "failed", error: job.error ?? "OCR failed" };
              // pending→processing, then "extracting" once the job has been running a while
              return { ...item, stage: ticks > 3 ? "extracting" : "processing" };
            })
          );
          if (job.status === "completed" || job.status === "failed") {
            clearInterval(timers.current[localId]);
            delete timers.current[localId];
            if (job.status === "completed") {
              toast.success(t("ocr.toast.completed", { name: job.filename }));
            } else {
              toast.error(t("ocr.toast.failed", { error: job.error ?? "unknown" }));
            }
          }
        } catch {
          // transient network error — keep polling
        }
      }, 1500);
    },
    [t]
  );

  const onDrop = useCallback(
    (accepted: File[]) => {
      for (const file of accepted) {
        const localId = `${Date.now()}-${file.name}-${Math.random().toString(36).slice(2)}`;
        setQueue((q) => [...q, { id: localId, file, stage: "uploading" }]);
        const { engine_select, ...payload } = { ...options, engine: options.engine_select };
        uploadDocument(file, payload)
          .then(({ job_id }) => {
            setQueue((q) =>
              q.map((item) => (item.id === localId ? { ...item, jobId: job_id, stage: "processing" } : item))
            );
            pollJob(localId, job_id);
          })
          .catch((err) => {
            setQueue((q) =>
              q.map((item) =>
                item.id === localId
                  ? { ...item, stage: "failed", error: err instanceof Error ? err.message : "Upload failed" }
                  : item
              )
            );
            toast.error(t("ocr.toast.upload_failed", { name: file.name }));
          });
      }
    },
    [options, pollJob, t]
  );

  const { getRootProps, getInputProps, isDragActive, open } = useDropzone({
    onDrop,
    accept: ACCEPTED,
    maxSize: MAX_BYTES,
    multiple: true,
    noClick: true,
    onDropRejected: (rejections) => {
      const first = rejections[0]?.errors[0];
      toast.error(first?.code === "file-too-large" ? t("ocr.toast.too_large") : t("ocr.toast.bad_type"));
    },
  });

  const regionDrop = useDropzone({
    onDrop: (accepted) => {
      const file = accepted[0];
      if (!file) return;
      setRegions([]);
      setRegionFile(file);
    },
    accept: ACCEPTED,
    maxSize: MAX_BYTES,
    multiple: false,
    noClick: true,
    onDropRejected: (rejections) => {
      const first = rejections[0]?.errors[0];
      toast.error(first?.code === "file-too-large" ? t("ocr.toast.too_large") : t("ocr.toast.bad_type"));
    },
  });

  const anyActive = queue.some((i) => i.stage !== "completed" && i.stage !== "failed");

  const handleRegionBack = useCallback(() => {
    setRegionFile(null);
    setRegions([]);
  }, []);

  const handleRegionSubmit = useCallback(async () => {
    if (!regionFile) return;
    if (regions.length === 0) {
      toast.error(t("ocr.region.none"));
      return;
    }
    setSubmitting(true);
    try {
      const { engine_select, ...payload } = { ...options, engine: options.engine_select };
      const specs = [...regions]
        .sort((a, b) => a.order - b.order)
        .map((r, i) => ({ ...r, order: i, label: String(i + 1) }));
      const { job_id } = await uploadDocument(regionFile, {
        ...payload,
        ocr_mode: mode,
        region_specs: specs,
      });
      router.push(`/ocr/job?id=${job_id}`);
    } catch {
      toast.error(t("ocr.toast.upload_failed", { name: regionFile.name }));
    } finally {
      setSubmitting(false);
    }
  }, [regionFile, regions, options, mode, router, t]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">{t("ocr.title")}</h1>
        <p className="text-sm text-muted-foreground">{t("ocr.subtitle")}</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-sm font-medium">{t("ocr.mode")}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex flex-col gap-1 rounded-xl bg-muted p-1 sm:flex-row">
            {MODES.map(({ value, icon: Icon }) => (
              <button
                key={value}
                type="button"
                onClick={() => {
                  setMode(value);
                  setRegionFile(null);
                  setRegions([]);
                }}
                className={cn(
                  "flex flex-1 items-center justify-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
                  mode === value
                    ? "bg-primary text-primary-foreground shadow-sm"
                    : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                )}
              >
                <Icon className="h-4 w-4" />
                {t(`ocr.mode.${value}` as TranslationKey)}
              </button>
            ))}
          </div>
          <p className="text-xs text-muted-foreground">{t("ocr.mode.hint")}</p>
        </CardContent>
      </Card>

      <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
        <div className="space-y-6">
          {mode === "full" ? (
            <>
              <div
                {...getRootProps()}
                className={cn(
                  "flex min-h-[280px] cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed p-8 text-center transition-colors",
                  isDragActive ? "border-primary bg-primary/5" : "border-border hover:border-primary/50 hover:bg-accent/40"
                )}
                onClick={open}
              >
                <input {...getInputProps()} />
                <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10">
                  <CloudUpload className="h-7 w-7 text-primary" />
                </div>
                <p className="mt-4 text-lg font-semibold">
                  {isDragActive ? t("ocr.drop.active") : t("ocr.drop.idle")}
                </p>
                <p className="mt-1 text-sm text-muted-foreground">{t("ocr.drop.formats")}</p>
                <p className="mt-1 text-xs text-muted-foreground">{t("ocr.drop.limits")}</p>
                <Button variant="outline" className="mt-4" type="button">
                  {t("ocr.drop.browse")}
                </Button>
              </div>

              {queue.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm font-medium">{t("ocr.queue")}</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {queue.map((item) => (
                      <div key={item.id} className="space-y-2">
                        <div className="flex items-center gap-3">
                          <FileText className="h-4 w-4 shrink-0 text-muted-foreground" />
                          <span className="min-w-0 flex-1 truncate text-sm font-medium">{item.file.name}</span>
                          <span className="text-xs text-muted-foreground">{formatBytes(item.file.size)}</span>
                          <StageIcon stage={item.stage} />
                          <span className="w-24 text-end text-xs text-muted-foreground">
                            {t(`ocr.stage.${item.stage}` as TranslationKey)}
                          </span>
                          {item.stage === "completed" && item.jobId && (
                            <Button size="sm" onClick={() => router.push(`/ocr/job?id=${item.jobId}`)}>
                              {t("common.view")}
                            </Button>
                          )}
                        </div>
                        <Progress value={STAGE_PROGRESS[item.stage]} className="h-1.5" />
                        {item.error && <p className="text-xs text-destructive">{item.error}</p>}
                      </div>
                    ))}
                    {!anyActive && (
                      <Button variant="outline" size="sm" onClick={() => setQueue([])}>
                        {t("ocr.queue.clear")}
                      </Button>
                    )}
                  </CardContent>
                </Card>
              )}
            </>
          ) : regionFile ? (
            <Card>
              <CardHeader>
                <CardTitle className="text-sm font-medium">{t("ocr.region.title")}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3">
                  <FileText className="h-4 w-4 shrink-0 text-muted-foreground" />
                  <span className="min-w-0 flex-1 truncate text-sm font-medium">{regionFile.name}</span>
                  <span className="shrink-0 text-xs text-muted-foreground">{formatBytes(regionFile.size)}</span>
                  <Button variant="outline" size="sm" type="button" onClick={handleRegionBack}>
                    <ArrowLeft className="h-4 w-4" />
                    {t("ocr.region.cancel")}
                  </Button>
                </div>

                <p className="text-sm text-muted-foreground">
                  {t(mode === "area" ? "ocr.region.draw_hint.area" : "ocr.region.draw_hint.multi")}
                </p>

                <RegionSelector file={regionFile} regions={regions} onChange={setRegions} />

                <Button
                  onClick={handleRegionSubmit}
                  disabled={submitting}
                  className="w-full gap-2 sm:w-auto"
                >
                  {submitting && <Loader2 className="h-4 w-4 animate-spin" />}
                  {t(mode === "area" ? "ocr.region.process_single" : "ocr.region.process")}
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div
              {...regionDrop.getRootProps()}
              className={cn(
                "flex min-h-[220px] cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed p-8 text-center transition-colors",
                regionDrop.isDragActive
                  ? "border-primary bg-primary/5"
                  : "border-border hover:border-primary/50 hover:bg-accent/40"
              )}
              onClick={regionDrop.open}
            >
              <input {...regionDrop.getInputProps()} />
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/10">
                <CloudUpload className="h-6 w-6 text-primary" />
              </div>
              <p className="mt-3 text-base font-semibold">
                {regionDrop.isDragActive ? t("ocr.drop.active") : t("ocr.drop.idle")}
              </p>
              <p className="mt-1 text-sm text-muted-foreground">{t("ocr.drop.formats")}</p>
              <Button variant="outline" className="mt-4" type="button">
                {t("ocr.drop.browse")}
              </Button>
            </div>
          )}
        </div>

        <Card className="h-fit">
          <CardHeader>
            <CardTitle className="text-sm font-medium">{t("ocr.settings")}</CardTitle>
          </CardHeader>
          <CardContent>
            <OCROptionsPanel options={options} onChange={setOptions} engines={engines} languages={languages} />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function StageIcon({ stage }: { stage: Stage }) {
  if (stage === "completed") return <CheckCircle2 className="h-4 w-4 text-emerald-500" />;
  if (stage === "failed") return <XCircle className="h-4 w-4 text-destructive" />;
  return <Loader2 className="h-4 w-4 animate-spin text-primary" />;
}