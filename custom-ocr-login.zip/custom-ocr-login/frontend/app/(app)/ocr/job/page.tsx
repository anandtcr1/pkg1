"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useCallback, useEffect, useMemo, useState } from "react";
import {
  ArrowLeft,
  Check,
  Copy,
  Download,
  FileCode,
  FileJson,
  FileText,
  Loader2,
  Pencil,
  RotateCcw,
  ShieldAlert,
  Trash2,
  X,
} from "lucide-react";
import { toast } from "sonner";

import {
  deleteJob,
  exportJobUrl,
  getJob,
  listEngines,
  reprocessJob,
  updateJob,
} from "@/lib/api";
import { useI18n } from "@/lib/i18n";
import type { EngineInfo, JobDetail, OCRBlock, OCRPage } from "@/lib/types";
import { cn, documentTypeLabel, engineDisplayName, formatPercent, formatSeconds, isRtl } from "@/lib/utils";
import { usePoll } from "@/hooks/use-poll";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ConfidenceBadge } from "@/components/confidence-badge";
import { DocumentViewer } from "@/components/document-viewer";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { JobStatusBadge } from "@/components/job-status-badge";
import { ReviewPanel } from "@/components/review-panel";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";

// Static export can't pre-render per-job routes, so the job id comes from ?id=
// (useSearchParams needs a Suspense boundary under output: "export").
export default function OCRResultPage() {
  return (
    <Suspense fallback={null}>
      <OCRResultContent />
    </Suspense>
  );
}

function OCRResultContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const { t } = useI18n();
  const jobId = searchParams.get("id") ?? "";

  const [refreshKey, setRefreshKey] = useState(0);
  const refresh = () => setRefreshKey((k) => k + 1);

  const fetcher = useCallback(() => getJob(jobId), [jobId]);
  const stop = useCallback((job: JobDetail) => job.status === "completed" || job.status === "failed", []);
  const { data: job, error } = usePoll<JobDetail>(fetcher, stop, 2000, [jobId, refreshKey]);

  const [hoveredBlockId, setHoveredBlockId] = useState<string | null>(null);
  const [showRegionOverlays, setShowRegionOverlays] = useState(true);
  const [editing, setEditing] = useState(false);
  const [editedText, setEditedText] = useState<string>("");
  const [reviewMode, setReviewMode] = useState(false);
  const [reprocessOpen, setReprocessOpen] = useState(false);
  const [reprocessEngine, setReprocessEngine] = useState<string>("tesseract");
  const [busy, setBusy] = useState(false);
  const [engines, setEngines] = useState<EngineInfo[]>([]);

  useEffect(() => {
    listEngines()
      .then(setEngines)
      .catch(() => setEngines([]));
  }, []);

  const direction = isRtl(job?.language) ? "rtl" : "ltr";

  const handleCopy = async () => {
    if (!job?.text) return;
    await navigator.clipboard.writeText(editing ? editedText : job.text);
    toast.success(t("result.copied"));
  };

  const handleSave = async () => {
    if (!job) return;
    setBusy(true);
    try {
      await updateJob(job.id, { text: editedText });
      toast.success(t("result.saved"));
      setEditing(false);
      refresh();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("result.save_failed"));
    } finally {
      setBusy(false);
    }
  };

  const handleReprocess = async () => {
    if (!job) return;
    setBusy(true);
    try {
      await reprocessJob(job.id, reprocessEngine);
      toast.success(t("result.reprocess_started"));
      setReprocessOpen(false);
      setBusy(false);
      refresh(); // job is now "pending" → the poller resumes until completion
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("result.reprocess_failed"));
      setBusy(false);
    }
  };

  const handleDelete = async () => {
    if (!job || !confirm(t("result.confirm_delete"))) return;
    try {
      await deleteJob(job.id);
      toast.success(t("result.deleted"));
      router.push("/history");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("result.delete_failed"));
    }
  };

  if (error) {
    return (
      <Card className="border-destructive/50">
        <CardContent className="py-10 text-center">
          <p className="font-medium text-destructive">{t("result.load_failed")}</p>
          <p className="mt-1 text-sm text-muted-foreground">{error}</p>
          <Button variant="outline" className="mt-4" onClick={() => router.push("/ocr")}>
            <ArrowLeft className="me-1 h-4 w-4 rtl:-scale-x-100" /> {t("result.back")}
          </Button>
        </CardContent>
      </Card>
    );
  }

  if (!job) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-10 w-2/3" />
        <div className="grid gap-4 lg:grid-cols-2">
          <Skeleton className="h-[600px]" />
          <Skeleton className="h-[600px]" />
        </div>
      </div>
    );
  }

  const processing = job.status === "pending" || job.status === "processing";
  const lowConfidenceCount = job.pages.reduce(
    (n, p) => n + p.blocks.filter((b) => (b.confidence ?? 1) < 0.8).length,
    0
  );

  return (
    <div className="space-y-4">
      {/* Header / toolbar */}
      <div className="flex flex-wrap items-center gap-2">
        <Button variant="ghost" size="icon" onClick={() => router.push("/ocr")}>
          <ArrowLeft className="h-4 w-4 rtl:-scale-x-100" />
        </Button>
        <div className="min-w-0 flex-1">
          <h1 className="truncate text-lg font-bold" title={job.filename}>
            {job.filename}
          </h1>
          <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
            <JobStatusBadge status={job.status} />
            {job.language && (
              <Badge variant="outline" className="uppercase">
                {job.language} {job.language !== "en" && "· RTL"}
              </Badge>
            )}
            {job.engine && <Badge variant="outline">{engineDisplayName(job.engine)}</Badge>}
            {job.document_type && (
              <Badge variant="info">
                {documentTypeLabel(job.document_type)}
                {job.document_type_confidence !== null &&
                  ` · ${formatPercent(job.document_type_confidence)}`}
              </Badge>
            )}
            <span>
              {job.page_count} {t("common.pages")}
            </span>
            <span>·</span>
            <span>{formatSeconds(job.processing_time)}</span>
          </div>
        </div>

        {job.status === "completed" && (
          <div className="flex flex-wrap items-center gap-2">
            <div className="me-2 hidden text-end sm:block">
              <p className="text-xs text-muted-foreground">{t("result.overall_accuracy")}</p>
              <p className="text-xl font-bold leading-none">
                <ConfidenceBadge value={job.confidence} className="text-sm" />
              </p>
            </div>
            <Button variant="outline" size="sm" onClick={handleCopy}>
              <Copy className="me-1 h-3.5 w-3.5" /> {t("result.copy")}
            </Button>
            {editing ? (
              <>
                <Button size="sm" onClick={handleSave} disabled={busy}>
                  <Check className="me-1 h-3.5 w-3.5" /> {t("result.save")}
                </Button>
                <Button variant="ghost" size="sm" onClick={() => setEditing(false)}>
                  <X className="me-1 h-3.5 w-3.5" /> {t("common.cancel")}
                </Button>
              </>
            ) : (
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setEditedText(job.text ?? "");
                  setEditing(true);
                }}
              >
                <Pencil className="me-1 h-3.5 w-3.5" /> {t("result.edit")}
              </Button>
            )}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm">
                  <Download className="me-1 h-3.5 w-3.5" /> {t("result.download")}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem asChild>
                  <a href={exportJobUrl(job.id, "txt")} download>
                    <FileText className="me-2 h-4 w-4" /> {t("result.download.txt")}
                  </a>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <a href={exportJobUrl(job.id, "json")} download>
                    <FileJson className="me-2 h-4 w-4" /> {t("result.download.json")}
                  </a>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <a href={exportJobUrl(job.id, "csv")} download>
                    <FileCode className="me-2 h-4 w-4" /> {t("result.download.csv")}
                  </a>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Button variant="outline" size="sm" onClick={() => setReprocessOpen(true)}>
              <RotateCcw className="me-1 h-3.5 w-3.5" /> {t("result.rerun")}
            </Button>
            <Button
              variant={reviewMode ? "default" : "outline"}
              size="sm"
              onClick={() => setReviewMode((v) => !v)}
            >
              <ShieldAlert className="me-1 h-3.5 w-3.5" />
              {t("result.review", { count: lowConfidenceCount })}
            </Button>
            <Button variant="ghost" size="icon" onClick={handleDelete} title={t("result.delete_title")}>
              <Trash2 className="h-4 w-4 text-destructive" />
            </Button>
          </div>
        )}
      </div>

      {/* Processing state */}
      {processing && (
        <Card>
          <CardContent className="flex items-center gap-3 py-8">
            <Loader2 className="h-5 w-5 animate-spin text-primary" />
            <div>
              <p className="font-medium">
                {job.status === "pending" ? t("result.queued") : t("result.processing")}
              </p>
              <p className="text-sm text-muted-foreground">{t("result.processing_hint")}</p>
            </div>
          </CardContent>
        </Card>
      )}

      {job.status === "failed" && (
        <Card className="border-destructive/50">
          <CardContent className="py-6">
            <p className="font-medium text-destructive">{t("result.failed")}</p>
            <p className="mt-1 whitespace-pre-wrap text-sm text-muted-foreground">{job.error}</p>
            <Button variant="outline" size="sm" className="mt-3" onClick={() => setReprocessOpen(true)}>
              <RotateCcw className="me-1 h-3.5 w-3.5" /> {t("result.try_again")}
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Split view */}
      {job.status === "completed" && (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card className="overflow-hidden">
            <div className="flex items-center justify-between gap-2 border-b px-4 py-2">
              <span className="text-sm font-medium text-muted-foreground">{t("result.original")}</span>
              {job.regions.length > 0 && (
                <label
                  className="flex cursor-pointer select-none items-center gap-2 text-xs"
                  title={t("ocr.region.result_overlay")}
                >
                  <span className="inline-flex h-3 w-3 shrink-0 rounded-sm border-2 border-dashed border-cyan-400 bg-cyan-400/10" />
                  <span className="text-muted-foreground">{t("ocr.region.result_overlay")}</span>
                  <Switch checked={showRegionOverlays} onCheckedChange={setShowRegionOverlays} />
                </label>
              )}
            </div>
            <div className="h-[70vh]">
              <DocumentViewer
                job={job}
                hoveredBlockId={hoveredBlockId}
                onHoverBlock={setHoveredBlockId}
                regionOverlays={job.regions}
                showRegionOverlays={showRegionOverlays}
              />
            </div>
          </Card>

          <Card className="overflow-hidden">
            <div className="border-b px-4 py-2 text-sm font-medium text-muted-foreground">
              {reviewMode ? t("result.review_mode") : t("result.extracted")}
            </div>
            <div className="scrollbar-thin h-[70vh] overflow-y-auto p-4">
              {reviewMode ? (
                <ReviewPanel job={job} onHoverBlock={setHoveredBlockId} onSaved={refresh} />
              ) : editing ? (
                <Textarea
                  value={editedText}
                  onChange={(e) => setEditedText(e.target.value)}
                  dir={direction}
                  className={cn("min-h-[62vh] font-mono text-sm", direction === "rtl" && "rtl-text")}
                />
              ) : (
                <ResultTabs job={job} hoveredBlockId={hoveredBlockId} onHoverBlock={setHoveredBlockId} />
              )}
            </div>
          </Card>
        </div>
      )}

      {/* Reprocess dialog */}
      <Dialog open={reprocessOpen} onOpenChange={setReprocessOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t("result.rerun_dialog.title")}</DialogTitle>
            <DialogDescription>{t("result.rerun_dialog.desc")}</DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <p className="text-sm font-medium">{t("ocr.engine")}</p>
            <Select value={reprocessEngine} onValueChange={setReprocessEngine}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {engines
                  .filter((e) => e.status === "READY")
                  .map((e) => (
                    <SelectItem key={e.name} value={e.name}>
                      {engineDisplayName(e.name)}
                    </SelectItem>
                  ))}
                {engines.length === 0 && (
                  <>
                    <SelectItem value="tesseract">Tesseract</SelectItem>
                    <SelectItem value="easyocr">EasyOCR</SelectItem>
                  </>
                )}
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setReprocessOpen(false)}>
              {t("common.cancel")}
            </Button>
            <Button onClick={handleReprocess} disabled={busy}>
              {busy && <Loader2 className="me-1 h-4 w-4 animate-spin" />} {t("result.rerun_dialog.start")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ---------------------------------------------------------------------------

function ResultTabs({
  job,
  hoveredBlockId,
  onHoverBlock,
}: {
  job: JobDetail;
  hoveredBlockId: string | null;
  onHoverBlock: (id: string | null) => void;
}) {
  const { t } = useI18n();
  return (
    <Tabs defaultValue="text">
      <TabsList>
        <TabsTrigger value="text">{t("result.tab.text")}</TabsTrigger>
        <TabsTrigger value="structured">{t("result.tab.structured")}</TabsTrigger>
        <TabsTrigger value="json">{t("result.tab.json")}</TabsTrigger>
        <TabsTrigger value="raw">{t("result.tab.raw")}</TabsTrigger>
      </TabsList>

      <TabsContent value="text" className="mt-4">
        <TextTab job={job} hoveredBlockId={hoveredBlockId} onHoverBlock={onHoverBlock} />
      </TabsContent>
      <TabsContent value="structured" className="mt-4">
        <StructuredTab job={job} />
      </TabsContent>
      <TabsContent value="json" className="mt-4">
        <JsonTab job={job} />
      </TabsContent>
      <TabsContent value="raw" className="mt-4">
        <RawTab job={job} hoveredBlockId={hoveredBlockId} onHoverBlock={onHoverBlock} />
      </TabsContent>
    </Tabs>
  );
}

function TextTab({
  job,
  hoveredBlockId,
  onHoverBlock,
}: {
  job: JobDetail;
  hoveredBlockId: string | null;
  onHoverBlock: (id: string | null) => void;
}) {
  const { t } = useI18n();
  const direction = isRtl(job.language) ? "rtl" : "ltr";
  return (
    <div className="space-y-6">
      {job.pages.map((page) => (
        <div key={page.id}>
          {job.pages.length > 1 && (
            <div className="mb-2 flex items-center gap-2">
              <Badge variant="secondary">{t("result.page", { n: page.page_number })}</Badge>
              <ConfidenceBadge value={page.confidence} />
            </div>
          )}
          <div className="space-y-1">
            {page.blocks.map((block) => (
              <TextLine
                key={block.id}
                block={block}
                active={hoveredBlockId === block.id}
                onHover={onHoverBlock}
                direction={isRtl(block.language) ? "rtl" : direction}
              />
            ))}
          </div>
        </div>
      ))}
      {job.pages.every((p) => p.blocks.length === 0) && (
        <p className="py-8 text-center text-sm text-muted-foreground">{t("result.no_text")}</p>
      )}
    </div>
  );
}

function TextLine({
  block,
  active,
  onHover,
  direction,
}: {
  block: OCRBlock;
  active: boolean;
  onHover: (id: string | null) => void;
  direction: "rtl" | "ltr";
}) {
  const { t } = useI18n();
  const pct = Math.round((block.confidence ?? 0) * 100);
  const level =
    (block.confidence ?? 0) >= 0.9 ? "high" : (block.confidence ?? 0) >= 0.7 ? "medium" : "low";
  return (
    <div
      onMouseEnter={() => onHover(block.id)}
      onMouseLeave={() => onHover(null)}
      className={cn(
        "flex cursor-default items-baseline gap-3 rounded-md px-2 py-1 transition-colors",
        active ? "bg-primary/15 ring-1 ring-primary" : "hover:bg-accent/60"
      )}
      dir={direction}
    >
      <span
        className={cn(
          "w-10 shrink-0 text-end text-xs font-semibold tabular-nums",
          level === "high" && "text-emerald-600 dark:text-emerald-400",
          level === "medium" && "text-amber-600 dark:text-amber-400",
          level === "low" && "text-red-600 dark:text-red-400"
        )}
        dir="ltr"
      >
        {pct}%
      </span>
      {block.region_label && (
        <Badge
          variant="outline"
          dir="ltr"
          className="shrink-0 border-cyan-400/40 px-1.5 text-[10px] font-medium leading-3 text-cyan-600 dark:text-cyan-400"
        >
          {t("ocr.region.block_source", { label: block.region_label })}
        </Badge>
      )}
      <span className={cn("flex-1 break-words leading-relaxed", direction === "rtl" && "rtl-text")}>
        {block.text}
      </span>
    </div>
  );
}

function StructuredTab({ job }: { job: JobDetail }) {
  const { t } = useI18n();
  const fields = job.structured_data?.fields ?? {};
  const tables = job.structured_data?.tables ?? [];
  const fieldEntries = Object.entries(fields);
  const direction = isRtl(job.language) ? "rtl" : "ltr";

  return (
    <div className="space-y-6">
      <div>
        <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
          {t("result.classification")}
        </p>
        <div className="flex items-center gap-2">
          <Badge variant="info">{documentTypeLabel(job.document_type)}</Badge>
          <ConfidenceBadge value={job.document_type_confidence} />
        </div>
      </div>

      <Separator />

      <div>
        <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
          {t("result.fields")}
        </p>
        {fieldEntries.length === 0 ? (
          <p className="text-sm text-muted-foreground">{t("result.no_fields")}</p>
        ) : (
          <dl className="divide-y rounded-lg border">
            {fieldEntries.map(([key, value]) => (
              <div key={key} className="flex gap-4 px-3 py-2 text-sm">
                <dt className="w-40 shrink-0 font-medium text-muted-foreground">
                  {key.replace(/_/g, " ")}
                </dt>
                <dd className={cn("flex-1 break-words", direction === "rtl" && "rtl-text")} dir="auto">
                  {Array.isArray(value) ? value.join(", ") : String(value)}
                </dd>
              </div>
            ))}
          </dl>
        )}
      </div>

      {tables.length > 0 && (
        <>
          <Separator />
          <div className="space-y-4">
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              {t("result.tables", { count: tables.length })}
            </p>
            {tables.map((table, i) => (
              <div key={i} className="overflow-x-auto rounded-lg border">
                <table className="w-full text-sm">
                  <thead className="bg-muted/50">
                    <tr>
                      {table.headers.map((h, j) => (
                        <th key={j} className="border-b px-3 py-2 text-start font-medium" dir="auto">
                          {h || t("result.column", { n: j + 1 })}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {table.rows.map((row, r) => (
                      <tr key={r}>
                        {row.map((cell, c) => (
                          <td key={c} className="px-3 py-2" dir="auto">
                            {cell}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

function JsonTab({ job }: { job: JobDetail }) {
  const payload = useMemo(() => JSON.stringify(job, null, 2), [job]);
  return (
    <pre className="overflow-x-auto rounded-lg bg-muted/50 p-4 text-xs leading-relaxed" dir="ltr">
      {payload}
    </pre>
  );
}

function RawTab({
  job,
  hoveredBlockId,
  onHoverBlock,
}: {
  job: JobDetail;
  hoveredBlockId: string | null;
  onHoverBlock: (id: string | null) => void;
}) {
  const { t } = useI18n();
  return (
    <div className="space-y-6">
      {job.pages.map((page: OCRPage) => (
        <div key={page.id}>
          <div className="mb-2 flex items-center gap-2">
            <Badge variant="secondary">{t("result.page", { n: page.page_number })}</Badge>
            <span className="text-xs text-muted-foreground">
              {t("result.blocks_meta", {
                count: page.blocks.length,
                w: page.width ?? 0,
                h: page.height ?? 0,
              })}
            </span>
          </div>
          <div className="space-y-1">
            {page.blocks.map((b) => (
              <div
                key={b.id}
                onMouseEnter={() => onHoverBlock(b.id)}
                onMouseLeave={() => onHoverBlock(null)}
                className={cn(
                  "rounded-md border px-3 py-2 font-mono text-xs",
                  hoveredBlockId === b.id && "border-primary bg-primary/10"
                )}
              >
                <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-muted-foreground">
                  <span>conf {(b.confidence ?? 0).toFixed(3)}</span>
                  <span>lang {b.language ?? "?"}</span>
                  <span>type {b.block_type}</span>
                  <span dir="ltr">bbox [{b.bbox?.map((v) => Math.round(v)).join(", ") ?? "—"}]</span>
                  {b.region_label && (
                    <Badge
                      variant="outline"
                      dir="ltr"
                      className="border-cyan-400/40 px-1.5 text-[10px] font-medium leading-3 text-cyan-600 dark:text-cyan-400"
                    >
                      {t("ocr.region.block_source", { label: b.region_label })}
                    </Badge>
                  )}
                </div>
                <p className="mt-1 break-words text-sm" dir="auto">
                  {b.text}
                </p>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
