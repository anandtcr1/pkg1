"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { FileImage, FileText, File as FileIcon } from "lucide-react";

import { listJobs } from "@/lib/api";
import { useI18n } from "@/lib/i18n";
import type { TranslationKey } from "@/lib/i18n";
import type { JobSummary } from "@/lib/types";
import { formatBytes, formatDate } from "@/lib/utils";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { JobStatusBadge } from "@/components/job-status-badge";

function fileIcon(mime: string) {
  if (mime === "application/pdf") return FileText;
  if (mime.startsWith("image/")) return FileImage;
  return FileIcon;
}

export default function DocumentsPage() {
  const { t, lang } = useI18n();
  const [jobs, setJobs] = useState<JobSummary[]>([]);
  const [total, setTotal] = useState(0);
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("");
  const [type, setType] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async (query: string, st: string, ty: string) => {
    setLoading(true);
    try {
      const res = await listJobs({ q: query || undefined, status: st || undefined, limit: 60 });
      let items = res.items;
      if (ty) {
        items = items.filter((j) =>
          ty === "pdf" ? j.mime_type === "application/pdf" : j.mime_type.startsWith("image/")
        );
      }
      setJobs(items);
      setTotal(items.length);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load documents");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => load(q, status, type), 300);
    return () => clearTimeout(timer);
  }, [q, status, type, load]);

  const statuses = ["", "completed", "processing", "pending", "failed"];
  const types = ["", "pdf", "image"];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">{t("documents.title")}</h1>
          <p className="text-sm text-muted-foreground">{t("documents.count", { count: total })}</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <select
            className="rounded-md border bg-background px-3 py-2 text-sm"
            value={status}
            onChange={(e) => setStatus(e.target.value)}
            aria-label={t("documents.filter.status")}
          >
            <option value="">{t("documents.filter.status")}: {t("status.all")}</option>
            {statuses.slice(1).map((s) => (
              <option key={s} value={s}>
                {t(`status.${s}` as TranslationKey)}
              </option>
            ))}
          </select>
          <select
            className="rounded-md border bg-background px-3 py-2 text-sm"
            value={type}
            onChange={(e) => setType(e.target.value)}
            aria-label={t("documents.filter.type")}
          >
            <option value="">{t("documents.filter.type")}: {t("status.all")}</option>
            <option value="pdf">PDF</option>
            <option value="image">Image</option>
          </select>
          <Input
            placeholder={t("documents.search")}
            value={q}
            onChange={(e) => setQ(e.target.value)}
            className="w-64"
          />
        </div>
      </div>

      {error && <p className="text-sm text-destructive">{error}</p>}

      {loading ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-28" />
          ))}
        </div>
      ) : jobs.length === 0 ? (
        <div className="rounded-xl border border-dashed py-16 text-center text-sm text-muted-foreground">
          {t("documents.empty")}
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {jobs.map((job) => {
            const Icon = fileIcon(job.mime_type);
            return (
              <Link key={job.id} href={`/ocr/job?id=${job.id}`}>
                <Card className="h-full transition-shadow hover:shadow-md">
                  <CardContent className="flex items-start gap-3 p-4">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                      <Icon className="h-5 w-5 text-primary" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium" title={job.filename}>
                        {job.filename}
                      </p>
                      <p className="mt-0.5 text-xs text-muted-foreground">
                        {formatBytes(job.file_size)} · {job.page_count || "—"} {t("common.pages")} ·{" "}
                        {formatDate(job.created_at, lang)}
                      </p>
                      <div className="mt-2">
                        <JobStatusBadge status={job.status} />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
