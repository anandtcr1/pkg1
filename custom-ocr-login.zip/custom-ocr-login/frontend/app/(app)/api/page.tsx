"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { ExternalLink } from "lucide-react";

import { API_BASE, listEngines } from "@/lib/api";
import { useI18n, type TranslationKey } from "@/lib/i18n";
import type { EngineInfo } from "@/lib/types";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { engineDisplayName } from "@/lib/utils";

const ENDPOINTS: { method: string; path: string; descKey: TranslationKey }[] = [
  { method: "POST", path: "/api/v1/ocr", descKey: "api.ep.create" },
  { method: "GET", path: "/api/v1/ocr/{job_id}", descKey: "api.ep.get" },
  { method: "GET", path: "/api/v1/ocr", descKey: "api.ep.list" },
  { method: "PATCH", path: "/api/v1/ocr/{job_id}", descKey: "api.ep.patch" },
  { method: "DELETE", path: "/api/v1/ocr/{job_id}", descKey: "api.ep.delete" },
  { method: "POST", path: "/api/v1/ocr/{job_id}/reprocess", descKey: "api.ep.reprocess" },
  { method: "GET", path: "/api/v1/ocr/{job_id}/export?format=txt|json|csv", descKey: "api.ep.export" },
  { method: "POST", path: "/api/v1/corrections", descKey: "api.ep.correction" },
  { method: "GET", path: "/api/v1/corrections/export?format=json|csv|jsonl", descKey: "api.ep.corrections_export" },
  { method: "GET", path: "/api/v1/stats/overview", descKey: "api.ep.stats_overview" },
  { method: "GET", path: "/api/v1/stats/charts", descKey: "api.ep.stats_charts" },
  { method: "GET", path: "/api/v1/api-keys", descKey: "api.ep.apikeys" },
  { method: "GET", path: "/api/v1/engines", descKey: "api.ep.engines" },
  { method: "GET", path: "/api/v1/system/health", descKey: "api.ep.system_health" },
  { method: "POST", path: "/api/v1/system/health/check", descKey: "api.ep.system_health_check" },
  { method: "GET", path: "/api/v1/system/resources", descKey: "api.ep.system_resources" },
  { method: "GET", path: "/api/v1/system/storage", descKey: "api.ep.system_storage" },
  { method: "POST", path: "/api/v1/system/maintenance/cleanup", descKey: "api.ep.system_cleanup" },
  { method: "POST", path: "/api/v1/benchmark", descKey: "api.ep.benchmark_create" },
  { method: "GET", path: "/api/v1/benchmark", descKey: "api.ep.benchmark_list" },
];

const METHOD_COLOR: Record<string, "success" | "info" | "warning" | "danger"> = {
  GET: "info",
  POST: "success",
  PATCH: "warning",
  DELETE: "danger",
};

function statusVariant(status: string): "success" | "warning" | "secondary" | "destructive" {
  if (status === "READY") return "success";
  if (status === "MODEL_NOT_INSTALLED") return "warning";
  if (status === "UNAVAILABLE") return "secondary";
  return "destructive";
}

export default function ApiDocsPage() {
  const { t } = useI18n();
  const [engines, setEngines] = useState<EngineInfo[]>([]);

  useEffect(() => {
    listEngines().then(setEngines).catch(() => setEngines([]));
  }, []);

  const curl = `curl -X POST \\
  ${API_BASE}/api/v1/ocr \\
  -H "Authorization: Bearer YOUR_API_KEY" \\
  -F "file=@document.pdf" \\
  -F "language=auto" \\
  -F "detect_tables=true"`;

  const python = `import requests

with open("document.pdf", "rb") as f:
    r = requests.post(
        "${API_BASE}/api/v1/ocr",
        headers={"Authorization": "Bearer YOUR_API_KEY"},
        files={"file": f},
        data={"language": "auto", "detect_tables": "true"},
    )
job = r.json()
print(job["job_id"], job["status"])`;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">{t("api.title")}</h1>
          <p className="text-sm text-muted-foreground">
            {t("api.subtitle")}{" "}
            <code className="rounded bg-muted px-1" dir="ltr">
              {API_BASE}
            </code>
          </p>
        </div>
        <Button variant="outline" asChild>
          <a href={`${API_BASE}/docs`} target="_blank" rel="noreferrer">
            {t("api.swagger")} <ExternalLink className="ms-1 h-4 w-4" />
          </a>
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-sm font-medium">{t("api.engines")}</CardTitle>
          <CardDescription>{t("api.engines_note")}</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          {engines.length === 0 && <span className="text-sm text-muted-foreground">{t("common.loading")}</span>}
          {engines.map((e) => (
            <Badge key={e.name} variant={statusVariant(e.status)}>
              {engineDisplayName(e.name)} · {e.status}
            </Badge>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-sm font-medium">{t("api.endpoints")}</CardTitle>
        </CardHeader>
        <CardContent className="divide-y">
          {ENDPOINTS.map((e) => (
            <div key={`${e.method}-${e.path}`} className="flex items-center gap-3 py-2.5 text-sm">
              <Badge variant={METHOD_COLOR[e.method]} className="w-16 justify-center">
                {e.method}
              </Badge>
              <code className="text-xs sm:text-sm" dir="ltr">
                {e.path}
              </code>
              <span className="ms-auto hidden text-xs text-muted-foreground md:block">{t(e.descKey)}</span>
            </div>
          ))}
        </CardContent>
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium">curl</CardTitle>
          </CardHeader>
          <CardContent>
            <pre className="overflow-x-auto rounded-lg bg-muted/50 p-4 text-xs" dir="ltr">
              {curl}
            </pre>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium">Python</CardTitle>
          </CardHeader>
          <CardContent>
            <pre className="overflow-x-auto rounded-lg bg-muted/50 p-4 text-xs" dir="ltr">
              {python}
            </pre>
          </CardContent>
        </Card>
      </div>

      <p className="text-sm text-muted-foreground">
        {t("api.keys_hint")}{" "}
        <Link href="/settings/api" className="text-primary underline-offset-4 hover:underline">
          {t("api.keys_link")}
        </Link>
        . {t("api.keys_required")}
      </p>
    </div>
  );
}
