import type { NextConfig } from "next";

// Set when IIS hosts the app under a sub-path (IIS application), e.g. BASE_PATH=/ocr.
// Leave unset when the app is the root of its own IIS site.
const basePath = process.env.BASE_PATH?.replace(/\/+$/, "") || undefined;

const nextConfig: NextConfig = {
  // Static export: `npm run build` writes plain HTML/JS/CSS to ./out for IIS.
  output: "export",
  basePath,
  // Emit /history/index.html etc. so IIS serves routes via its default document.
  trailingSlash: true,
  images: { unoptimized: true },
  reactStrictMode: true,
};

export default nextConfig;
