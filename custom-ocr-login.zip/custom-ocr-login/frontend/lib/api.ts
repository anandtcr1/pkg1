import type {
  APIKeyCreated,
  APIKeyOut,
  AppUser,
  AuthMe,
  BenchmarkCreated,
  BenchmarkOut,
  CleanupResult,
  Correction,
  DirectoryUser,
  EngineInfo,
  EnginePerformance,
  JobDetail,
  JobList,
  LanguageInfo,
  LoginResponse,
  OCROptions,
  StatsCharts,
  StatsOverview,
  StorageReport,
  SystemHealth,
  SystemInfo,
  SystemResources,
} from "@/lib/types";

export const API_BASE = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";
// export const API_BASE = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost/ocrapi";
const V1 = `${API_BASE}/api/v1`;

const TOKEN_KEY = "iocr.access_token";
// Set after sign-out or a failed Windows sign-in: don't auto-login again in this browser session.
const SSO_SKIP_KEY = "iocr.sso_skip";
export const AUTH_CHANGED_EVENT = "iocr:auth-changed";

export function getStoredToken(): string | null {
  if (typeof window === "undefined") return null;
  return window.localStorage.getItem(TOKEN_KEY);
}

export function setStoredToken(token: string): void {
  window.localStorage.setItem(TOKEN_KEY, token);
  window.sessionStorage.removeItem(SSO_SKIP_KEY);
  window.dispatchEvent(new Event(AUTH_CHANGED_EVENT));
}

export function clearStoredToken(): void {
  window.localStorage.removeItem(TOKEN_KEY);
  window.sessionStorage.setItem(SSO_SKIP_KEY, "1");
  window.dispatchEvent(new Event(AUTH_CHANGED_EVENT));
}

/**
 * Append the session token for URLs the browser loads directly (downloads,
 * <img>, PDF viewer) — those can't send an Authorization header. The backend
 * accepts the same token as ?api_key=.
 */
export function authUrl(url: string): string {
  const token = getStoredToken();
  if (!token) return url;
  return `${url}${url.includes("?") ? "&" : "?"}api_key=${encodeURIComponent(token)}`;
}

export function isWindowsSsoSkipped(): boolean {
  return window.sessionStorage.getItem(SSO_SKIP_KEY) === "1";
}

export function skipWindowsSso(): void {
  window.sessionStorage.setItem(SSO_SKIP_KEY, "1");
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const headers = new Headers(init?.headers);
  const token = getStoredToken();
  if (token) headers.set("Authorization", `Bearer ${token}`);
  const res = await fetch(`${V1}${path}`, { ...init, headers });
  if (!res.ok) {
    let detail = `Request failed (${res.status})`;
    try {
      const body = await res.json();
      if (body?.detail) detail = typeof body.detail === "string" ? body.detail : JSON.stringify(body.detail);
    } catch {
      // keep default message
    }
    throw new Error(detail);
  }
  if (res.status === 204) return undefined as T;
  return res.json() as Promise<T>;
}

// ---------- Auth ----------

export function login(username: string, password: string): Promise<LoginResponse> {
  return request("/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, password }),
  });
}

export function getAuthMe(): Promise<AuthMe> {
  return request("/auth/me");
}

// ---------- First-run setup ----------

export function getSetupStatus(): Promise<{ setup_required: boolean }> {
  return request("/auth/setup");
}

/** Create the first (local) administrator. Only accepted while no users exist. */
export function createFirstAdmin(username: string, password: string): Promise<{ username: string; is_admin: boolean }> {
  return request("/auth/setup", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, password }),
  });
}

/**
 * Windows integrated sign-in (Kerberos). The browser answers the server's
 * "Negotiate" challenge with the signed-in Windows user's ticket — this only
 * works on domain machines where the API host is trusted for Windows auth.
 * Resolves to null on any failure (not registered, not in AD, no ticket, …).
 */
export async function windowsLogin(timeoutMs = 15000): Promise<LoginResponse | null> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(`${V1}/auth/sso`, { credentials: "include", signal: controller.signal });
    if (!res.ok) return null;
    return (await res.json()) as LoginResponse;
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

// ---------- Users (Active Directory) ----------

export function listUsers(): Promise<AppUser[]> {
  return request("/users");
}

export function searchDirectory(q: string): Promise<DirectoryUser[]> {
  return request(`/users/directory?q=${encodeURIComponent(q)}`);
}

export function addUser(username: string, isAdmin: boolean): Promise<AppUser> {
  return request("/users", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, is_admin: isAdmin }),
  });
}

export function setUserAdmin(id: string, isAdmin: boolean): Promise<AppUser> {
  return request(`/users/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ is_admin: isAdmin }),
  });
}

/** Disable (active=false) or re-enable a user. Users are never deleted. */
export function setUserActive(id: string, active: boolean): Promise<AppUser> {
  return request(`/users/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ is_active: active }),
  });
}

// ---------- OCR jobs ----------

export function uploadDocument(file: File, options: OCROptions): Promise<{ job_id: string; status: string }> {
  const form = new FormData();
  form.append("file", file);
  form.append("options", JSON.stringify(options));
  return request("/ocr", { method: "POST", body: form });
}

export function listJobs(params?: { status?: string; q?: string; limit?: number; offset?: number }): Promise<JobList> {
  const sp = new URLSearchParams();
  if (params?.status) sp.set("status", params.status);
  if (params?.q) sp.set("q", params.q);
  if (params?.limit) sp.set("limit", String(params.limit));
  if (params?.offset) sp.set("offset", String(params.offset));
  const qs = sp.toString();
  return request(`/ocr${qs ? `?${qs}` : ""}`);
}

export function getJob(jobId: string): Promise<JobDetail> {
  return request(`/ocr/${jobId}`);
}

export function updateJob(
  jobId: string,
  payload: { text?: string; pages?: { page_number: number; text: string }[] }
): Promise<JobDetail> {
  return request(`/ocr/${jobId}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
}

export function deleteJob(jobId: string): Promise<void> {
  return request(`/ocr/${jobId}`, { method: "DELETE" });
}

export function reprocessJob(jobId: string, engine?: string): Promise<{ job_id: string; status: string }> {
  return request(`/ocr/${jobId}/reprocess`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(engine ? { engine } : {}),
  });
}

export function exportJobUrl(jobId: string, format: "txt" | "json" | "csv"): string {
  return authUrl(`${V1}/ocr/${jobId}/export?format=${format}`);
}

export function originalFileUrl(jobId: string): string {
  return authUrl(`${V1}/ocr/${jobId}/file`);
}

// ---------- Stats ----------

export function getStatsOverview(): Promise<StatsOverview> {
  return request("/stats/overview");
}

export function getStatsCharts(): Promise<StatsCharts> {
  return request("/stats/charts");
}

export function getEnginePerformance(): Promise<EnginePerformance[]> {
  return request("/stats/engines");
}

export function getSystemInfo(): Promise<SystemInfo> {
  return request("/stats/system");
}

// ---------- Corrections ----------

export function listCorrections(jobId?: string): Promise<Correction[]> {
  return request(`/corrections${jobId ? `?job_id=${jobId}` : ""}`);
}

export function createCorrection(payload: {
  job_id: string;
  page_number: number;
  original_text: string;
  corrected_text: string;
  confidence?: number | null;
  language?: string | null;
  bbox?: number[] | null;
}): Promise<Correction> {
  return request("/corrections", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
}

export function exportCorrectionsUrl(format: "json" | "csv" | "jsonl"): string {
  return authUrl(`${V1}/corrections/export?format=${format}`);
}

// ---------- API keys / engines ----------

export function listApiKeys(): Promise<APIKeyOut[]> {
  return request("/api-keys");
}

export function createApiKey(name: string): Promise<APIKeyCreated> {
  return request("/api-keys", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name }),
  });
}

export function revokeApiKey(id: string): Promise<void> {
  return request(`/api-keys/${id}`, { method: "DELETE" });
}

export function listEngines(): Promise<EngineInfo[]> {
  return request("/engines");
}

export function listLanguages(): Promise<LanguageInfo[]> {
  return request("/languages");
}

// ---------- System Health ----------

export function getSystemHealth(): Promise<SystemHealth> {
  return request("/system/health");
}

export function runSystemHealthCheck(): Promise<SystemHealth> {
  return request("/system/health/check", { method: "POST" });
}

export function getSystemResources(): Promise<SystemResources> {
  return request("/system/resources");
}

export function getStorageReport(): Promise<StorageReport> {
  return request("/system/storage");
}

export function cleanupStorage(targets: ("temp" | "exports" | "logs")[]): Promise<CleanupResult> {
  return request("/system/maintenance/cleanup", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ targets }),
  });
}

// ---------- OCR Lab (benchmarks) ----------

export function createBenchmark(
  file: File,
  opts: { engines?: string[]; ground_truth?: string; language?: string }
): Promise<BenchmarkCreated> {
  const form = new FormData();
  form.append("file", file);
  if (opts.engines?.length) form.append("engines", opts.engines.join(","));
  if (opts.ground_truth) form.append("ground_truth", opts.ground_truth);
  form.append("language", opts.language ?? "auto");
  return request("/benchmark", { method: "POST", body: form });
}

export function listBenchmarks(limit = 20): Promise<BenchmarkOut[]> {
  return request(`/benchmark?limit=${limit}`);
}

export function getBenchmark(benchmarkId: string): Promise<BenchmarkOut> {
  return request(`/benchmark/${benchmarkId}`);
}

export function deleteBenchmark(benchmarkId: string): Promise<void> {
  return request(`/benchmark/${benchmarkId}`, { method: "DELETE" });
}

/** Direct URL to the original benchmark document (image/PDF preview — offline). */
export function benchmarkFileUrl(benchmarkId: string): string {
  return authUrl(`${V1}/benchmark/${benchmarkId}/file`);
}
