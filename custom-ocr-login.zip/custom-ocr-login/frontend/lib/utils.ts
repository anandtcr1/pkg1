import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatBytes(bytes: number): string {
  if (!bytes) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  let value = bytes;
  let i = 0;
  while (value >= 1024 && i < units.length - 1) {
    value /= 1024;
    i++;
  }
  return `${value.toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
}

export function formatPercent(value: number | null | undefined): string {
  if (value === null || value === undefined) return "—";
  return `${(value * 100).toFixed(1)}%`;
}

export function formatSeconds(value: number | null | undefined): string {
  if (value === null || value === undefined) return "—";
  if (value < 1) return `${Math.round(value * 1000)} ms`;
  if (value < 60) return `${value.toFixed(1)} s`;
  const m = Math.floor(value / 60);
  return `${m}m ${Math.round(value % 60)}s`;
}

export function formatDate(value: string | null | undefined, locale?: string): string {
  if (!value) return "—";
  const d = new Date(value);
  return d.toLocaleString(locale, {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function confidenceLevel(c: number | null | undefined): "high" | "medium" | "low" | "none" {
  if (c === null || c === undefined) return "none";
  if (c >= 0.9) return "high";
  if (c >= 0.7) return "medium";
  return "low";
}

export function documentTypeLabel(type: string | null | undefined): string {
  if (!type) return "—";
  return type
    .split("_")
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(" ");
}

// ---------- Engine display naming ----------

export const ENGINE_DISPLAY: Record<string, string> = {
  qari: "QARI-OCR",
  easyocr: "EasyOCR",
  tesseract: "Tesseract",
  wevisdoc: "WeVisDoc",
};

export function engineDisplayName(name: string): string {
  return ENGINE_DISPLAY[name] ?? name.charAt(0).toUpperCase() + name.slice(1);
}

// ---------- Language helpers ----------

const RTL_LANGUAGES = new Set(["ar", "fa", "ur", "he", "mixed"]);

export function isRtl(language: string | null | undefined): boolean {
  return !!language && RTL_LANGUAGES.has(language);
}

export function languageLabel(
  language: string | null | undefined,
  languages: { code: string; name_en: string; name_ar: string }[],
  uiLang: string
): string {
  if (!language) return "—";
  const entry = languages.find((l) => l.code === language);
  if (!entry) return language;
  return uiLang === "ar" ? entry.name_ar : entry.name_en;
}

/** OCR Lab engine tokens: "qari:v0.2" / "qari:v0.3" get versioned labels. */
export function engineVariantLabel(name: string): string {
  if (name === "qari:v0.2") return "QARI-OCR v0.2";
  if (name === "qari:v0.3") return "QARI-OCR v0.3";
  return engineDisplayName(name);
}
