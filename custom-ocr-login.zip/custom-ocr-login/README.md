# IOCR — Intelligence OCR

A production-ready full-stack OCR platform for **Arabic + English** documents.
Upload scans, images, screenshots and PDFs; get editable text with per-line
confidence scores, bounding-box overlays, structured field extraction, table
detection, a low-confidence review workflow and a full REST API.

| | |
|---|---|
| Frontend | Next.js 15 · React 19 · TypeScript · Tailwind CSS · shadcn/ui · PDF.js · Recharts |
| Backend | Python 3.11 · FastAPI · SQLAlchemy · PostgreSQL · Celery + Redis |
| OCR | QARI-OCR (Qwen2-VL) · WeVisDoc · EasyOCR · PaddleOCR · Tesseract — behind one provider interface |

---

## Requirements

- **Docker Desktop** (recommended), or for local development:
  - Python 3.11, Node.js 20+, PostgreSQL 16, Redis 7
  - Tesseract OCR with `ara` + `eng` traineddata and additional language packs as needed (optional but recommended fallback)

## Quick Start (Docker)

```powershell
git clone <repository>
cd custom-ocr
copy .env.example .env
docker compose up -d --build
```

Then open:

- **Frontend** — http://localhost:3000
- **Backend API** — http://localhost:8000
- **FastAPI Swagger** — http://localhost:8000/docs

## Local Development (without Docker)

### 1. Backend

```powershell
cd backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

Create `backend/.env` (or set env vars):

```env
DATABASE_URL=sqlite:///./ocr.db      # or postgresql://ocr:ocr@localhost:5432/ocr
REDIS_URL=redis://localhost:6379/0
WORKER_MODE=inline                   # inline = no Redis/Celery needed
STORAGE_PATH=./storage
OCR_DEFAULT_ENGINE=tesseract
```

Run the API (OCR runs in-process on background threads):

```powershell
uvicorn app.main:app --reload --port 8000
```

For queued processing, set `WORKER_MODE=celery`, start Redis, and run a worker:

```powershell
celery -A app.workers.celery_app:celery worker --loglevel=info --pool=solo
```

### 2. Frontend

```powershell
cd frontend
npm install
$env:NEXT_PUBLIC_API_URL="http://localhost:8000"
npm run dev
```

Open http://localhost:3000.

## OCR Engine Setup

Five engines behind one provider interface: **QARI-OCR**, **WeVisDoc**,
**EasyOCR**, **PaddleOCR** and **Tesseract**. The platform picks the requested
engine and **falls back automatically** (language-aware: Arabic/mixed documents
route to QARI first when its model is installed, otherwise Tesseract → PaddleOCR
→ EasyOCR). Check live availability at `GET /api/v1/engines` or the *API* page
in the UI.

### Tesseract (default fallback)

- **Docker**: preinstalled (`tesseract-ocr-ara`, `tesseract-ocr-eng`).
- **Windows**: install from https://github.com/UB-Mannheim/tesseract/wiki and
  add `C:\Program Files\Tesseract-OCR` to PATH; make sure `ara.traineddata` is
  selected during installation.
- **Linux**: `sudo apt install tesseract-ocr tesseract-ocr-ara tesseract-ocr-eng`

### EasyOCR (second engine)

Enabled by default. The backend installs **CPU-only PyTorch wheels**
(`--extra-index-url https://download.pytorch.org/whl/cpu`), so no CUDA packages
are pulled and behavior is identical between dev and production — no CUDA
version conflicts. `easyocr==1.7.2` is pinned with `torch==2.5.1`
(`backend/requirements/`) and verified end-to-end by the test suite, so the
EasyOCR↔PyTorch pair is reproducible on any host. Models download on first use.

### PaddleOCR (local CPU alternative)

PaddleOCR 3.x (`paddleocr==3.7.0` / CPU-only `paddlepaddle==3.3.1`) is wired in
as a fully **local** engine — no cloud component — with its own Arabic/Latin
recognizers. Model dirs are passed explicitly so PaddleX never queries its
model hub; weights are installed once per [models/README.md](models/README.md)
and missing weights report `MODEL_NOT_INSTALLED`. It covers Latin- and
Arabic-script languages and ranks after Tesseract in auto mode. MKLDNN is
disabled at runtime (a PaddlePaddle 3.3.1 PIR/oneDNN CPU bug verified in this
deployment) in exchange for correctness.

### QARI-OCR (Qwen2-VL — best Arabic quality)

QARI-OCR runs the official **NAMAA-Space** Qwen2-VL-2B-Instruct fine-tunes fully
locally (Qwen2-VL OCR). It reports **no confidence score** (stats/analytics show
"—" for it), supports a QARI Mode (Auto / Printed→v0.2 / Handwritten+Layout→v0.3)
and adds versioned variants to the OCR Lab. Models are **never downloaded**:
install the exact files once per the steps in [models/README.md](models/README.md);
until then the engine reports `MODEL_NOT_INSTALLED` and auto-OCR silently uses a
ready engine.

### Adding a new provider

Subclass `OCRProvider` in `backend/app/providers/ocr/`, register it in that
package's `__init__.py`, and it immediately appears in the UI, the reprocess
dialog and `GET /api/v1/engines`:

```python
class MyVisionProvider(OCRProvider):
    name = "my_engine"
    languages = ["ar", "en"]

    async def extract(self, file_path: str, options: dict) -> OCRResult:
        ...  # call a local / hosted model and map into OCRResult
```

## Multilingual OCR Setup

- The single source of truth for supported languages is
  [`backend/app/services/languages.py`](backend/app/services/languages.py); the UI
  and the `GET /api/v1/languages` endpoint both read from it.
- Built-in languages (26 entries incl. `auto` and `mixed`): English, Arabic,
  Mixed (Arabic + English), Chinese Simplified/Traditional, French, German,
  Spanish, Italian, Portuguese, Dutch, Polish, Swedish, Turkish, Vietnamese,
  Indonesian, Russian, Ukrainian, Persian, Urdu, Hindi, Japanese, Korean, Thai,
  Greek and Hebrew.
- Engine coverage is per-language and reported by `GET /api/v1/engines`:
  - **Tesseract** handles every language (installs one traineddata per language).
  - **EasyOCR** handles all Latin / Arabic / Cyrillic / CJK languages but **not**
    Greek (`el`) or Hebrew (`he`); requests for those fall back to Tesseract.
  - **PaddleOCR** handles Latin- and Arabic-script languages (16 of them) with
    its Latin + Arabic recognizers; other scripts fall back.
  - **QARI** is Arabic specialist (`ar` / `mixed`) only.
- `language: auto` lets the engine detect the script: Tesseract OSD first, then a
  cheap OCR probe (default `eng+ara+chi_sim`) for sparse pages; the final fallback
  is `mixed` (Arabic + English).
- `direction: rtl` is applied automatically for Arabic, Persian, Urdu, Hebrew
  and `mixed`; the frontend mirrors it with `text-align: right`.
- Docker builds install the Tesseract language packs in `backend/Dockerfile`;
  offline installs can provision them with
  `python -m app.tools.download_models --langs en,ar,zh-Hans,...` (see
  [`models/README.md`](models/README.md)).

## Arabic OCR Setup

- All engines ship Arabic content support; QARI-OCR needs its local Qwen2-VL
  weights (see above), Tesseract and EasyOCR cover Arabic out of the box in Docker.
- Documents are auto-classified as `ar`, `en`, `mixed` (or any other configured
  language); the UI switches to `direction: rtl; text-align: right` automatically
  for Arabic output.
- Tesseract runs with the document language plus `eng` (e.g. `ara+eng`) so English
  inside other-language pages still resolves.

## Environment Variables

See [.env.example](.env.example). Key ones:

| Variable | Default | Purpose |
|---|---|---|
| `DATABASE_URL` | `postgresql://ocr:ocr@postgres:5432/ocr` | SQLAlchemy DSN (SQLite works for dev) |
| `REDIS_URL` | `redis://redis:6379/0` | Celery broker/backend |
| `WORKER_MODE` | `celery` (compose) / `inline` | `inline` runs OCR in the API process |
| `OCR_DEFAULT_ENGINE` | `auto` | Default engine for new jobs (`auto` picks by language/availability) |
| `OCR_USE_GPU` | `auto` | `auto` = GPU when CUDA usable, `never` = force CPU |
| `QARI_ENABLED` | `true` | Enable the QARI-OCR engine (full local Qwen2-VL Arabic OCR) |
| `QARI_DEFAULT_VERSION` | `v0.2` | Version used when QARI Mode = auto |
| `QARI_MODEL_DIR` / `QARI_BASE_MODEL_DIR` | empty | Override `MODELS_DIR/qari` and its `base/` adapter root |
| `QARI_MAX_TOKENS` | `2000` | Generation cap per page |
| `WEVISDOC_ENABLED` | `true` | Enable the WeVisDoc engine (Tencent Qwen3-VL-2B/4B page→Markdown parser, optional) |
| `WEVISDOC_MODEL_DIR` | empty | Override `MODELS_DIR/wevisdoc` (holds one WeVisDoc checkpoint) |
| `WEVISDOC_MAX_TOKENS` | `8192` | Generation cap per page; cap-hits without an end token are rejected, not truncated |
| `OCR_WORKER_CONCURRENCY` | `auto` | Celery worker processes; auto = derived from the real CPU budget (cores ∩ cgroup quota ∩ affinity) and RAM |
| `OCR_THREADS_PER_WORKER` | `auto` | Threads per worker; auto = budget / workers, so workers × threads never exceed the budget (set an int to pin) |
| `OCR_RAM_PER_WORKER_GB` | `2.5` | Assumed RAM per worker for auto sizing |
| `HEAVY_INFERENCE_WAIT_S` | `600` | Seconds a heavy generative engine (QARI/WeVisDoc) waits for the exclusive cross-process inference lock before failing with `ENGINE_BUSY` (0 = fail fast) |
| `MAX_UPLOAD_SIZE_MB` | `50` | Upload size cap |
| `STORAGE_PATH` | `/app/storage` | Uploads / processed pages / exports |
| `JWT_SECRET` | `CHANGE_ME` | Token signing secret (e.g. `openssl rand -hex 32`) |
| `REQUIRE_API_KEY` | `false` | When `true`, all `/api/v1/*` calls need a Bearer API key |
| `REQUIRE_AUTH` | `false` | When `true`, a logged-in user (JWT) **or** an API key is required; the web UI shows the `/login` page |
| `ADMIN_USERNAME` | `admin` | Bootstrap administrator account (created automatically on first start) |
| `ADMIN_PASSWORD` | (empty) | Empty = random password generated and printed once in the API logs |
| `JWT_EXPIRES_MINUTES` | `720` | Login session lifetime in minutes |
| `RATE_LIMIT_PER_MINUTE` | `120` | Per-IP API rate limit (0 disables) |
| `NEXT_PUBLIC_API_URL` | `http://localhost:8000` | Frontend → backend base URL (build-time) |

## Authentication

The platform supports two credential types, both fully offline:

1. **User login (username/password)** — branch new accounts from the bootstrap admin
   (`ADMIN_USERNAME` / `ADMIN_PASSWORD`, auto-created on first start; empty password =
   generated and printed once in the API logs). `POST /api/v1/auth/login` returns a JWT
   (`Authorization: Bearer <token>`). `GET /api/v1/auth/me` reports the session for the
   frontend guard.
2. **API keys** — for automation and service accounts (Settings → API Keys,
   `GET/POST/DELETE /api/v1/api-keys`).

Set `REQUIRE_AUTH=true` (and/or `REQUIRE_API_KEY=true`) to enforce either. With both off
the default, the API is open and `/auth/me` reports `authenticated: true` (anonymous) so
the web UI does not force a login.

## API Usage

Create a key in **Settings → API Keys**, then:

```bash
curl -X POST \
  http://localhost:8000/api/v1/ocr \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -F "file=@document.pdf" \
  -F "language=auto" \
  -F "detect_tables=true"
# → {"job_id": "…", "status": "pending"}

curl http://localhost:8000/api/v1/ocr/<job_id> \
  -H "Authorization: Bearer YOUR_API_KEY"
```

Other endpoints: `GET /api/v1/ocr` (history) · `PATCH /api/v1/ocr/{id}` (save edits) ·
`DELETE /api/v1/ocr/{id}` · `POST /api/v1/ocr/{id}/reprocess` ·
`GET /api/v1/ocr/{id}/export?format=txt|json|csv` ·
`POST /api/v1/corrections` · `GET /api/v1/corrections/export?format=json|csv|jsonl` ·
`GET /api/v1/stats/overview|charts` · `GET/POST/DELETE /api/v1/api-keys` ·
`POST /api/v1/auth/login` (user session) · `GET /api/v1/auth/me` (session probe) ·
`GET /api/v1/engines`. Full schemas: http://localhost:8000/docs

## Project Architecture

```
custom-ocr/
├── frontend/                    # Next.js 15 (App Router)
│   ├── app/
│   │   ├── page.tsx             # Dashboard (live stats + charts)
│   │   ├── ocr/page.tsx         # Upload workspace (dropzone + options)
│   │   ├── ocr/[jobId]/page.tsx # Split-view result (doc + text, tabs, review)
│   │   ├── documents/  history/ # File grid / full job table
│   │   ├── analytics/           # 5 charts, all from DB
│   │   ├── api/                 # REST docs + engine status
│   │   └── settings/  settings/api/  # Theme, dataset export, API keys
│   ├── components/              # shadcn/ui + viewer/overlay/review components
│   └── lib/  hooks/             # Typed API client, poll hook
├── backend/
│   └── app/
│       ├── api/v1/              # ocr, stats, corrections, api-keys, engines
│       ├── core/                # config, db, security (API keys, JWT), rate limit
│       ├── models/  schemas/    # SQLAlchemy / Pydantic
│       ├── providers/ocr/       # base interface + qari/easyocr/tesseract
│       ├── services/            # pipeline, preprocessing, classify, extraction,
│       │                        # tables, export, stats
│       ├── storage/             # StorageProvider (local now; S3/R2/MinIO-ready)
│       └── workers/             # Celery app + OCR task
├── storage/{uploads,processed,exports}/
└── docker-compose.yml           # frontend, backend, worker, postgres, redis
```

**Pipeline:** upload → validate (extension + MIME + magic bytes) → PDF pages
rasterized at 200 DPI → auto-rotate (OSD) → deskew → denoise → contrast →
OCR → per-block bbox + confidence → language detection → document
classification → structured field extraction → (optional) table detection →
PostgreSQL. Everything runs in a Celery worker; the API never blocks.

## Performance & Hardware Adaptation

- **Adaptive engines**: EasyOCR auto-detects CUDA (`OCR_USE_GPU`) and runs with
  PyTorch on GPU hosts; Tesseract always runs on CPU.
- **Parallelism**: worker count and per-worker thread budget are derived from the
  effective CPU budget (host cores ∩ cgroup quota ∩ affinity) so
  `workers × threads ≈ budget` — no CFS throttling and no idle cores.
  Override with `OCR_WORKER_CONCURRENCY` / `OCR_THREADS_PER_WORKER`.
- **Monitoring**: `GET /api/v1/stats/engines` (per-engine avg time/confidence)
  and `GET /api/v1/stats/system` (CPU/GPU/platform) power the Analytics page.

## Security Notes

- UUID filenames, path-traversal guards, magic-byte validation, size caps.
- Uploads are never executed; PDFs are rasterized by PyMuPDF, images by OpenCV.
- API keys are stored SHA-256-hashed; the plain key is shown once.
- In-memory per-IP rate limiting middleware (`RATE_LIMIT_PER_MINUTE`).
- Passwords are bcrypt-hashed; API keys stored as SHA-256 hashes; login JWTs signed with `JWT_SECRET`.
- Set `REQUIRE_AUTH=true` or `REQUIRE_API_KEY=true` and change `JWT_SECRET` before exposing publicly.

## Troubleshooting

| Problem | Fix |
|---|---|
| `No OCR engine available` | Rebuild backend image; or install Tesseract locally as a baseline fallback |
| Job stuck in `pending` | Worker down — `docker compose logs worker`; for local dev use `WORKER_MODE=inline` |
| First EasyOCR job is slow | Weights load from `MODELS_DIR` on first use; subsequent jobs are fast |
| `docker compose` fails to connect to daemon | Start **Docker Desktop** first and wait for the whale icon to turn steady |
| Frontend can't reach API | Check `NEXT_PUBLIC_API_URL` build arg; CORS origins include `http://localhost:3000` |
| Tesseract `ara` errors | Arabic traineddata missing — install `tesseract-ocr-ara` |
| EasyOCR import error | It's optional: uncomment it in `requirements.txt` first |
| 429 responses | Raise `RATE_LIMIT_PER_MINUTE` or set to `0` |
