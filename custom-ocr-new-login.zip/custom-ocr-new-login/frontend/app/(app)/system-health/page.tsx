"use client";

import { useCallback, useEffect, useState } from "react";
import { Activity, Cpu, Database, HardDrive, Loader2, MemoryStick, RefreshCw } from "lucide-react";

import { getSystemHealth, getSystemResources, runSystemHealthCheck } from "@/lib/api";
import { useI18n } from "@/lib/i18n";
import type { EngineInfo, SystemHealth, SystemResources } from "@/lib/types";
import { formatBytes, engineDisplayName } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

function engineBadge(status: string): { label: string; variant: "success" | "warning" | "destructive" } {
  if (status === "READY") return { label: "READY", variant: "success" };
  if (status === "ERROR") return { label: "ERROR", variant: "destructive" };
  return { label: "WARNING", variant: "warning" };
}

function formatDate(value: string | null): string {
  if (!value) return "—";
  try {
    return new Date(value).toLocaleString();
  } catch {
    return "—";
  }
}

export default function SystemHealthPage() {
  const { t } = useI18n();
  const [health, setHealth] = useState<SystemHealth | null>(null);
  const [resources, setResources] = useState<SystemResources | null>(null);
  const [running, setRunning] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const [h, r] = await Promise.all([getSystemHealth(), getSystemResources().catch(() => null)]);
      setHealth(h);
      setResources(r);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load system health");
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const runCheck = async () => {
    setRunning(true);
    setError(null);
    try {
      setHealth(await runSystemHealthCheck());
    } catch (err) {
      setError(err instanceof Error ? err.message : "Health check failed");
    } finally {
      setRunning(false);
    }
  };

  if (error && !health) {
    return (
      <div className="space-y-6">
        <h1 className="text-2xl font-bold tracking-tight">{t("health.title")}</h1>
        <p className="text-sm text-destructive">{error}</p>
      </div>
    );
  }

  const offline = health?.offline;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">{t("health.title")}</h1>
          <p className="text-sm text-muted-foreground">{t("health.subtitle")}</p>
        </div>
        <Button onClick={runCheck} disabled={running}>
          {running ? <Loader2 className="me-1 h-4 w-4 animate-spin" /> : <RefreshCw className="me-1 h-4 w-4" />}
          {running ? t("health.checking") : t("health.run_check")}
        </Button>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        {/* Offline / storage */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-sm font-medium">
              <Activity className="h-4 w-4 text-muted-foreground" /> {t("health.offline_mode")}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            {offline ? (
              <>
                <Row label={t("health.offline_mode")} value={offline.offline_mode ? t("dashboard.status.offline") : t("dashboard.status.online")} ok={offline.offline_mode} />
                <Row label={t("health.network_access")} value={offline.network_access ? "true" : "false"} ok={!offline.network_access} />
                <Row label={t("health.network_guard")} value={offline.network_guard_active ? "✓" : "—"} ok={offline.network_guard_active} />
                <Row label={t("health.auto_download")} value={offline.auto_download_models ? "true" : "false"} ok={!offline.auto_download_models} />
                <Row label={t("health.telemetry")} value={offline.telemetry ? "true" : "false"} ok={!offline.telemetry} />
                <Row label={t("health.model_source")} value={offline.model_source} />
                <Row label={t("health.models_dir")} value={offline.models_dir_exists ? offline.models_dir : `${offline.models_dir} ✗`} ok={offline.models_dir_exists} />
              </>
            ) : (
              <Skeleton className="h-40 w-full" />
            )}
          </CardContent>
        </Card>

        {/* Database / queue / disk */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-sm font-medium">
              <Database className="h-4 w-4 text-muted-foreground" /> {t("health.db")} · {t("health.queue")}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            {health ? (
              <>
                <Row label={t("health.env")} value={health.app_env} />
                <Row label={t("health.server")} value={`v${health.version}`} />
                <Row label={t("health.db")} value={health.database} ok={health.database === "ok"} />
                <Row label={t("health.queue")} value={health.queue === "ok" ? t("health.ok") : health.queue} ok={health.queue === "ok"} />
                <Row label={t("health.lab_enabled")} value={health.lab_enabled ? "✓" : "—"} ok={health.lab_enabled} />
                <Row label={t("health.swagger_enabled")} value={health.swagger_enabled ? "✓" : "—"} />
              </>
            ) : (
              <Skeleton className="h-40 w-full" />
            )}
          </CardContent>
        </Card>

        {/* Resources */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-sm font-medium">
              <Cpu className="h-4 w-4 text-muted-foreground" /> {t("system.cpu")} · {t("system.memory")}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            {resources ? (
              <>
                <Row
                  label={t("system.cpu")}
                  value={`${resources.cpu_cores} cores${
                    resources.cpu_host_cores && resources.cpu_host_cores !== resources.cpu_cores
                      ? ` (${resources.cpu_budget_cores ?? resources.cpu_cores}/${resources.cpu_host_cores} budget)`
                      : ""
                  } · ${Math.round(resources.cpu_percent)}%`}
                />
                <Row
                  label={t("system.memory")}
                  value={
                    resources.memory.total > 0
                      ? t("system.ram_used", {
                          used: formatBytes(resources.memory.used),
                          total: formatBytes(resources.memory.total),
                        })
                      : t("system.memory_unavailable")
                  }
                />
                <Row label={t("system.gpu")} value={resources.gpu ? `${resources.gpu.name} (${resources.gpu.device})` : t("analytics.gpu.unavailable")} ok={!!resources.gpu} />
                <Row
                  label={t("system.workers")}
                  value={t("system.workers", {
                    count: resources.worker_count,
                    threads: resources.threads_per_worker,
                  })}
                />
                {resources.avg_processing_time != null && (
                  <Row label={t("jobs.time")} value={`${resources.avg_processing_time.toFixed(2)}s · p50 ${(resources.p50_processing_time ?? 0).toFixed(2)}s · p95 ${(resources.p95_processing_time ?? 0).toFixed(2)}s`} />
                )}
              </>
            ) : (
              <Skeleton className="h-40 w-full" />
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-sm font-medium">
            <HardDrive className="h-4 w-4 text-muted-foreground" /> {t("health.disk_free")}
          </CardTitle>
          <CardDescription>
            {health ? `${formatBytes(health.disk_free_mb * 1024 * 1024)} free` : "—"}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <MemoryStick className="h-4 w-4" />
            <span className="text-xs">{!resources?.queue_length ? t("health.inline") : `${resources.queue_length} queued / ${resources.active_jobs} active / ${resources.pending_jobs} pending`}</span>
          </div>
        </CardContent>
      </Card>

      {/* Engines */}
      <Card>
        <CardHeader className="flex items-center justify-between space-y-0">
          <CardTitle className="flex items-center gap-2 text-sm font-medium">
            <HardDrive className="h-4 w-4 text-muted-foreground" /> {t("health.engines")}
          </CardTitle>
          <span className="text-xs text-muted-foreground">
            {health ? t("health.engines_ready", { count: health.engines.filter((e) => e.status === "READY").length }) : ""}
          </span>
        </CardHeader>
        <CardContent className="space-y-4">
          {health ? (
            health.engines.map((e) => <EngineRow key={e.name} engine={e} />)
          ) : (
            <Skeleton className="h-32 w-full" />
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function lastCheckLabel(status: string): string {
  const s = (status ?? "").toLowerCase();
  if (s === "ok") return "OK";
  if (s === "fail" || s === "failed") return "FAILED";
  return "SKIPPED";
}

function Row({ label, value, ok }: { label: string; value: string; ok?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-2">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-medium" dir="auto">
        {value}
      </span>
    </div>
  );
}

function EngineRow({ engine }: { engine: EngineInfo }) {
  const { t } = useI18n();
  return (
    <div className="rounded-lg border p-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Badge variant={engineBadge(engine.status).variant}>{engineBadge(engine.status).label}</Badge>
          <span className="text-sm font-medium">{engineDisplayName(engine.name)}</span>
          {engine.version && <span className="text-xs text-muted-foreground">v{engine.version}</span>}
        </div>
        <span className="text-xs text-muted-foreground" dir="auto">
          {t("health.engine.device")}: {engine.device}
        </span>
      </div>
      <div className="mt-2 grid gap-1 text-xs text-muted-foreground">
        {engine.reason && <p className="text-amber-600 dark:text-amber-400">{engine.reason}</p>}
        {engine.model_path && (
          <p className="truncate" dir="auto">
            {t("health.engine.model_path")}: {engine.model_path}
          </p>
        )}
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
          <span>{t("health.engine.model_source")}: {engine.model_source || "local"}</span>
          <span>
            {t("health.engine.network_required")}:{" "}
            {engine.internet_required ? t("health.engine.network.yes") : t("health.engine.network.no")}
          </span>
        </div>
        <p>
          {t("health.engine.last_check")}:{" "}
          {engine.last_check
            ? `${lastCheckLabel(engine.last_check.status)} — ${formatDate(engine.last_check.checked_at ?? null)}`
            : "—"}
          {engine.last_check?.text_sample ? ` · “${engine.last_check.text_sample.slice(0, 24)}…”` : ""}
        </p>
      </div>
    </div>
  );
}