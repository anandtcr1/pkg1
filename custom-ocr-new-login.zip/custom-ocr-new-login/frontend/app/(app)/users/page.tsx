"use client";

import { useCallback, useEffect, useState } from "react";
import { Plus, Search, ShieldCheck, ShieldOff, Trash2, UserPlus, Users } from "lucide-react";
import { toast } from "sonner";

import { addUser, listUsers, removeUser, searchDirectory, setUserAdmin } from "@/lib/api";
import { useI18n } from "@/lib/i18n";
import type { AppUser, DirectoryUser } from "@/lib/types";
import { formatDate } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";

export default function UsersPage() {
  const { t, lang } = useI18n();
  const [users, setUsers] = useState<AppUser[] | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [open, setOpen] = useState(false);

  const load = useCallback(async () => {
    try {
      setUsers(await listUsers());
      setLoadError(null);
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : t("users.load_failed"));
      setUsers([]);
    }
  }, [t]);

  useEffect(() => {
    load();
  }, [load]);

  const handleRole = async (u: AppUser) => {
    try {
      await setUserAdmin(u.id, !u.is_admin);
      toast.success(t("users.role_updated"));
      load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("users.action_failed"));
    }
  };

  const handleRemove = async (u: AppUser) => {
    if (!confirm(t("users.remove_confirm", { user: u.display_name || u.username || "" }))) return;
    try {
      await removeUser(u.id);
      toast.success(t("users.removed"));
      load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("users.action_failed"));
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">{t("users.title")}</h1>
          <p className="text-sm text-muted-foreground">{t("users.subtitle")}</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="me-1 h-4 w-4" /> {t("users.add")}
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DirectorySearch
              onAdded={() => {
                load();
              }}
            />
          </DialogContent>
        </Dialog>
      </div>

      {loadError && (
        <p className="rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive">
          {loadError}
        </p>
      )}

      <Card>
        <CardContent className="overflow-x-auto p-0">
          {users === null ? (
            <div className="space-y-2 p-6">
              {Array.from({ length: 3 }).map((_, i) => (
                <Skeleton key={i} className="h-10 w-full" />
              ))}
            </div>
          ) : users.length === 0 ? (
            <div className="flex flex-col items-center py-14 text-center">
              <Users className="h-8 w-8 text-muted-foreground" />
              <p className="mt-2 text-sm text-muted-foreground">{t("users.empty")}</p>
            </div>
          ) : (
            <table className="w-full text-sm">
              <thead className="border-b bg-muted/50 text-xs uppercase text-muted-foreground">
                <tr>
                  <th className="px-4 py-3 text-start">{t("common.name")}</th>
                  <th className="px-4 py-3 text-start">{t("users.login")}</th>
                  <th className="px-4 py-3 text-start">{t("users.email")}</th>
                  <th className="px-4 py-3 text-start">{t("users.source")}</th>
                  <th className="px-4 py-3 text-start">{t("users.role")}</th>
                  <th className="px-4 py-3 text-start">{t("common.created")}</th>
                  <th className="px-4 py-3 text-end">{t("common.actions")}</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {users.map((u) => {
                  const local = u.auth_source === "local";
                  return (
                    <tr key={u.id}>
                      <td className="px-4 py-3 font-medium">{u.display_name || "—"}</td>
                      <td className="px-4 py-3">
                        <code className="text-xs" dir="ltr">
                          {u.username}
                        </code>
                      </td>
                      <td className="px-4 py-3 text-muted-foreground" dir="ltr">
                        {u.email || "—"}
                      </td>
                      <td className="px-4 py-3">
                        {local ? (
                          <Badge variant="warning">{t("users.source.local")}</Badge>
                        ) : (
                          <Badge variant="info">{t("users.source.ldap")}</Badge>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        {u.is_admin ? (
                          <Badge variant="success">{t("auth.admin")}</Badge>
                        ) : (
                          <Badge variant="secondary">{t("auth.user")}</Badge>
                        )}
                      </td>
                      <td className="px-4 py-3 text-muted-foreground">{formatDate(u.created_at, lang)}</td>
                      <td className="whitespace-nowrap px-4 py-3 text-end">
                        <Button
                          variant="ghost"
                          size="icon"
                          disabled={local}
                          onClick={() => handleRole(u)}
                          title={u.is_admin ? t("users.make_user") : t("users.make_admin")}
                        >
                          {u.is_admin ? <ShieldOff className="h-4 w-4" /> : <ShieldCheck className="h-4 w-4" />}
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          disabled={local}
                          onClick={() => handleRemove(u)}
                          title={t("users.remove")}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function DirectorySearch({ onAdded }: { onAdded: () => void }) {
  const { t } = useI18n();
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<DirectoryUser[] | null>(null);
  const [searching, setSearching] = useState(false);
  const [asAdmin, setAsAdmin] = useState(false);
  const [adding, setAdding] = useState<string | null>(null);

  const runSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    const q = query.trim();
    if (q.length < 2 || searching) return;
    setSearching(true);
    try {
      setResults(await searchDirectory(q));
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("users.search_failed"));
      setResults(null);
    } finally {
      setSearching(false);
    }
  };

  const handleAdd = async (u: DirectoryUser) => {
    setAdding(u.username);
    try {
      await addUser(u.username, asAdmin);
      toast.success(`${t("users.added")} — ${u.display_name || u.username}`);
      setResults((rs) => rs?.map((r) => (r.username === u.username ? { ...r, registered: true } : r)) ?? null);
      onAdded();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("users.add_failed"));
    } finally {
      setAdding(null);
    }
  };

  return (
    <>
      <DialogHeader>
        <DialogTitle>{t("users.dialog.title")}</DialogTitle>
        <DialogDescription>{t("users.dialog.desc")}</DialogDescription>
      </DialogHeader>
      <form onSubmit={runSearch} className="flex gap-2">
        <Input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={t("users.dialog.placeholder")}
          autoFocus
          dir="ltr"
        />
        <Button type="submit" disabled={searching || query.trim().length < 2}>
          <Search className="me-1 h-4 w-4" /> {t("common.search")}
        </Button>
      </form>
      <div className="flex items-center gap-2">
        <Checkbox id="as-admin" checked={asAdmin} onCheckedChange={(v) => setAsAdmin(v === true)} />
        <Label htmlFor="as-admin" className="text-sm font-normal">
          {t("users.dialog.as_admin")}
        </Label>
      </div>
      <div className="max-h-80 overflow-y-auto rounded-md border">
        {searching ? (
          <div className="space-y-2 p-4">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-10 w-full" />
            ))}
          </div>
        ) : results === null ? null : results.length === 0 ? (
          <p className="py-8 text-center text-sm text-muted-foreground">{t("users.dialog.no_results")}</p>
        ) : (
          <ul className="divide-y">
            {results.map((u) => (
              <li key={u.username} className="flex items-center justify-between gap-3 px-3 py-2">
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium">{u.display_name || u.username}</p>
                  <p className="truncate text-xs text-muted-foreground" dir="ltr">
                    {[u.username, u.email, u.department, u.title].filter(Boolean).join(" · ")}
                  </p>
                </div>
                {u.registered ? (
                  <Badge variant="secondary">{t("users.registered")}</Badge>
                ) : (
                  <Button size="sm" variant="outline" disabled={adding !== null} onClick={() => handleAdd(u)}>
                    <UserPlus className="me-1 h-4 w-4" /> {t("users.add")}
                  </Button>
                )}
              </li>
            ))}
          </ul>
        )}
      </div>
    </>
  );
}
