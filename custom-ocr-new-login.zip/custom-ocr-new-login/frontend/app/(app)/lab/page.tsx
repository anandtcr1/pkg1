"use client";

import { Fragment, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ChevronDown, ExternalLink, FileText, Info, Loader2, Trash2, Upload } from "lucide-react";
import { toast } from "sonner";

import {
  benchmarkFileUrl,
  createBenchmark,
  deleteBenchmark,
  getSystemHealth,
  listBenchmarks,
  listLanguages,
} from "@/lib/api";
import { useI18n } from "@/lib/i18n";
import type { BenchmarkOut, BenchmarkResultRow, EngineInfo, LanguageInfo } from "@/lib/types";
import {
  engineDisplayName,
  engineVariantLabel,
  formatBytes,
  formatDate,
  formatPercent,
  formatSeconds,
  languageLabel,
} from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";

type HealthEngine = EngineInfo & { lab_enabled?: boolean };

interface EngineChoice {
  key: string;
  label: string;
  version: string | null;
  device: string;
  isQariVariant: boolean;
}

function resultStatusVariant(status: string): "success" | "destructive" {
  return status === "OK" ? "success" : "destructive";
}

function benchStatusVariant(status: string): "success" | "warning" | "destructive" | "secondary" {
  if (status === "completed") return "success";
  if (status === "failed") return "destructive";
  return "secondary";
}

function deviceLabel(device: string | null | undefined): string {
  if (!device) return "";
  const d = device.toLowerCase();
  if (d === "cuda" || d === "gpu") return "GPU";
  if (d === "cpu") return "CPU";
  return device;
}

function readyLabEngines(engines: HealthEngine[]): HealthEngine[] {
  return engines.filter((e) => e.status === "READY" && e.lab_enabled === true);
}

function buildChoices(engines: HealthEngine[]): EngineChoice[] {
  const choices: EngineChoice[] = [];
  for (const e of engines) {
    if (e.name === "qari") {
      const versions = (e.details?.versions as unknown) ?? [];
      const installed = Array.isArray(versions)
        ? versions.filter((v): v is string => typeof v === "string")
        : [];
      if (installed.length > 0) {
        for (const ver of installed) {
          const key = `qari:${ver}`;
          choices.push({
            key,
            label: engineVariantLabel(key),
            version: ver,
            device: e.device,
            isQariVariant: true,
          });
        }
      } else {
        choices.push({
          key: "qari",
          label: engineDisplayName("qari"),
          version: e.version,
          device: e.device,
          isQariVariant: false,
        });
      }
    } else {
      choices.push({
        key: e.name,
        label: engineDisplayName(e.name),
        version: e.version,
        device: e.device,
        isQariVariant: false,
      });
    }
  }
  return choices;
}

function benchDuration(benchmark: BenchmarkOut): number | undefined {
  if (!benchmark.created_at || !benchmark.completed_at) return undefined;
  const start = new Date(benchmark.created_at).getTime();
  const end = new Date(benchmark.completed_at).getTime();
  if (Number.isNaN(start) || Number.isNaN(end)) return undefined;
  return Math.max(0, (end - start) / 1000);
}

function isPdfBenchmark(benchmark: BenchmarkOut): boolean {
  return /pdf/i.test(benchmark.mime_type || benchmark.filename);
}

export default function OcRLabPage() {
  const { t, lang } = useI18n();
  const [enabled, setEnabled] = useState<boolean | null>(null);
  const [healthEngines, setHealthEngines] = useState<HealthEngine[]>([]);
  const [selected, setSelected] = useState<string[]>([]);
  const [file, setFile] = useState<File | null>(null);
  const [groundTruth, setGroundTruth] = useState("");
  const [language, setLanguage] = useState("auto");
  const [languages, setLanguages] = useState<LanguageInfo[]>([]);
  const [running, setRunning] = useState(false);
  const [benchmarks, setBenchmarks] = useState<BenchmarkOut[]>([]);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const pollTimer = useRef<ReturnType<typeof setInterval> | null>(null);

  const choices = useMemo(() => buildChoices(healthEngines), [healthEngines]);
  const hasQari = choices.some((c) => c.isQariVariant || c.key === "qari");

  const loadBenchmarks = useCallback(async (alertOnFail?: boolean) => {
    try {
      const rows = await listBenchmarks(15);
      setBenchmarks(rows);
      if (rows.some((b) => b.status === "pending" || b.status === "processing")) {
        if (!pollTimer.current) {
          pollTimer.current = setInterval(loadBenchmarks, 2000);
        }
      }
    } catch {
      if (alertOnFail) setEnabled(false);
    }
  }, []);

  useEffect(() => {
    getSystemHealth()
      .then((h) => {
        setEnabled(h.lab_enabled);
        const avail = readyLabEngines(h.engines as HealthEngine[]);
        setHealthEngines(avail);
        setSelected(buildChoices(avail).map((c) => c.key));
      })
      .catch(() => setEnabled(false));
    loadBenchmarks();
    listLanguages()
      .then((list) => setLanguages(list))
      .catch(() => setLanguages([]));
    return () => {
      if (pollTimer.current) clearInterval(pollTimer.current);
    };
  }, [loadBenchmarks]);

  useEffect(() => {
    const active = benchmarks.find((b) => b.status === "pending" || b.status === "processing");
    if (!active && pollTimer.current) {
      clearInterval(pollTimer.current);
      pollTimer.current = null;
    }
  }, [benchmarks]);

  const startBenchmark = async () => {
    if (!file) {
      toast.error(t("lab.run_failed"));
      return;
    }
    if (selected.length === 0) {
      toast.error(t("lab.run_failed"));
      return;
    }
    setRunning(true);
    try {
      const created = await createBenchmark(file, {
        engines: selected,
        ground_truth: groundTruth || undefined,
        language,
      });
      toast.success(`Benchmark ${created.benchmark_id.slice(0, 8)}… queued`);
      await loadBenchmarks();
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      if (msg.includes("403")) setEnabled(false);
      toast.error(`${t("lab.run_failed")}: ${msg}`);
    } finally {
      setRunning(false);
      setFile(null);
    }
  };

  const removeBenchmark = async (benchmarkId: string) => {
    if (!confirm(t("lab.delete_confirm"))) return;
    try {
      await deleteBenchmark(benchmarkId);
      setExpandedId((id) => (id === benchmarkId ? null : id));
      await loadBenchmarks();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Delete failed");
    }
  };

  if (enabled === null) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">{t("lab.title")}</h1>
          <p className="text-sm text-muted-foreground">{t("lab.subtitle")}</p>
        </div>
        <div className="grid gap-6 lg:grid-cols-[340px_1fr]">
          <Skeleton className="h-[480px] w-full" />
          <Skeleton className="h-[480px] w-full" />
        </div>
      </div>
    );
  }

  if (enabled === false) {
    return (
      <div className="space-y-6">
        <h1 className="text-2xl font-bold tracking-tight">{t("lab.title")}</h1>
        <Card className="border-destructive/50">
          <CardContent className="py-6 text-sm text-destructive">{t("lab.not_enabled")}</CardContent>
        </Card>
      </div>
    );
  }

  const completed = benchmarks.filter((b) => b.status === "completed");
  const latest = completed.slice(0, 3);
  const pending = benchmarks.find((b) => b.status === "pending" || b.status === "processing");

  const languageName = (value: string | null): string =>
    value === "auto" ? t("ocr.lang.auto") : languageLabel(value, languages, lang);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">{t("lab.title")}</h1>
        <p className="text-sm text-muted-foreground">{t("lab.subtitle")}</p>
      </div>

      <div className="flex items-start gap-2 rounded-lg border bg-muted/40 p-3 text-sm text-muted-foreground">
        <Info className="mt-0.5 h-4 w-4 shrink-0" />
        <div className="space-y-1">
          <p>{t("lab.info")}</p>
          <p className="text-xs opacity-80">
            {t("nav.settings")} → {t("nav.system_health")}
          </p>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[340px_1fr]">
        {/* Run form */}
        {choices.length === 0 ? (
          <Card>
            <CardContent className="py-10 text-center">
              <p className="text-sm text-muted-foreground">{t("lab.no_engines")}</p>
              <p className="mt-1 text-xs text-muted-foreground/70">
                {t("nav.settings")} → {t("nav.system_health")}
              </p>
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium">{t("lab.run")}</CardTitle>
              <CardDescription>{t("lab.ground_truth.hint")}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {choices.length < 2 && (
                <p className="rounded-md border border-amber-500/30 bg-amber-500/10 px-3 py-2 text-xs text-amber-700 dark:text-amber-400">
                  {t("lab.two_required")}
                </p>
              )}

              <div className="space-y-2">
                <Label>{t("lab.document")}</Label>
                <label className="flex cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed p-5 text-center text-sm text-muted-foreground hover:border-primary/50">
                  <Upload className="h-5 w-5" />
                  <span className="truncate">{file ? file.name : t("lab.doc_drop")}</span>
                  <input
                    type="file"
                    accept="image/*,.pdf"
                    className="hidden"
                    onChange={(e) => setFile(e.target.files?.[0] ?? null)}
                  />
                </label>
                {file && <p className="text-xs text-muted-foreground">{formatBytes(file.size)}</p>}
              </div>

              <div className="space-y-2">
                <Label>{t("lab.ground_truth")}</Label>
                <Textarea value={groundTruth} onChange={(e) => setGroundTruth(e.target.value)} rows={3} />
              </div>

              <div className="space-y-2">
                <Label>{t("lab.engines")}</Label>
                {hasQari && <p className="text-xs text-muted-foreground">{t("lab.qari.note")}</p>}
                <div className="space-y-1.5">
                  {choices.map((c) => (
                    <div key={c.key} className="flex items-center justify-between gap-2">
                      <label className="flex items-center gap-2 text-sm">
                        <Checkbox
                          checked={selected.includes(c.key)}
                          onCheckedChange={(on) =>
                            setSelected((s) => (on ? [...s, c.key] : s.filter((n) => n !== c.key)))
                          }
                        />
                        <span>{c.label}</span>
                      </label>
                      <span className="shrink-0 text-xs text-muted-foreground">
                        {c.version ? `v${c.version} · ` : ""}
                        {deviceLabel(c.device)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <Label>{t("lab.lang")}</Label>
                <select
                  className="w-full rounded-md border bg-background px-3 py-2 text-sm"
                  value={language}
                  onChange={(e) => setLanguage(e.target.value)}
                >
                  <option value="auto">{t("ocr.lang.auto")}</option>
                  {languages.map((l) => (
                    <option key={l.code} value={l.code}>
                      {lang === "ar" ? l.name_ar : l.name_en}
                    </option>
                  ))}
                </select>
              </div>

              <Button className="w-full" onClick={startBenchmark} disabled={running || !file || selected.length === 0}>
                {running ? <Loader2 className="me-1 h-4 w-4 animate-spin" /> : null}
                {running ? t("lab.running") : t("lab.run")}
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Results */}
        <div className="space-y-6">
          {pending && (
            <Card className="border-primary/30">
              <CardHeader>
                <CardTitle className="text-sm font-medium">
                  {pending.status === "processing" ? t("lab.running") : t("lab.status.queued")} — {pending.filename}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Button variant="outline" size="sm" onClick={() => loadBenchmarks()}>
                  <Loader2 className="me-1 h-4 w-4 animate-spin" /> {t("common.loading")}
                </Button>
              </CardContent>
            </Card>
          )}

          {!pending && latest.length === 0 && (
            <Card>
              <CardContent className="py-16 text-center text-sm text-muted-foreground">
                {t("lab.no_results")}
              </CardContent>
            </Card>
          )}

          {latest.map((b) => (
            <BenchmarkCard key={b.id} benchmark={b} lang={lang} onDelete={() => removeBenchmark(b.id)} />
          ))}

          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium">{t("lab.recent")}</CardTitle>
            </CardHeader>
            <CardContent>
              {benchmarks.length === 0 ? (
                <p className="text-sm text-muted-foreground">{t("lab.no_results")}</p>
              ) : (
                <table className="w-full text-sm">
                  <thead className="bg-muted/50 text-start text-xs uppercase text-muted-foreground">
                    <tr>
                      <th className="px-3 py-2 text-start">{t("jobs.file")}</th>
                      <th className="px-3 py-2 text-start">{t("lab.lang")}</th>
                      <th className="px-3 py-2 text-start">{t("lab.row.engine")}</th>
                      <th className="px-3 py-2 text-start">{t("common.status")}</th>
                      <th className="px-3 py-2 text-start">{t("lab.row.time")}</th>
                      <th className="px-3 py-2 text-end">{t("common.actions")}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {benchmarks.map((b) => {
                      const isCompleted = b.status === "completed";
                      const expanded = expandedId === b.id;
                      const engineList = (b.engines ?? []).map((en) => engineVariantLabel(en));
                      const participating = engineList.join(", ");
                      return (
                        <Fragment key={b.id}>
                          <tr className="hover:bg-muted/40">
                            <td className="px-3 py-2">
                              <div className="flex min-w-0 items-center gap-1">
                                {isCompleted && (
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="h-6 w-6 shrink-0"
                                    title={t("lab.preview")}
                                    onClick={() => setExpandedId(expanded ? null : b.id)}
                                  >
                                    <ChevronDown
                                      className={`h-4 w-4 transition-transform ${expanded ? "rotate-180" : ""}`}
                                    />
                                  </Button>
                                )}
                                <span className="min-w-0 truncate">{b.filename}</span>
                              </div>
                            </td>
                            <td className="px-3 py-2 text-muted-foreground">{languageName(b.language)}</td>
                            <td className="max-w-[220px] px-3 py-2">
                              <span
                                className="block truncate text-muted-foreground"
                                title={participating ? `${t("lab.participating")}: ${participating}` : t("lab.row.na")}
                              >
                                {participating || t("lab.row.na")}
                              </span>
                            </td>
                            <td className="px-3 py-2">
                              <Badge variant={benchStatusVariant(b.status)}>{b.status}</Badge>
                            </td>
                            <td className="px-3 py-2 text-muted-foreground">
                              {formatSeconds(benchDuration(b))}
                            </td>
                            <td className="px-3 py-2 text-end">
                              <Button variant="ghost" size="icon" title={t("lab.delete")} onClick={() => removeBenchmark(b.id)}>
                                <Trash2 className="h-4 w-4 text-destructive" />
                              </Button>
                            </td>
                          </tr>
                          {expanded && (
                            <tr>
                              <td colSpan={6} className="px-3 pb-3">
                                <div className="flex items-start gap-3 rounded-lg border bg-muted/30 p-3">
                                  {isPdfBenchmark(b) ? (
                                    <a
                                      href={benchmarkFileUrl(b.id)}
                                      target="_blank"
                                      rel="noreferrer"
                                      title={t("lab.preview")}
                                      className="flex shrink-0 items-center gap-2 self-center text-sm font-medium underline-offset-4 hover:underline"
                                    >
                                      <FileText className="h-8 w-8 text-muted-foreground" />
                                      <ExternalLink className="h-3.5 w-3.5 text-muted-foreground" />
                                    </a>
                                  ) : (
                                    <a
                                      href={benchmarkFileUrl(b.id)}
                                      target="_blank"
                                      rel="noreferrer"
                                      title={t("lab.preview")}
                                      className="shrink-0"
                                    >
                                      <img
                                        src={benchmarkFileUrl(b.id)}
                                        alt={b.filename}
                                        loading="lazy"
                                        className="max-h-48 w-auto rounded border object-contain"
                                      />
                                    </a>
                                  )}
                                  <div className="min-w-0 flex-1">
                                    <p className="text-xs text-muted-foreground">{t("lab.preview")}</p>
                                    <p className="truncate text-sm font-medium">{b.filename}</p>
                                    <p className="truncate text-xs text-muted-foreground">{b.mime_type}</p>
                                  </div>
                                  {isPdfBenchmark(b) && <Badge variant="secondary">{t("lab.pdf_indicator")}</Badge>}
                                </div>
                              </td>
                            </tr>
                          )}
                        </Fragment>
                      );
                    })}
                  </tbody>
                </table>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

function BenchmarkCard({
  benchmark,
  lang,
  onDelete,
}: {
  benchmark: BenchmarkOut;
  lang: string;
  onDelete: () => void;
}) {
  const { t } = useI18n();
  const rows = benchmark.results ?? [];
  const hasGt = Boolean(benchmark.ground_truth?.trim());

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-sm font-medium">
          {benchmark.filename}
          <span className="ms-2 text-xs font-normal text-muted-foreground">{formatDate(benchmark.created_at, lang)}</span>
        </CardTitle>
        <div className="flex items-center gap-2">
          {!hasGt && <Badge variant="warning">{t("lab.no_gt")}</Badge>}
          <Button variant="ghost" size="icon" onClick={onDelete} title={t("lab.delete")}>
            <Trash2 className="h-4 w-4 text-destructive" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="overflow-x-auto">
        {rows.length === 0 ? (
          <p className="text-sm text-muted-foreground">{t("common.loading")}…</p>
        ) : (
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-start text-xs uppercase text-muted-foreground">
              <tr>
                <th className="px-3 py-2 text-start">{t("lab.row.engine")}</th>
                <th className="px-3 py-2 text-start">{t("lab.row.status")}</th>
                <th className="px-3 py-2 text-start">{t("lab.row.time")}</th>
                <th className="px-3 py-2 text-start" title={t("lab.ram.tooltip")}>
                  {t("lab.row.ram")}
                </th>
                <th className="px-3 py-2 text-start" title={t("lab.cpu.tooltip")}>
                  {t("lab.row.cpu")}
                </th>
                <th className="px-3 py-2 text-start" title={t("lab.confidence.hint")}>
                  {t("lab.row.confidence")}
                </th>
                <th className="px-3 py-2 text-start" title={t("lab.cer_wer.help")}>
                  {t("lab.row.cer")}
                </th>
                <th className="px-3 py-2 text-start" title={t("lab.cer_wer.help")}>
                  {t("lab.row.wer")}
                </th>
                <th className="px-3 py-2 text-start">{t("health.engine.version")}</th>
                <th className="px-3 py-2 text-start">{t("health.engine.device")}</th>
              </tr>
              {!hasGt && (
                <tr>
                  <th colSpan={10} className="px-3 py-1.5 text-start text-xs font-normal text-muted-foreground">
                    {t("lab.no_gt")}
                  </th>
                </tr>
              )}
            </thead>
            <tbody className="divide-y">
              {rows.map((r: BenchmarkResultRow) => (
                <tr key={r.engine} className="hover:bg-muted/40">
                  <td className="px-3 py-2 font-medium">{engineVariantLabel(r.engine)}</td>
                  <td className="px-3 py-2">
                    <Badge
                      variant={resultStatusVariant(r.status)}
                      title={
                        r.status !== "OK" ? `${t("lab.row.reason_failed")}: ${r.reason ?? ""}` : undefined
                      }
                    >
                      {r.status}
                    </Badge>
                  </td>
                  <td className="px-3 py-2 text-muted-foreground">
                    {r.time != null ? formatSeconds(r.time) : t("lab.row.na")}
                  </td>
                  <td className="px-3 py-2 text-muted-foreground">
                    {r.peak_memory_mb != null ? (
                      <span title={t("lab.ram.tooltip")}>{Math.round(r.peak_memory_mb)} MB</span>
                    ) : (
                      t("lab.row.na")
                    )}
                  </td>
                  <td className="px-3 py-2 text-muted-foreground">
                    {r.cpu_percent != null ? (
                      <span title={t("lab.cpu.tooltip")}>{Math.round(r.cpu_percent)}%</span>
                    ) : (
                      t("lab.row.na")
                    )}
                  </td>
                  <td className="px-3 py-2 text-muted-foreground">
                    {r.confidence != null ? formatPercent(r.confidence) : t("lab.row.na")}
                  </td>
                  <td className="px-3 py-2 text-muted-foreground">
                    {r.cer != null ? r.cer.toFixed(4) : t("lab.row.na")}
                  </td>
                  <td className="px-3 py-2 text-muted-foreground">
                    {r.wer != null ? r.wer.toFixed(4) : t("lab.row.na")}
                  </td>
                  <td className="px-3 py-2 text-muted-foreground">{r.version ?? t("lab.row.na")}</td>
                  <td className="px-3 py-2 text-muted-foreground">
                    {r.device ? deviceLabel(r.device) : t("lab.row.na")}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </CardContent>
    </Card>
  );
}