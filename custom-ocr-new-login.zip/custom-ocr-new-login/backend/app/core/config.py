import os
from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # ---- Profile ----
    APP_ENV: str = "development"  # development | production

    # ---- Database / queue ----
    DATABASE_URL: str = "sqlite:///./ocr.db"
    REDIS_URL: str = "redis://localhost:6379/0"
    WORKER_MODE: str = "inline"  # celery | inline

    # ---- Offline / air-gapped operation (mandatory) ----
    OFFLINE_MODE: bool = True
    NETWORK_ACCESS: bool = False  # false = outbound sockets to public networks are blocked in-process
    MODEL_SOURCE: str = "local"
    TELEMETRY: bool = False
    AUTO_DOWNLOAD_MODELS: bool = False  # never silently download a missing model
    MODELS_DIR: str = "./models"

    # ---- OCR engines ----
    OCR_DEFAULT_ENGINE: str = "auto"  # auto | tesseract | easyocr | qari | wevisdoc | paddle
    OCR_USE_GPU: str = "auto"  # auto | always | never
    TESSERACT_MODE: str = "speed"  # speed (tessdata_fast) | accuracy (tessdata_best)

    # ---- QARI (Qwen2-VL Arabic OCR) ----
    # 100% local: models must exist under QARI_MODEL_DIR. Nothing is ever
    # downloaded at runtime; missing models report MODEL_NOT_INSTALLED.
    QARI_ENABLED: bool = True
    QARI_MODEL_DIR: str = ""  # default: <MODELS_DIR>/qari
    QARI_DEFAULT_VERSION: str = "v0.2"  # auto | v0.2 | v0.3 (used when QARI mode = auto)
    QARI_ALLOW_DOWNLOAD: bool = False  # informational only — runtime downloads are always blocked
    QARI_BASE_MODEL_DIR: str = ""  # local Qwen2-VL-2B base required by the v0.2 LoRA adapter
    QARI_MAX_TOKENS: int = 2000  # generation cap per page (v0.3 structured docs may need more)

    # ---- WeVisDoc (Tencent Qwen3-VL-2B/4B document parser) ----
    # Optional end-to-end page → Markdown engine (LaTeX formulas, HTML tables).
    # 100% local: weights must exist under WEVISDOC_MODEL_DIR. Loading uses the
    # native transformers Qwen3VLForConditionalGeneration class (no
    # trust_remote_code, no downloads; enforced offline by the network guard).
    WEVISDOC_ENABLED: bool = True
    WEVISDOC_MODEL_DIR: str = ""  # default: <MODELS_DIR>/wevisdoc (2B or 4B checkpoint)
    WEVISDOC_MAX_TOKENS: int = 8192  # generation cap per page (structured tables/formulas are token-hungry)

    # ---- PaddleOCR (local CPU alternative) ----
    # PaddleOCR 3.x with pinned CPU-only PaddlePaddle wheels (no CUDA anywhere).
    # Inference models must exist under PADDLE_MODEL_DIR/{det,rec_latin,rec_arabic};
    # model dirs are passed explicitly so PaddleX never queries its model hub.
    PADDLE_ENABLED: bool = True
    PADDLE_MODEL_DIR: str = ""  # default: <MODELS_DIR>/paddle
    PADDLE_DET_MODEL: str = "PP-OCRv6_medium_det"
    PADDLE_REC_LATIN_MODEL: str = "latin_PP-OCRv5_mobile_rec"
    PADDLE_REC_ARABIC_MODEL: str = "arabic_PP-OCRv5_mobile_rec"

    # ---- CPU / worker management ----
    OCR_WORKER_CONCURRENCY: str = "auto"  # auto | <int>
    # auto = derive from the real CPU budget (host cores, cgroup quota, affinity)
    # so workers × threads never exceed it (avoids CFS throttling / idle cores).
    OCR_THREADS_PER_WORKER: str = "auto"  # auto | <int>
    OCR_RAM_PER_WORKER_GB: float = 2.5
    # Seconds a heavy generative engine (QARI/WeVisDoc) waits for the exclusive
    # cross-process inference lock before failing with ENGINE_BUSY. 0 = fail fast.
    HEAVY_INFERENCE_WAIT_S: float = 600.0

    # ---- Uploads / disk ----
    MAX_UPLOAD_SIZE_MB: int = 50
    MIN_FREE_DISK_MB: int = 500

    # ---- Storage ----
    STORAGE_PATH: str = "./storage"
    LOGS_PATH: str = ""  # default: <STORAGE_PATH>/logs
    KEEP_TEMP_FILES: bool = False
    RETENTION_DAYS: int = 0  # 0 = keep forever

    # ---- Security ----
    JWT_SECRET: str = "CHANGE_ME"
    REQUIRE_API_KEY: bool = False
    REQUIRE_AUTH: bool = True  # true = /api/v1 needs a logged-in user OR an API key
    # Local break-glass administrator: the only account that logs in with a
    # local password instead of Active Directory. Its password is re-synced from
    # ADMIN_PASSWORD on every start. Empty = random, printed once in the logs.
    ADMIN_USERNAME: str = "administrator"
    ADMIN_PASSWORD: str = "123456"
    JWT_EXPIRES_MINUTES: int = 60 * 12
    RATE_LIMIT_PER_MINUTE: int = 120

    # ---- Active Directory (LDAP) ----
    # Users are searched in AD and added to the local DB by an admin. Login then
    # requires the account to exist in BOTH the DB and AD (password checked by AD).
    # The local break-glass account (ADMIN_USERNAME) never goes to AD.
    LDAP_ENABLED: bool = True
    LDAP_SERVER: str = "ldap://dev.team.ae"  # ldap://host[:389] or ldaps://host[:636]
    LDAP_USE_STARTTLS: bool = False
    LDAP_BASE_DN: str = ""  # empty = read defaultNamingContext from the server
    # Service account used to search the directory (UPN, DOMAIN\user or full DN).
    LDAP_BIND_USER: str = ""
    LDAP_BIND_PASSWORD: str = ""
    LDAP_TIMEOUT_S: int = 10

    # ---- Windows single sign-on (Kerberos / SPNEGO "Negotiate") ----
    # The browser sends the signed-in Windows user's Kerberos ticket; the user
    # must still be registered in the DB and enabled in AD. Linux needs a keytab
    # for HTTP/<api-host> (KRB5_KTNAME); a Windows host uses its own SSPI identity.
    SSO_ENABLED: bool = True
    # Accepted Kerberos realms / NetBIOS domains (comma separated).
    # Empty = derived from the AD base DN, e.g. DC=dev,DC=team,DC=ae -> DEV.TEAM.AE, DEV
    SSO_DOMAINS: str = ""
    CORS_ORIGINS: str = "http://localhost:3000"

    # ---- Feature toggles (auto = follow APP_ENV) ----
    SWAGGER_ENABLED: str = "auto"
    OCR_LAB_ENABLED: str = "auto"

    # ---- Derived helpers ----
    @property
    def is_production(self) -> bool:
        return self.APP_ENV.strip().lower() == "production"

    @property
    def is_development(self) -> bool:
        return not self.is_production

    def _auto_flag(self, value: str, dev_default: bool, prod_default: bool) -> bool:
        v = (value or "auto").strip().lower()
        if v in ("true", "1", "yes", "on"):
            return True
        if v in ("false", "0", "no", "off"):
            return False
        return dev_default if self.is_development else prod_default

    @property
    def swagger_enabled(self) -> bool:
        return self._auto_flag(self.SWAGGER_ENABLED, dev_default=True, prod_default=False)

    @property
    def lab_enabled(self) -> bool:
        return self._auto_flag(self.OCR_LAB_ENABLED, dev_default=True, prod_default=False)

    @property
    def max_upload_bytes(self) -> int:
        return self.MAX_UPLOAD_SIZE_MB * 1024 * 1024

    @property
    def sso_domain_list(self) -> list[str]:
        return [d.strip().upper() for d in self.SSO_DOMAINS.split(",") if d.strip()]

    @property
    def cors_origin_list(self) -> list[str]:
        return [o.strip() for o in self.CORS_ORIGINS.split(",") if o.strip()]

    @property
    def models_path(self) -> str:
        return os.path.abspath(self.MODELS_DIR)

    @property
    def qari_model_dir(self) -> str:
        return os.path.abspath(self.QARI_MODEL_DIR or os.path.join(self.models_path, "qari"))

    @property
    def qari_base_model_dir(self) -> str:
        return os.path.abspath(self.QARI_BASE_MODEL_DIR or os.path.join(self.qari_model_dir, "base"))

    @property
    def qari_default_version(self) -> str:
        v = (self.QARI_DEFAULT_VERSION or "v0.2").strip().lower()
        return "v0.3" if v == "v0.3" else "v0.2"

    @property
    def wevisdoc_model_dir(self) -> str:
        return os.path.abspath(self.WEVISDOC_MODEL_DIR or os.path.join(self.models_path, "wevisdoc"))

    @property
    def paddle_dir(self) -> str:
        return os.path.abspath(self.PADDLE_MODEL_DIR or os.path.join(self.models_path, "paddle"))

    @property
    def logs_path(self) -> str:
        return os.path.abspath(self.LOGS_PATH or os.path.join(self.STORAGE_PATH, "logs"))


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
