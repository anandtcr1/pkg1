"""User management: search Active Directory and register users in the application.

Only registered users can sign in (and only while they still exist in AD).
All endpoints require a signed-in administrator.
"""

import logging

from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import Response
from sqlalchemy.orm import Session

from app.api.v1.auth import find_user, is_local_admin
from app.core.database import get_db
from app.core.security import require_admin
from app.models.models import User
from app.schemas import schemas
from app.services import ldap_service

logger = logging.getLogger("ocr.users")

router = APIRouter(prefix="/users", tags=["users"])


def _directory_error(exc: ldap_service.LdapError) -> HTTPException:
    return HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail=str(exc))


@router.get("", response_model=list[schemas.UserOut])
def list_users(db: Session = Depends(get_db), _: dict = Depends(require_admin)):
    return db.query(User).order_by(User.created_at.asc()).all()


@router.get("/directory", response_model=list[schemas.DirectoryUserOut])
def search_directory(
    q: str = Query(..., min_length=2, max_length=64),
    limit: int = Query(25, ge=1, le=100),
    db: Session = Depends(get_db),
    _: dict = Depends(require_admin),
):
    try:
        found = ldap_service.search_users(q, limit)
    except ldap_service.LdapError as exc:
        raise _directory_error(exc) from exc
    registered = {
        (u.username or "").lower() for u in db.query(User.username).filter(User.username.isnot(None)).all()
    }
    return [
        schemas.DirectoryUserOut(
            username=u.username,
            display_name=u.display_name,
            email=u.email,
            upn=u.upn,
            department=u.department,
            title=u.title,
            registered=u.username.lower() in registered,
        )
        for u in found
    ]


@router.post("", response_model=schemas.UserOut, status_code=201)
def add_user(payload: schemas.UserCreate, db: Session = Depends(get_db), admin: dict = Depends(require_admin)):
    if is_local_admin(payload.username):
        raise HTTPException(status_code=400, detail="The local administrator account already exists.")
    try:
        ad_user = ldap_service.find_user(payload.username)
    except ldap_service.LdapError as exc:
        raise _directory_error(exc) from exc
    if ad_user is None:
        raise HTTPException(status_code=404, detail="User not found in Active Directory (or the account is disabled).")
    if find_user(db, ad_user.username) is not None:
        raise HTTPException(status_code=409, detail="User is already registered.")

    email = ad_user.email
    if email and db.query(User).filter(User.email == email).first() is not None:
        email = None  # e-mail is informational; never block registration on it
    user = User(
        username=ad_user.username,
        display_name=ad_user.display_name,
        email=email,
        # AD users never authenticate locally; this value can't match any bcrypt check.
        hashed_password="!ldap",
        is_admin=payload.is_admin,
        auth_source="ldap",
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    logger.info("USERS - %s added %s (admin=%s)", admin["username"], user.username, user.is_admin)
    return user


@router.patch("/{user_id}", response_model=schemas.UserOut)
def update_user(
    user_id: str, payload: schemas.UserUpdate, db: Session = Depends(get_db), admin: dict = Depends(require_admin)
):
    user = db.get(User, user_id)
    if user is None:
        raise HTTPException(status_code=404, detail="User not found.")
    if user.username == admin["username"] or is_local_admin(user.username or ""):
        raise HTTPException(status_code=400, detail="You cannot change the role of this account.")
    user.is_admin = payload.is_admin
    db.commit()
    db.refresh(user)
    logger.info("USERS - %s set admin=%s for %s", admin["username"], user.is_admin, user.username)
    return user


@router.delete("/{user_id}", status_code=204)
def remove_user(user_id: str, db: Session = Depends(get_db), admin: dict = Depends(require_admin)):
    user = db.get(User, user_id)
    if user is None:
        raise HTTPException(status_code=404, detail="User not found.")
    if user.username == admin["username"] or is_local_admin(user.username or ""):
        raise HTTPException(status_code=400, detail="You cannot remove this account.")
    db.delete(user)
    db.commit()
    # Existing login tokens stop working immediately: tokens are resolved against the users table.
    logger.info("USERS - %s removed %s", admin["username"], user.username)
    return Response(status_code=204)
