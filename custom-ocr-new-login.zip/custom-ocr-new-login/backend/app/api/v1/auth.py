import base64
import binascii
import logging
import secrets
from typing import Optional

import spnego
from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from spnego.exceptions import SpnegoError
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.database import SessionLocal, get_db
from app.core.security import create_access_token, current_identity, hash_password, verify_password
from app.models.models import User
from app.services import ldap_service

logger = logging.getLogger("ocr.auth")

router = APIRouter(prefix="/auth", tags=["auth"])


class LoginRequest(BaseModel):
    username: str
    password: str


def find_user(db: Session, username: str) -> Optional[User]:
    """Case-insensitive lookup — AD login names are case-insensitive."""
    return db.query(User).filter(func.lower(User.username) == username.strip().lower()).first()


def is_local_admin(username: str) -> bool:
    return username.strip().lower() == (settings.ADMIN_USERNAME or "administrator").strip().lower()


def ensure_admin(db: Session) -> str:
    """Create/repair the local break-glass administrator (idempotent, offline-safe).

    This is the only account whose password is checked locally; everyone else
    signs in through Active Directory. The stored hash is re-synced from
    ADMIN_PASSWORD on every start so the configured password always works. When
    ADMIN_PASSWORD is empty a random password is generated once and logged.
    """
    username = (settings.ADMIN_USERNAME or "administrator").strip()
    password = (settings.ADMIN_PASSWORD or "").strip()
    user = find_user(db, username)
    if user is not None:
        user.auth_source = "local"
        user.is_admin = True
        if password and not verify_password(password, user.hashed_password):
            user.hashed_password = hash_password(password)
            logger.info("ADMIN - password for %s re-synced from ADMIN_PASSWORD", user.username)
        db.commit()
        return user.username

    generated = not password
    password = generated and secrets.token_urlsafe(12) or password
    user = User(
        username=username,
        email=f"{username}@local",
        hashed_password=hash_password(password),
        is_admin=True,
        auth_source="local",
        display_name="Local administrator",
    )
    db.add(user)
    db.commit()
    if generated:
        logger.warning(
            "ADMIN - initial login created. username=%s password=%s (generated — store it safely)",
            username,
            password,
        )
    else:
        logger.info("ADMIN - initial login created. username=%s (password from ADMIN_PASSWORD)", username)
    return username


def ensure_admin_once() -> str:
    with SessionLocal() as db:
        return ensure_admin(db)


def _invalid() -> HTTPException:
    return HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid username or password.")


@router.post("/login")
def login(payload: LoginRequest, db: Session = Depends(get_db)) -> dict:
    if is_local_admin(payload.username):
        # Exception: the local administrator is verified here, never against AD.
        user = find_user(db, payload.username)
        if user is None or not verify_password(payload.password, user.hashed_password):
            logger.warning("AUTH - local admin login failed for %s", payload.username.strip())
            raise _invalid()
    else:
        # Everyone else must exist in our DB (added by an admin) AND in AD.
        username = ldap_service.normalize_username(payload.username)
        user = find_user(db, username) if username else None
        if user is None:
            logger.warning("AUTH - login refused, %s is not registered in the application", username)
            raise _invalid()
        try:
            ad_user = ldap_service.authenticate(username, payload.password)
        except ldap_service.LdapError as exc:
            logger.error("AUTH - AD unavailable during login of %s: %s", username, exc)
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Active Directory is unavailable. Try again later or contact the administrator.",
            ) from exc
        if ad_user is None:
            logger.warning("AUTH - AD rejected login for %s (wrong password, disabled or removed)", username)
            raise _invalid()
        if ad_user.display_name and ad_user.display_name != user.display_name:
            user.display_name = ad_user.display_name
            db.commit()

    return _session(user)


def _session(user: User) -> dict:
    token = create_access_token(user.username, settings.JWT_EXPIRES_MINUTES)
    return {
        "access_token": token,
        "token_type": "bearer",
        "expires_in": settings.JWT_EXPIRES_MINUTES * 60,
        "username": user.username,
        "display_name": user.display_name,
        "is_admin": user.is_admin,
        "auth_required": settings.REQUIRE_AUTH or settings.REQUIRE_API_KEY,
    }


def _sso_refused(detail: str) -> JSONResponse:
    # Deliberately no WWW-Authenticate header: re-challenging after a failed
    # attempt makes browsers pop up a credentials dialog. The frontend falls
    # back to the login page instead.
    return JSONResponse(status_code=status.HTTP_401_UNAUTHORIZED, content={"detail": detail})


def _split_principal(principal: str) -> tuple[str, str]:
    r"""'jdoe@DEV.TEAM.AE' or 'DEV\jdoe' -> ('jdoe', 'DEV.TEAM.AE' / 'DEV')."""
    if "\\" in principal:
        domain, name = principal.split("\\", 1)
    elif "@" in principal:
        name, domain = principal.rsplit("@", 1)
    else:
        name, domain = principal, ""
    return name.strip(), domain.strip().upper()


@router.get("/sso")
def windows_sso(request: Request, db: Session = Depends(get_db)):
    """Windows integrated sign-in (Kerberos via SPNEGO "Negotiate").

    1st call (no ticket)  -> 401 + WWW-Authenticate: Negotiate (browser attaches the ticket and retries)
    2nd call (ticket)     -> validate ticket, require the user in our DB AND enabled in AD -> session
    Anything else         -> 401 without a challenge, so the frontend shows the login page.
    """
    if not (settings.SSO_ENABLED and settings.LDAP_ENABLED):
        return _sso_refused("Windows sign-in is disabled.")
    header = request.headers.get("Authorization", "")
    if not header.lower().startswith("negotiate "):
        return JSONResponse(
            status_code=status.HTTP_401_UNAUTHORIZED,
            content={"detail": "Windows credentials required."},
            headers={"WWW-Authenticate": "Negotiate"},
        )

    try:
        in_token = base64.b64decode(header.split(" ", 1)[1].strip(), validate=True)
        ctx = spnego.server(protocol="negotiate", service="HTTP")
        out_token = ctx.step(in_token)
    except (binascii.Error, SpnegoError) as exc:
        logger.warning("SSO - ticket rejected: %s", exc)
        return _sso_refused("Windows sign-in failed.")
    except Exception as exc:  # missing keytab / GSSAPI library, etc.
        logger.error("SSO - Kerberos acceptor unavailable: %s", exc)
        return _sso_refused("Windows sign-in is not available on this server.")
    if not ctx.complete:
        # NTLM fallback needs a connection-bound multi-leg exchange — only Kerberos is supported.
        logger.warning("SSO - incomplete handshake (browser offered NTLM instead of Kerberos?)")
        return _sso_refused("Windows sign-in failed (Kerberos ticket required).")

    username, domain = _split_principal(ctx.client_principal or "")
    try:
        allowed = set(settings.sso_domain_list) or ldap_service.directory_domains()
        if not username or domain not in allowed:
            logger.warning("SSO - principal %s is outside the allowed domains %s", ctx.client_principal, allowed)
            return _sso_refused("Windows account is not from an allowed domain.")
        user = find_user(db, username)
        if user is None or is_local_admin(username):
            logger.warning("SSO - %s is not registered in the application", username)
            return _sso_refused("Windows account is not registered in the application.")
        ad_user = ldap_service.find_user(username)
    except ldap_service.LdapError as exc:
        logger.error("SSO - AD unavailable during sign-in of %s: %s", username, exc)
        return _sso_refused("Active Directory is unavailable.")
    if ad_user is None:
        logger.warning("SSO - %s is disabled or missing in AD", username)
        return _sso_refused("Windows account is disabled or missing in Active Directory.")
    if ad_user.display_name and ad_user.display_name != user.display_name:
        user.display_name = ad_user.display_name
        db.commit()

    logger.info("SSO - %s signed in with Windows credentials", user.username)
    headers = {"WWW-Authenticate": "Negotiate " + base64.b64encode(out_token).decode()} if out_token else None
    return JSONResponse(content=_session(user), headers=headers)


@router.get("/me")
def me(request: Request, db: Session = Depends(get_db)) -> dict:
    """Identity probe for the frontend auth guard.

    - When a valid login JWT / API key is present -> authenticated.
    - When no credential is passed but auth is off -> anonymous (allowed).
    - When no/expired credential is passed and auth is on -> authenticated=false.
    """
    auth_required = settings.REQUIRE_AUTH or settings.REQUIRE_API_KEY
    identity = current_identity(request, db)
    if identity is not None:
        return {
            "authenticated": True,
            "kind": identity["kind"],
            "username": identity["username"],
            "is_admin": bool(identity["is_admin"]),
            "auth_required": auth_required,
        }
    return {
        "authenticated": False if auth_required else True,
        "kind": None if auth_required else "anonymous",
        "username": None,
        "is_admin": False,
        "auth_required": auth_required,
    }