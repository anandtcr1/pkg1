import logging
import secrets

from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.database import SessionLocal, get_db
from app.core.security import create_access_token, current_identity, hash_password, verify_password
from app.models.models import User

logger = logging.getLogger("ocr.auth")

router = APIRouter(prefix="/auth", tags=["auth"])


class LoginRequest(BaseModel):
    username: str
    password: str


def ensure_admin(db: Session) -> str:
    """Create the initial admin user on first start (idempotent). Pure local/bcrypt — offline-safe.

    Returns the admin username. When ADMIN_PASSWORD is empty a random password
    is generated, printed once to the API logs, and stored hashed.
    """
    username = (settings.ADMIN_USERNAME or "admin").strip()
    existing = db.query(User).filter(User.username == username).first()
    if existing is not None:
        return existing.username

    # Pre-existing row that only had an email (table predates username column).
    legacy = db.query(User).filter(User.email == f"{username}@local").first()
    if legacy is not None:
        legacy.username = username
        legacy.is_admin = True
        db.commit()
        return legacy.username

    password = (settings.ADMIN_PASSWORD or "").strip()
    generated = not password
    password = generated and secrets.token_urlsafe(12) or password
    user = User(
        username=username,
        email=f"{username}@local",
        hashed_password=hash_password(password),
        is_admin=True,
    )
    db.add(user)
    db.commit()
    if generated:
        logger.warning(
            "ADMIN - initial login created. username=%s password=%s (generated — store it safely)",
            username,
            password,
        )
    else:
        logger.info("ADMIN - initial login created. username=%s (password from ADMIN_PASSWORD)", username)
    return username


def ensure_admin_once() -> str:
    with SessionLocal() as db:
        return ensure_admin(db)


@router.post("/login")
def login(payload: LoginRequest, db: Session = Depends(get_db)) -> dict:
    username = payload.username.strip()
    user = db.query(User).filter(User.username == username).first()
    if user is None or not verify_password(payload.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid username or password.",
        )
    token = create_access_token(user.username, settings.JWT_EXPIRES_MINUTES)
    return {
        "access_token": token,
        "token_type": "bearer",
        "expires_in": settings.JWT_EXPIRES_MINUTES * 60,
        "username": user.username,
        "is_admin": user.is_admin,
        "auth_required": settings.REQUIRE_AUTH or settings.REQUIRE_API_KEY,
    }


@router.get("/me")
def me(request: Request, db: Session = Depends(get_db)) -> dict:
    """Identity probe for the frontend auth guard.

    - When a valid login JWT / API key is present -> authenticated.
    - When no credential is passed but auth is off -> anonymous (allowed).
    - When no/expired credential is passed and auth is on -> authenticated=false.
    """
    auth_required = settings.REQUIRE_AUTH or settings.REQUIRE_API_KEY
    identity = current_identity(request, db)
    if identity is not None:
        return {
            "authenticated": True,
            "kind": identity["kind"],
            "username": identity["username"],
            "is_admin": bool(identity["is_admin"]),
            "auth_required": auth_required,
        }
    return {
        "authenticated": False if auth_required else True,
        "kind": None if auth_required else "anonymous",
        "username": None,
        "is_admin": False,
        "auth_required": auth_required,
    }