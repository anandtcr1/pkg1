import hashlib
import secrets
from datetime import datetime, timedelta, timezone
from typing import Optional

import bcrypt
from fastapi import Depends, HTTPException, Request, status
from jose import JWTError, jwt
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.database import get_db

ALGORITHM = "HS256"
API_KEY_PREFIX = "ocr_live_"


def generate_api_key() -> tuple[str, str]:
    """Return (plain_key, sha256_hash). The plain key is shown to the user once."""
    plain = API_KEY_PREFIX + secrets.token_urlsafe(32)
    return plain, hash_api_key(plain)


def hash_api_key(plain_key: str) -> str:
    return hashlib.sha256(plain_key.encode("utf-8")).hexdigest()


def hash_password(plain: str) -> str:
    """bcrypt hash for local user passwords (self-contained — fully offline)."""
    return bcrypt.hashpw(plain.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(plain: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))
    except (ValueError, TypeError):
        return False


def create_access_token(subject: str, expires_minutes: Optional[int] = None) -> str:
    minutes = expires_minutes if expires_minutes is not None else settings.JWT_EXPIRES_MINUTES
    expire = datetime.now(timezone.utc) + timedelta(minutes=minutes)
    payload = {"sub": subject, "exp": expire}
    return jwt.encode(payload, settings.JWT_SECRET, algorithm=ALGORITHM)


def decode_access_token(token: str) -> Optional[str]:
    try:
        payload = jwt.decode(token, settings.JWT_SECRET, algorithms=[ALGORITHM])
        return payload.get("sub")
    except JWTError:
        return None


def _extract_bearer(request: Request) -> Optional[str]:
    auth = request.headers.get("Authorization", "")
    if auth.lower().startswith("bearer "):
        return auth[7:].strip()
    # also allow ?api_key= for simple curl testing
    return request.query_params.get("api_key")


def _verify_credentials(key: str, db: Session) -> Optional[dict]:
    """Resolve a bearer token as either a login JWT (user) or an API key.

    Returns an identity dict or None when the credential is not valid.
    """
    # 1) Login JWTs issued by /api/v1/auth/login — sub carries the username.
    subject = decode_access_token(key)
    if subject is not None:
        from app.models.models import User

        user = db.query(User).filter(User.username == subject).first()
        if user is not None:
            return {"kind": "user", "username": user.username, "is_admin": user.is_admin}
        return None  # token was validly signed but the user no longer exists

    # 2) API keys created via POST /api-keys (hash stored, one-way).
    from app.models.models import APIKey

    record = db.query(APIKey).filter(APIKey.key_hash == hash_api_key(key), APIKey.revoked.is_(False)).first()
    if record is None:
        return None
    record.last_used_at = datetime.now(timezone.utc)
    db.commit()
    return {"kind": "api_key", "username": None, "is_admin": False}


def require_auth(request: Request, db: Session = Depends(get_db)) -> None:
    """Dependency guarding /api/v1 endpoints.

    Allowed when both REQUIRE_AUTH and REQUIRE_API_KEY are off (default local dev).
    When either is on, a valid login JWT OR a valid API key is required.
    """
    if not (settings.REQUIRE_AUTH or settings.REQUIRE_API_KEY):
        return

    key = _extract_bearer(request)
    if not key:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required. Pass 'Authorization: Bearer <token>'.",
        )
    if _verify_credentials(key, db) is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid, expired or revoked credential.")


def current_identity(request: Request, db: Session = Depends(get_db)) -> Optional[dict]:
    """Resolve the caller's identity (if any). Used by GET /api/v1/auth/me."""
    key = _extract_bearer(request)
    if not key:
        return None
    return _verify_credentials(key, db)
