import logging

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.api.v1 import apikeys, auth, benchmark, corrections, engines, languages, ocr, stats, system
from app.core import network_guard
from app.core.config import settings
from app.core.database import ensure_schema
from app.core.errors import OCRError
from app.core.logging_config import configure_logging
from app.core.rate_limit import RateLimitMiddleware
from app.models import models  # noqa: F401 — ensure models are registered

configure_logging()
logger = logging.getLogger("ocr")

# Offline enforcement happens before anything else can open a socket.
if not settings.NETWORK_ACCESS:
    network_guard.install()

app = FastAPI(
    title="IOCR — Intelligence OCR API",
    description="Offline Arabic + English OCR: local models, bounding boxes, confidence, "
    "    structured extraction, table detection, OCR Lab benchmarking.",
    version="1.6.0",
    docs_url="/docs" if settings.swagger_enabled else None,
    redoc_url="/redoc" if settings.swagger_enabled else None,
    openapi_url="/openapi.json" if settings.swagger_enabled else None,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list + ["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.add_middleware(RateLimitMiddleware)


@app.exception_handler(OCRError)
async def ocr_error_handler(_: Request, exc: OCRError) -> JSONResponse:
    return JSONResponse(
        status_code=400,
        content={"error_code": exc.code.value, "detail": exc.public_message(settings.is_development)},
    )


@app.on_event("startup")
def on_startup() -> None:
    ensure_schema()
    auth.ensure_admin_once()
    # Inline mode runs OCR in this process: cap its thread budget too. In celery
    # mode the API does no OCR, so skip (avoids importing torch into the API).
    threads = None
    if settings.WORKER_MODE != "celery":
        from app.services.resources import apply_thread_budget

        threads = apply_thread_budget()
    logger.info(
        "API ready | env=%s offline=%s network_access=%s guard=%s models=%s storage=%s threads=%s",
        settings.APP_ENV,
        settings.OFFLINE_MODE,
        settings.NETWORK_ACCESS,
        network_guard.is_installed(),
        settings.models_path,
        settings.STORAGE_PATH,
        threads,
    )
    # Security posture, logged explicitly at startup (also in the worker).
    logger.info("SEC - QARI model source: %s", settings.MODEL_SOURCE.upper())
    logger.info("SEC - Network inference: %s", "DISABLED" if not settings.NETWORK_ACCESS else "ENABLED")
    logger.info("SEC - Automatic downloads: %s", "DISABLED" if not settings.AUTO_DOWNLOAD_MODELS else "ENABLED")
    logger.info(
        "SEC - Auth require_login=%s require_api_key=%s admin_user=%s",
        settings.REQUIRE_AUTH,
        settings.REQUIRE_API_KEY,
        settings.ADMIN_USERNAME or "admin",
    )


@app.get("/health", tags=["meta"])
def health() -> dict:
    return {"status": "ok", "env": settings.APP_ENV, "offline": settings.OFFLINE_MODE}


app.include_router(auth.router, prefix="/api/v1")
app.include_router(ocr.router, prefix="/api/v1")
app.include_router(stats.router, prefix="/api/v1")
app.include_router(corrections.router, prefix="/api/v1")
app.include_router(apikeys.router, prefix="/api/v1")
app.include_router(engines.router, prefix="/api/v1")
app.include_router(languages.router, prefix="/api/v1")
app.include_router(system.router, prefix="/api/v1")
app.include_router(benchmark.router, prefix="/api/v1")
