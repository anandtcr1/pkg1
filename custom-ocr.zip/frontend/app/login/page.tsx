"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { ScanText } from "lucide-react";
import { toast } from "sonner";

import { getAuthMe, getStoredToken, login, setStoredToken } from "@/lib/api";
import { useI18n } from "@/lib/i18n";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function LoginPage() {
  const { t } = useI18n();
  const router = useRouter();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [authDisabled, setAuthDisabled] = useState(false);

  // Already signed in -> go to dashboard. Otherwise show the auth mode note.
  useEffect(() => {
    let cancelled = false;
    getAuthMe()
      .then((me) => {
        if (cancelled) return;
        if (me.authenticated && me.kind === "user") router.replace("/");
        setAuthDisabled(!me.auth_required);
      })
      .catch(() => setAuthDisabled(false));
    return () => {
      cancelled = true;
    };
  }, [router]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (busy) return;
    setBusy(true);
    try {
      const res = await login(username.trim(), password);
      setStoredToken(res.access_token);
      toast.success(`${t("auth.success")} — ${res.username}`);
      router.replace("/");
      router.refresh();
    } catch {
      toast.error(t("auth.error"));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex min-h-[70vh] items-center justify-center">
      <Card className="w-full max-w-sm">
        <CardHeader className="items-center text-center">
          <div className="mb-1 flex h-10 w-10 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <ScanText className="h-5 w-5" />
          </div>
          <CardTitle className="text-xl">{t("auth.title")}</CardTitle>
          <CardDescription>{t("auth.subtitle")}</CardDescription>
        </CardHeader>
        <CardContent>
          {getStoredToken() === null && authDisabled && (
            <p className="mb-4 rounded-md bg-muted px-3 py-2 text-center text-xs text-muted-foreground">
              {t("auth.no_auth_note")}
            </p>
          )}
          <form onSubmit={onSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username">{t("auth.username")}</Label>
              <Input
                id="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                autoComplete="username"
                autoFocus
                required
                dir="ltr"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">{t("auth.password")}</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="current-password"
                required
                dir="ltr"
              />
            </div>
            <Button type="submit" className="w-full" disabled={busy}>
              {busy ? t("auth.submitting") : t("auth.submit")}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}