export interface OCRBlock {
  id: string;
  text: string;
  confidence: number | null;
  bbox: [number, number, number, number] | null;
  language: string | null;
  block_type: string;
  region_label?: string | null; // Selective OCR: which selected region produced this block
}

export interface RegionSpec {
  page_number: number;
  label: string;
  x: number; // 0-1 normalized, from left
  y: number; // 0-1 normalized, from top
  width: number; // 0-1 normalized
  height: number; // 0-1 normalized
  order: number;
}

export interface RegionOut {
  page_number: number;
  label: string;
  x: number;
  y: number;
  width: number;
  height: number;
  order: number;
}

export interface OCRPage {
  id: string;
  page_number: number;
  text: string | null;
  confidence: number | null;
  width: number | null;
  height: number | null;
  image_url: string | null;
  blocks: OCRBlock[];
}

export interface JobSummary {
  id: string;
  filename: string;
  mime_type: string;
  file_size: number;
  status: "pending" | "processing" | "completed" | "failed" | string;
  language: string | null;
  engine: string | null;
  engine_version: string | null;
  device: string | null;
  confidence: number | null;
  page_count: number;
  processing_time: number | null;
  document_type: string | null;
  error_code: string | null;
  verified_cer: number | null;
  verified_wer: number | null;
  created_at: string | null;
}

export interface ExtractedTable {
  headers: string[];
  rows: string[][];
  page_number?: number;
}

export interface StructuredData {
  fields?: Record<string, unknown>;
  tables?: ExtractedTable[];
}

export interface JobDetail extends JobSummary {
  error: string | null;
  peak_memory_mb: number | null;
  cpu_percent: number | null;
  document_type_confidence: number | null;
  structured_data: StructuredData | null;
  options: Record<string, unknown> | null;
  text: string | null;
  updated_at: string | null;
  regions: RegionOut[];
  pages: OCRPage[];
}

export interface JobList {
  items: JobSummary[];
  total: number;
}

export type EngineName = "auto" | "tesseract" | "easyocr" | "qari" | "wevisdoc";
export type QARIMode = "auto" | "printed" | "handwritten";
export type OCRMode = "full" | "area" | "multi";

export interface OCROptions {
  engine?: EngineName;
  language?: string;
  document_type?: string;
  quality_mode?: "fast" | "balanced" | "high";
  device_preference?: "auto" | "cpu" | "cuda";
  deskew?: boolean;
  denoise?: boolean;
  auto_rotate?: boolean;
  enhance_contrast?: boolean;
  detect_tables?: boolean;
  structured_extraction?: boolean;
  preserve_layout?: boolean;
  preserve_diacritics?: boolean;
  preserve_punctuation?: boolean;
  handwriting_detection?: boolean;
  qari_mode?: QARIMode;
  qari_version?: "v0.2" | "v0.3";
  ocr_mode?: OCRMode;
  region_specs?: RegionSpec[];
}

export interface StatsOverview {
  documents_processed: number;
  pages_processed: number;
  average_confidence: number | null; // OCR confidence — NOT accuracy; null = no engine reported scores
  verified_accuracy: number | null;
  verified_samples: number;
  average_processing_time: number;
  failed_jobs: number;
  total_corrections: number;
}

export interface StatsCharts {
  requests_per_day: { date: string; count: number }[];
  confidence_per_day: { date: string; confidence: number; documents: number }[];
  language_distribution: { language: string; count: number }[];
  file_types: { type: string; count: number }[];
  engine_usage: { engine: string; count: number }[];
}

export interface EnginePerformance {
  engine: string;
  jobs: number;
  pages: number;
  avg_processing_time: number;
  avg_confidence: number | null; // null = engine reported no confidence scores (e.g. QARI)
}

export interface SystemInfo {
  cpu_cores: number;
  cpu_host_cores?: number | null;
  cpu_budget_cores?: number | null;
  cpu_cgroup_quota_cores?: number | null;
  gpu_available: boolean;
  gpu_name: string | null;
  platform: string;
  python_version: string;
  worker_mode: string;
  default_engine: string;
  omp_thread_limit: string | null;
}

// ---------- Languages ----------

export interface LanguageInfo {
  code: string;
  name_en: string;
  name_ar: string;
  script: string;
  direction: "rtl" | "ltr";
  engines: { tesseract: boolean; easyocr: boolean; qari: boolean; wevisdoc: boolean };
}

// ---------- Engines / System Health ----------

export type EngineStatus = "READY" | "MODEL_NOT_INSTALLED" | "UNAVAILABLE" | "ERROR";

export interface EngineCheck {
  status: string;
  time: number | null;
  text_sample: string | null;
  error: string | null;
  checked_at: string | null;
}

export interface EngineInfo {
  name: string;
  available: boolean;
  languages: string[];
  status: EngineStatus | string;
  reason: string | null;
  model_path: string | null;
  version: string | null;
  device: string;
  internet_required: boolean;
  model_source: string;
  last_check: EngineCheck | null;
  details: Record<string, unknown> | null;
}

export interface OfflineStatus {
  offline_mode: boolean;
  network_access: boolean;
  network_guard_active: boolean;
  model_source: string;
  auto_download_models: boolean;
  telemetry: boolean;
  models_dir: string;
  models_dir_exists: boolean;
}

export interface SystemHealth {
  app_env: string;
  version: string;
  offline: OfflineStatus;
  engines: EngineInfo[];
  database: string;
  queue: string;
  disk_free_mb: number;
  lab_enabled: boolean;
  swagger_enabled: boolean;
}

export interface SystemResources {
  cpu_percent: number;
  cpu_cores: number;
  cpu_host_cores?: number | null;
  cpu_budget_cores?: number | null;
  cpu_cgroup_quota_cores?: number | null;
  memory: { total: number; available: number; used: number; percent: number };
  gpu: { device: string; name: string; vram_total_mb: number; vram_free_mb: number } | null;
  worker_mode: string;
  worker_count: number;
  recommended_workers: number;
  threads_per_worker: number;
  queue_length: number | null;
  active_jobs: number;
  pending_jobs: number;
  completed_jobs: number;
  failed_jobs: number;
  avg_processing_time: number | null;
  p50_processing_time: number | null;
  p95_processing_time: number | null;
}

export interface StorageArea {
  name: string;
  path: string;
  bytes: number;
}

export interface StorageReport {
  areas: StorageArea[];
  disk_total_bytes: number;
  disk_free_bytes: number;
}

export interface CleanupResult {
  cleaned: string[];
  freed_bytes: number;
}

// ---------- OCR Lab (benchmarks) ----------

export interface BenchmarkResultRow {
  engine: string;
  version: string | null;
  device: string;
  status: "OK" | "SKIPPED" | "FAIL" | string;
  reason: string | null;
  time: number | null;
  peak_memory_mb: number | null;
  cpu_percent: number | null;
  confidence: number | null;
  blocks: number;
  text: string | null;
  cer: number | null;
  wer: number | null;
  cer_no_diacritics: number | null;
  wer_no_diacritics: number | null;
}

export interface BenchmarkOut {
  id: string;
  filename: string;
  mime_type: string;
  ground_truth: string | null;
  language: string | null;
  engines: string[];
  status: string;
  results: BenchmarkResultRow[] | null;
  error: string | null;
  created_at: string | null;
  completed_at: string | null;
}

export interface BenchmarkCreated {
  benchmark_id: string;
  status: string;
}

export interface Correction {
  id: string;
  job_id: string;
  page_number: number;
  original_text: string;
  corrected_text: string;
  confidence: number | null;
  language: string | null;
  bbox: [number, number, number, number] | null;
  created_at: string | null;
}

export interface APIKeyOut {
  id: string;
  name: string;
  prefix: string;
  revoked: boolean;
  created_at: string | null;
  last_used_at: string | null;
}

export interface APIKeyCreated {
  id: string;
  name: string;
  key: string;
  prefix: string;
  created_at: string;
}

// ---------- Auth ----------

export interface LoginResponse {
  access_token: string;
  token_type: string;
  expires_in: number;
  username: string;
  is_admin: boolean;
  auth_required: boolean;
}

export interface AuthMe {
  authenticated: boolean;
  kind: "user" | "api_key" | "anonymous" | null;
  username: string | null;
  is_admin: boolean;
  auth_required: boolean;
}