"use client";

import { useEffect, useState } from "react";
import { usePathname, useRouter } from "next/navigation";

import { getAuthMe } from "@/lib/api";
import { useI18n } from "@/lib/i18n";

export function AuthGuard({ children }: { children: React.ReactNode }) {
  const { t } = useI18n();
  const pathname = usePathname();
  const router = useRouter();
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (pathname === "/login") {
      setReady(true);
      return;
    }
    let cancelled = false;
    getAuthMe()
      .then((me) => {
        if (cancelled) return;
        if (!me.authenticated) {
          router.replace("/login");
          return;
        }
        setReady(true);
      })
      .catch(() => {
        // Backend unreachable: don't lock the user out — pages will show errors.
        if (!cancelled) setReady(true);
      });
    return () => {
      cancelled = true;
    };
  }, [pathname, router]);

  if (!ready) {
    return <div className="py-24 text-center text-sm text-muted-foreground">{t("common.loading")}</div>;
  }
  return <>{children}</>;
}