"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  BarChart3,
  Code2,
  FileText,
  FlaskConical,
  HeartPulse,
  History,
  LayoutDashboard,
  LogIn,
  LogOut,
  ScanText,
  Settings,
} from "lucide-react";

import { cn } from "@/lib/utils";
import { clearStoredToken, getAuthMe } from "@/lib/api";
import { useI18n, type TranslationKey } from "@/lib/i18n";
import type { AuthMe } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/theme-toggle";
import { LanguageSwitcher } from "@/components/language-switcher";

interface NavItem {
  href: string;
  labelKey: TranslationKey;
  icon: typeof LayoutDashboard;
}

interface NavGroup {
  labelKey: TranslationKey;
  items: NavItem[];
}

const NAV_GROUPS: NavGroup[] = [
  {
    labelKey: "nav.group.main",
    items: [{ href: "/", labelKey: "nav.dashboard", icon: LayoutDashboard }],
  },
  {
    labelKey: "nav.group.ocr",
    items: [
      { href: "/ocr", labelKey: "nav.new_ocr", icon: ScanText },
      { href: "/history", labelKey: "nav.history", icon: History },
      { href: "/documents", labelKey: "nav.documents", icon: FileText },
    ],
  },
  {
    labelKey: "nav.group.development",
    items: [{ href: "/lab", labelKey: "nav.lab", icon: FlaskConical }],
  },
  {
    labelKey: "nav.group.monitoring",
    items: [
      { href: "/analytics", labelKey: "nav.analytics", icon: BarChart3 },
      { href: "/system-health", labelKey: "nav.system_health", icon: HeartPulse },
    ],
  },
  {
    labelKey: "nav.group.integration",
    items: [{ href: "/api", labelKey: "nav.api", icon: Code2 }],
  },
  {
    labelKey: "nav.group.administration",
    items: [{ href: "/settings", labelKey: "nav.settings", icon: Settings }],
  },
];

const FLAT_ITEMS = NAV_GROUPS.flatMap((g) => g.items);

function isActive(href: string, pathname: string): boolean {
  return href === "/" ? pathname === "/" : pathname.startsWith(href);
}

export function Sidebar() {
  const pathname = usePathname();
  const { t } = useI18n();

  return (
    <aside className="fixed inset-y-0 start-0 z-40 hidden w-60 flex-col border-e bg-card md:flex">
      <div className="flex h-16 items-center gap-2 border-b px-6">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
          <ScanText className="h-5 w-5" />
        </div>
        <div>
          <p className="text-sm font-bold leading-none">{t("app.name")}</p>
          <p className="text-xs text-muted-foreground">{t("app.tagline_full")}</p>
        </div>
      </div>

      <nav className="flex-1 space-y-4 overflow-y-auto px-3 py-4">
        {NAV_GROUPS.map((group) => (
          <div key={group.labelKey} className="space-y-1">
            <p className="px-3 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground/70">
              {t(group.labelKey)}
            </p>
            {group.items.map((item) => {
              const active = isActive(item.href, pathname);
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
                    active
                      ? "bg-primary/10 text-primary"
                      : "text-muted-foreground hover:bg-accent hover:text-foreground"
                  )}
                >
                  <item.icon className="h-4 w-4" />
                  {t(item.labelKey)}
                </Link>
              );
            })}
          </div>
        ))}
      </nav>

      <div className="space-y-3 border-t px-4 py-3">
        <AccountRow />
        <LanguageSwitcher />
        <div className="flex items-center justify-between">
          <span className="text-xs text-muted-foreground">v1.3</span>
          <ThemeToggle />
        </div>
      </div>
    </aside>
  );
}

function AccountRow() {
  const { t } = useI18n();
  const router = useRouter();
  const [me, setMe] = useState<AuthMe | null>(null);

  useEffect(() => {
    let cancelled = false;
    getAuthMe()
      .then((m) => {
        if (cancelled) return;
        setMe(m);
      })
      .catch(() => {
        if (!cancelled) setMe(null);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  if (!me?.authenticated || me.kind === "anonymous" || me.kind === "api_key") {
    return (
      <Button variant="outline" size="sm" className="w-full justify-start px-3" asChild>
        <Link href="/login">
          <LogIn className="h-4 w-4" />
          {t("auth.title")}
        </Link>
      </Button>
    );
  }

  function signOut() {
    clearStoredToken();
    router.replace("/login");
  }

  return (
    <div className="flex items-center justify-between gap-2 rounded-md border px-3 py-2">
      <div className="min-w-0">
        <p className="truncate text-xs font-semibold" dir="ltr">
          {me.username}
        </p>
        <p className="text-[10px] text-muted-foreground">{me.is_admin ? t("auth.admin") : t("auth.user")}</p>
      </div>
      <Button variant="ghost" size="icon" onClick={signOut} title={t("auth.logout")}>
        <LogOut className="h-4 w-4" />
      </Button>
    </div>
  );
}

export function MobileNav() {
  const pathname = usePathname();
  const { t } = useI18n();
  const primary = FLAT_ITEMS.slice(0, 5);
  return (
    <div className="fixed bottom-0 start-0 end-0 z-40 flex items-center justify-around border-t bg-card py-2 md:hidden">
      {primary.map((item) => {
        const active = isActive(item.href, pathname);
        return (
          <Link
            key={item.href}
            href={item.href}
            className={cn(
              "flex flex-col items-center gap-1 px-2 py-1 text-[10px]",
              active ? "text-primary" : "text-muted-foreground"
            )}
          >
            <item.icon className="h-5 w-5" />
            {t(item.labelKey)}
          </Link>
        );
      })}
    </div>
  );
}